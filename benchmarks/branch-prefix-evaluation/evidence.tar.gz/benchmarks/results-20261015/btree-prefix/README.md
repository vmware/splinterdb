# Resident B-tree prefix evaluation — 2026-10-15

The isolated B-tree results show a space/CPU tradeoff: common-prefix packed
trees occupy **27.75% less allocated space**, but their packing throughput is
**8.11% lower than the candidate with compression disabled**. Several resident
long scan cases have **4–6% lower throughput than main**. Mutable insertion and overwrite
estimates stay within 1.5% of main, with almost identical instruction counts.
These results do not establish a general 2–3% regression ceiling.

The candidate is `b9cc3ea4`; the frozen main baseline is
`6105c49f66a24d3006ba0464d9558b52e692e27c`. This campaign adds a reusable
[direct B-tree harness](../../btree_prefix_bench.c) and measurements. It does
not change production runtime code. The primary matrix contains 396 samples
with six balanced paired repetitions per comparison. A separate 120-sample
full-switch read comparison is also complete: **516 comparison samples in
total**, with smoke and calibration runs kept separate.

## Results against main

Numbers are paired throughput changes; positive is faster. Lexical pack/read
rows use compression enabled; mutable and nonlexical rows use the candidate's
uncompressed path. See [all rates and nominal 95% intervals](TABLES.md) for
the complete main/off/on comparisons.

| Operation | Common-prefix lexical | Dispersed lexical | Nonlexical |
| --- | ---: | ---: | ---: |
| Random fresh inserts | +0.79% | +0.62% | −0.28% |
| Sorted fresh inserts | −1.42% | −0.50% | +0.82% |
| Same-size overwrites | +0.25% | +1.26% | −0.26% |
| Array-fed pack | −8.38% | +0.23% | +0.51% |
| Point hit | +3.03% | +0.56% | −1.84% |
| Point miss | +6.05% | +4.14% | −2.16% |
| Scan one key | +4.86% | +5.29% | −1.72% |
| Scan 10,000 keys | −6.18% | −3.61% | −4.61% |
| Scan all 200,000 keys | +0.89% | −4.26% | −2.45% |

The most clearly resolved losses above 3% are common-prefix packing versus
main (−8.38%, interval −10.49% to −6.22%), common-prefix 10,000-key scans
(−6.18%, −7.68% to −4.65%), dispersed lexical full scans
(−4.26%, −5.07% to −3.44%), and nonlexical 10,000-key scans
(−4.61%, −5.58% to −3.63%). Dispersed lexical 10,000-key scans also regress,
although their interval crosses the 3% threshold.

Some smaller estimates remain uncertain: common sorted inserts permit a 3.11%
loss in their interval, and nonlexical full scans, misses, one-key scans and
packing still permit losses exceeding 3%. Common-prefix full scans show no
resolved change versus main; that is not evidence of equivalence. These are
separate nominal six-pair intervals, without a multiple-comparison adjustment.

## What enabling compression changes

For primary lexical reads, the `off` profile packs without compression but
keeps lexical comparison enabled. Thus `on/off` isolates the compressed
representation while holding comparison eligibility fixed. `off/main` also
includes the candidate's comparator-dispatch and prefix-support changes.
Mutable insertion ignores the lexical flag. Enabling lexical ordering for the
custom nonlexical comparator would be invalid, so those cases compare current
with main instead.

For common-prefix data, compression changes allocated output from 35.129 MiB
to 25.379 MiB. The first repetition has 6,261 leaves instead of 8,696; 6,260
leaves are compressed, with a mean stored prefix of 48.97 bytes. The input has
48 fixed leading bytes. Dispersed lexical and nonlexical outputs have no
compressed leaves and retain the original size.

Common-prefix packing drops from 15.760 to 14.481 million keys/s when enabled
(−8.11%, interval −10.15% to −6.03%). User-mode instructions per key rise 30.35% and
process CPU time per key rises 8.86%. This cost is inside `btree_pack()`:
its input iterator only indexes an already prepared tuple array.

At fixed lexical comparison eligibility, common-prefix 10,000-key scans lose
2.43% from compression, while full scans gain 4.46%. Combining that with the
candidate's existing uncompressed scan cost leaves the former 6.18% below main
and the latter statistically unresolved versus main. Point-read gains versus
main often also appear in the `off` profile; they cannot all be credited to
compression. Common-prefix hit improvement from compression alone is unresolved
(+4.35%, interval −0.42% to +9.35%).

Dispersed lexical packing is 2.17% faster with the flag enabled in this sample,
despite identical output and 0.62% more instructions. This is an observed
timing difference, not a space-saving benefit or an established causal speedup.
Its read `on/off` intervals all include zero, as expected for identical
uncompressed representations and read eligibility.

### Full runtime switch

The separate adjacent `on/callback` read pairs disable both packing compression
and lexical read dispatch in the reference profile. Both profiles still contain
the candidate's prefix-support code. These ratios are not chained with the
primary ratios. See [full rates, intervals and instruction counts](FULL-SWITCH.md).

| Read operation | Common-prefix enabled/disabled | Dispersed lexical enabled/disabled |
| --- | ---: | ---: |
| Point hit | +2.96% [−2.92%, +9.21%] | +0.90% [−1.21%, +3.06%] |
| Point miss | +7.29% [+5.23%, +9.39%] | +3.48% [+0.41%, +6.65%] |
| Scan one key | +6.90% [+4.74%, +9.11%] | +6.80% [+4.17%, +9.49%] |
| Scan 10,000 keys | −1.87% [−4.30%, +0.63%] | +1.53% [−0.66%, +3.76%] |
| Scan all keys | +4.08% [+3.60%, +4.56%] | −0.32% [−2.28%, +1.68%] |

The complete switch benefits misses and one-key scans in both lexical patterns,
and full scans of common-prefix data. Point hits remain unresolved, as does
the common-prefix 10,000-key scan change. On dispersed keys, the representation
does not change, so resolved gains come from the read-dispatch configuration.
Turning the feature off does not remove the branch's uncompressed scan overhead
relative to main; that is why the main baseline remains necessary.

## Where the remaining CPU work appears

Instruction counts below are user-mode hardware-counter measurements.

Uncompressed scans, including nonlexical scans, still return keys directly from
pinned pages. They do not allocate a decode buffer or copy each key. Their
long-scan instruction count nevertheless rises about 6.8% versus main. The
candidate adds prefix-aware validation and a prefix test when returning the
current key; generated code also calls an outlined current-entry validator
where main inlines it. Compressed long scans execute about 16.1% more
instructions per key than main. Counter changes support the presence of extra
work, but do not isolate the wall-time cost of an individual check or call.

Packing first writes an uncompressed leaf. Successful prefix compression then
rewrites it into scratch space and copies the page back. Parent-pivot linking
also initializes a key buffer even for uncompressed pivots. Uncompressed
packing executes 1.52% more instructions per key than main. Both versions
already use an outlined append helper; its existence is not a newly introduced
per-tuple call.

[Three independent optimization proposals](proposals/README.md) target rare
blob-validation scratch, unnecessary pivot-buffer initialization, and prefix
qualification before entering the compression rewrite helper. They are
**unapplied, unbuilt and unbenchmarked**. They identify concrete experiments,
not demonstrated fixes or claimed speedups. No validation check should be
removed just to match main's instruction count.

## Controls and limits

The test uses one worker pinned to CPU2, 200,000 tuples, 64-byte keys,
100-byte inline values and a 512 MiB cache on an i7-12800H. Pack input is an
array iterator for all orderings; tuple generation, sorting, output validation
and reclamation are excluded from active time. The complete pack call is
included. Every accepted sample checks exact keys/values, expected read
checksums, zero active I/O and zero major faults. Primary samples ran for
4.809–6.123 seconds of active work each. Runs were serialized under the shared
machine and benchmark locks.

Within-pattern inputs and access orders match across profiles. Key bytes have
different locality across lexical and nonlexical input patterns, so their
absolute pack rates are not a pure comparator comparison. This is one tree
size and tuple shape, without filters, blobs, concurrency or disk-read costs.
The space reduction may help disk workloads, but these resident measurements
do not quantify that benefit or predict whole-database regression magnitudes.

The [final integrity audit](audit.json) passed all six campaigns: 716 accepted
invocations, comprising 516 comparison samples, 134 smoke samples and 66 pilot
samples. The single expected early perf-acknowledgement failure is retained
separately. The audit checked 1,677 file identities and found no errors.
Independent recomputation matched all primary and supplemental paired
estimates. [Final source verification](final-source-state.json) confirms that
all 166 current runtime source files match the measured candidate and that
there are no tracked runtime edits.

See [methods and reproduction](METHODS.md),
[primary machine-readable analysis](primary/summary.json),
[primary raw-run manifest](primary/manifest.json), and
[supplemental raw-run manifest](supplemental/manifest.json), and the
[archive hash index](archive-sha256.json).
