#!/usr/bin/env python3
"""Serialized, fixed-work B-tree experiments. See plan.json for the workload."""
import argparse
import fcntl
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SCRATCH = ROOT / '.cache/btree-prefix-bench'
COORD = Path('/home/rob/projects/splinterdb/.cache/projects-20261011/coordination')
EVENTS = '{cpu_core/cycles/u,cpu_core/instructions/u},task-clock,context-switches,cpu-migrations'


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for data in iter(lambda: stream.read(1048576), b''):
            digest.update(data)
    return digest.hexdigest()


def save(path, value):
    temp = path.with_suffix(path.suffix + '.new')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    temp.replace(path)


def host():
    value = {'time': time.time(), 'loadavg': Path('/proc/loadavg').read_text().strip()}
    for name, path in [('frequency_khz', '/sys/devices/system/cpu/cpu2/cpufreq/scaling_cur_freq'),
                       ('thermal_millic', '/sys/class/thermal/thermal_zone0/temp')]:
        try:
            value[name] = int(Path(path).read_text())
        except (OSError, ValueError):
            pass
    return value


def stop(proc):
    # Reap the whole process group, even if perf exited before its child.
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    proc.wait()


def counters(path):
    result = {}
    for line in path.read_text().splitlines():
        parts = line.split(';')
        if len(parts) < 5 or line.startswith('#'):
            continue
        event = parts[2].strip()
        assert event not in result, f'Duplicate perf event {event}'
        try:
            value, coverage = float(parts[0]), float(parts[4])
            assert math.isfinite(value) and value >= 0
            assert math.isfinite(coverage) and 99 <= coverage <= 100
            result[event] = {'value': value, 'coverage': coverage}
        except ValueError:
            result[event] = {'unavailable': parts[0].strip()}
    for event in ('cpu_core/cycles/u', 'cpu_core/instructions/u', 'task-clock'):
        assert result.get(event, {}).get('value', 0) > 0, f'Missing/invalid {event}'
    return result


def ordered_profiles(profiles, repeat):
    # All six permutations for three modes; AB/BA for two.
    permutations = list(itertools.permutations(profiles))
    return permutations[repeat % len(permutations)]


def main():
    def interrupted(signum, frame):
        raise KeyboardInterrupt(f'signal {signum}')
    signal.signal(signal.SIGTERM, interrupted)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--name', required=True)
    parser.add_argument('--build', type=Path, default=HERE / 'build.json')
    parser.add_argument('--no-perf', action='store_true')
    parser.add_argument('--timeout', type=int, default=900)
    args = parser.parse_args()
    assert args.name.replace('-', '').replace('_', '').isalnum()
    plan = json.loads(args.plan.read_text())
    builds = json.loads(args.build.read_text())
    candidate = 'current' if 'current' in builds else 'highwater'
    folder = HERE / args.name
    folder.mkdir(exist_ok=False)
    SCRATCH.mkdir(exist_ok=True, parents=True)
    save(folder / 'plan.json', plan)
    (folder / 'runner.py').write_bytes(Path(__file__).read_bytes())
    save(folder / 'build.json', builds)
    data = {'complete': False, 'started': time.time(), 'runs': [],
            'plan': plan, 'plan_sha256': sha(folder / 'plan.json'),
            'runner_sha256': sha(__file__), 'build_sha256': sha(args.build),
            'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'host': subprocess.check_output(['lscpu'], text=True),
            'coordination': 'Exclusive benchmark.lock then machine.lock; one child at a time',
            'perf_events': None if args.no_perf else EVENTS}
    save(folder / 'manifest.json', data)
    print('Waiting for exclusive benchmark.lock and machine.lock', flush=True)
    with (COORD / 'benchmark.lock').open('rb') as bench, (COORD / 'machine.lock').open('rb') as machine:
        fcntl.flock(bench, fcntl.LOCK_EX)
        fcntl.flock(machine, fcntl.LOCK_EX)
        for key in ('main', candidate):
            entry = builds[key]
            assert sha(entry['binary']) == entry['binary_sha256'], key
            assert sha(entry['library']) == entry['library_sha256'], key
        cases = plan['cases']
        index = 0
        for repeat in range(plan.get('repeats', 6)):
            # Rotate workloads too; comparison modes remain adjacent within a block.
            rotated = cases[repeat % len(cases):] + cases[:repeat % len(cases)]
            for case in rotated:
                for position, profile in enumerate(ordered_profiles(case['profiles'], repeat)):
                    index += 1
                    label = f'{index:04d}-r{repeat}-{case["name"]}-{profile}'
                    entry = builds['main' if profile == 'main' else candidate]
                    database = SCRATCH / (args.name + '-scratch.db')
                    assert not database.exists(), 'Refusing to replace an existing scratch database'
                    lexical = case['pattern'] != 'nonlexical'
                    pack_on = profile == 'on'
                    read_on = lexical and profile in ('on', 'off')
                    command = [entry['binary'], '--db', str(database), '--operation', case['operation'],
                               '--pattern', case['pattern'], '--compression', 'on' if pack_on else 'off',
                               '--read-lexical', 'on' if read_on else 'off',
                               '--keys', str(plan.get('keys', 200000)),
                               '--key-bytes', str(plan.get('key_bytes', 64)),
                               '--value-bytes', str(plan.get('value_bytes', 100)),
                               '--cache-mib', str(plan.get('cache_mib', 512)),
                               '--disk-mib', str(plan.get('disk_mib', 2048)),
                               '--cpu', str(plan.get('cpu', 2)),
                               '--seed', str(plan.get('seed', 20261015) + repeat),
                               '--ops', str(case.get('ops', 1)), '--batches', str(case.get('batches', 1))]
                    for key in ('scan_length', 'insert_order'):
                        if key in case:
                            command += ['--' + key.replace('_', '-'), str(case[key])]
                    if case.get('miss'):
                        command += ['--miss']
                    env = dict(os.environ)
                    env.pop('PREFIX_PERF_CONTROL', None)
                    env.pop('PREFIX_PERF_ACK', None)
                    control, ack = SCRATCH / (label + '.control'), SCRATCH / (label + '.ack')
                    stat = folder / (label + '.stat')
                    if not args.no_perf:
                        os.mkfifo(control)
                        os.mkfifo(ack)
                        env.update(PREFIX_PERF_CONTROL=str(control), PREFIX_PERF_ACK=str(ack))
                        command = ['perf', 'stat', '-x', ';', '-o', str(stat), '-e', EVENTS,
                                   '-D', '-1', f'--control=fifo:{control},{ack}', '--', *command]
                    record = {'label': label, 'case': case['name'], 'repeat': repeat,
                              'position': position, 'profile': profile, 'command': command,
                              'binary_sha256': entry['binary_sha256'], 'host_start': host()}
                    data['runs'].append(record)
                    save(folder / 'manifest.json', data)
                    print(label, 'running', flush=True)
                    logfile = folder / (label + '.log')
                    try:
                        with logfile.open('w') as log:
                            proc = None
                            try:
                                proc = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log,
                                                        stderr=subprocess.STDOUT, start_new_session=True)
                                code = proc.wait(timeout=args.timeout)
                            finally:
                                if proc is not None:
                                    stop(proc)
                        record.update(returncode=code, host_end=host(), log_sha256=sha(logfile))
                        assert code == 0, f'{label}: exit {code}; see {logfile}'
                        results = [json.loads(line) for line in logfile.read_text().splitlines()
                                   if line.startswith('{') and 'schema_version' in line]
                        assert len(results) == 1, f'{label}: expected one result'
                        result = results[0]
                        record['result'] = result
                        assert result['resident'], f'{label}: measured I/O'
                        assert result['verified'] and result['verified_tuples'] > 0
                        expected = dict(operation=case['operation'], pattern=case['pattern'],
                                        keys=plan.get('keys', 200000),
                                        seed=plan.get('seed', 20261015) + repeat,
                                        batches=case.get('batches', 1),
                                        pack_lexical=pack_on, read_lexical=read_on)
                        for key, value in expected.items():
                            assert result[key] == value, f'{label}: {key} mismatch'
                        assert result['checksum'] == result['expected_checksum'], f'{label}: checksum'
                        assert result['active_wall_ns'] > 0
                        if not args.no_perf:
                            record['perf'] = counters(stat)
                            record['perf_sha256'] = sha(stat)
                            assert all('unavailable' not in v for v in record['perf'].values()), record['perf']
                        print(label, 'done', round(result['active_wall_ns'] / 1e9, 3), 'active seconds', flush=True)
                    except BaseException as error:
                        record['error'] = repr(error)
                        raise
                    finally:
                        save(folder / 'manifest.json', data)
                        for pipe in (control, ack):
                            pipe.unlink(missing_ok=True)
                        # Only our disposable image, and only after its child is reaped.
                        database.unlink(missing_ok=True)
        data.update(complete=True, finished=time.time())
        save(folder / 'manifest.json', data)
    print('Completed', len(data['runs']), 'validated samples', flush=True)


if __name__ == '__main__':
    main()
