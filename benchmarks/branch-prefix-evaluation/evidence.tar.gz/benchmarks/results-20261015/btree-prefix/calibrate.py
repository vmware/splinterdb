#!/usr/bin/env python3
"""Freeze identical per-case work counts from the fastest pilot profile."""
import argparse
import hashlib
import json
import math
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pilot', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--seconds', type=float, default=5.0)
    parser.add_argument('--repeats', type=int, default=6)
    args = parser.parse_args()
    evidence = json.loads(args.pilot.read_text())
    assert evidence['complete'] and args.seconds > 0 and args.repeats > 0
    plan = evidence['plan']
    plan['repeats'] = args.repeats
    details = {}
    for case in plan['cases']:
        runs = [r for r in evidence['runs'] if r['case'] == case['name']]
        assert {r['profile'] for r in runs} == set(case['profiles'])
        assert all(r['result']['resident'] and r['result']['verified'] for r in runs)
        seconds = min(r['result']['active_wall_ns'] / 1e9 / r['result']['batches'] for r in runs)
        batches = max(1, math.ceil(args.seconds / seconds))
        details[case['name']] = dict(fastest_pilot_seconds_per_batch=seconds, batches=batches)
        case['batches'] = batches
    plan['calibration'] = dict(pilot=str(args.pilot.resolve()),
                               pilot_sha256=hashlib.sha256(args.pilot.read_bytes()).hexdigest(),
                               target_active_seconds=args.seconds, method='ceil(target / fastest profile seconds per batch)',
                               details=details)
    with args.output.open('x') as output:
        json.dump(plan, output, indent=2)
        output.write('\n')
    print('Frozen', len(plan['cases']), 'cases;', sum(len(c['profiles']) for c in plan['cases']) * args.repeats, 'samples')


if __name__ == '__main__':
    main()
