#!/usr/bin/env python3
"""Render primary rates and direct paired comparisons from validated summaries."""
import argparse
import json
from pathlib import Path

LABELS = {'insert-random': 'Random inserts', 'insert-sorted': 'Sorted inserts',
          'overwrite': 'Overwrites', 'pack': 'Array-fed pack', 'hit': 'Point hit',
          'miss': 'Point miss', 'scan1': 'Scan 1', 'scan10000': 'Scan 10,000',
          'scanfull': 'Scan full'}


def change(case, comparison, metric):
    value = case['comparisons'].get(comparison, {}).get('metrics', {}).get(metric)
    if not value or value['percent_change'] is None:
        return '—'
    result = f'{value["percent_change"]:+.2f}%'
    if value['ci95_percent'] is not None:
        lo, hi = value['ci95_percent']
        result += f' [{lo:+.2f}, {hi:+.2f}]'
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('summary', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    summary = json.loads(args.summary.read_text())
    lines = ['# Direct B-tree benchmark tables', '',
             'Rates are millions of processed or returned keys/s; point-miss rates are millions of queries/s. '
             'Rates use geometric means across repetitions. Changes are directly paired throughput ratios '
             'with nominal 95% intervals. Positive throughput change is faster. '
             'See [methods](METHODS.md) for scope and statistical limits.', '']
    for pattern, title in [('common', 'Common-prefix lexical keys'),
                           ('random', 'Dispersed lexical keys'),
                           ('nonlexical', 'Nonlexical keys')]:
        lines += ['## ' + title, '',
                  '| Operation | Main M/s | Current uncompressed M/s | Current on M/s | Uncompressed/main | On/off | On/main |',
                  '| --- | ---: | ---: | ---: | --- | --- | --- |']
        for suffix, label in LABELS.items():
            case = summary['cases'][pattern + '-' + suffix]
            metric = 'tuples_s' if case['operation'] in ('scan', 'pack') else 'ops_s'
            profiles = case['profiles']
            off = 'off' if 'off' in profiles else 'current'
            def rate(profile):
                if profile not in profiles:
                    return '—'
                return f'{profiles[profile]["metrics"][metric]["geometric_mean"] / 1e6:.3f}'
            lines.append('| ' + ' | '.join([label, rate('main'), rate(off), rate('on'),
                         change(case, off + '/main', metric), change(case, 'on/off', metric),
                         change(case, 'on/main', metric)]) + ' |')
        lines += ['']
    lines += ['For lexical pack/read cases, current uncompressed means the off profile (pack flag false, read lexical flag true). '
              'Mutable inserts/overwrites and nonlexical cases use the current/main comparison. '
              'The runtime lexical flag does not affect mutable inserts; enabling it is invalid for '
              'the custom nonlexical comparator. These rows therefore have no separate on throughput.', '',
              '## CPU instruction cost', '',
              'User-mode instructions use the same key/query denominator as the throughput table. '
              'Positive instruction change means more work. Phase perf includes small timer/control overhead.', '',
              '| Case | Main instructions/key or query | Uncompressed/main | On/off | On/main |',
              '| --- | ---: | --- | --- | --- |']
    for name, case in summary['cases'].items():
        metric = 'user_instructions_per_tuple' if case['operation'] in ('scan', 'pack') else 'user_instructions_per_operation'
        profiles = case['profiles']
        off = 'off' if 'off' in profiles else 'current'
        base = profiles['main']['metrics'].get(metric, {}).get('geometric_mean')
        lines.append('| ' + ' | '.join([name, f'{base:.2f}' if base else '—',
                     change(case, off + '/main', metric), change(case, 'on/off', metric),
                     change(case, 'on/main', metric)]) + ' |')
    lines += ['', '## Packed output', '',
              'The census below is the first repetition; complete per-repetition census values are in the summary.', '',
              '| Pattern | Profile | Allocated MiB | Leaves | Compressed leaves | Mean prefix among compressed leaves |',
              '| --- | --- | ---: | ---: | ---: | ---: |']
    for pattern in ('common', 'random', 'nonlexical'):
        for profile, values in summary['cases'][pattern + '-pack']['profiles'].items():
            result = values['samples'][0]['result']
            compressed = result['compressed_leaf_count']
            prefix = result['prefix_bytes'] / compressed if compressed else 0
            lines.append(f'| {pattern} | {profile} | {result["packed_bytes"] / 2**20:.3f} | '
                         f'{result["leaf_count"]} | {compressed} | {prefix:.2f} |')
    with args.output.open('x') as output:
        output.write('\n'.join(lines) + '\n')
    print(args.output)


if __name__ == '__main__':
    main()
