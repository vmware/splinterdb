#!/usr/bin/env python3
"""Audit completed B-tree benchmark evidence; never starts a workload.

Run only after the campaign owner authorizes the final audit. The default
campaigns are smoke, smoke-no-perf, smoke-perf, pilot, primary, and supplemental. Additional
named completed campaigns can be supplied as positional arguments. Exclusive
benchmark.lock and machine.lock prevent hashing alongside a measurement.
Inputs are read-only; the requested new JSON output is the only file written.
"""

import argparse
from collections import defaultdict
import fcntl
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import time


HERE = Path(__file__).resolve().parent
COORD = Path('/home/rob/projects/splinterdb/.cache/projects-20261011/coordination')
DEFAULT_CAMPAIGNS = ('smoke', 'smoke-no-perf', 'smoke-perf', 'pilot', 'primary',
                     'supplemental')
KNOWN_COUNTS = {'smoke-no-perf': 67, 'smoke-perf': 67, 'pilot': 66, 'primary': 396,
                'supplemental': 120}
ZERO_FIELDS = ('active_read_bytes', 'active_write_bytes', 'major_faults',
               'io_reads', 'io_writes', 'io_async_reads', 'io_async_writes')
CONFIG_FIELDS = ('operation', 'pattern', 'insert_order', 'keys', 'key_bytes',
                 'value_bytes', 'requested_ops', 'scan_length', 'batches',
                 'seed', 'cache_mib', 'disk_mib', 'cpu', 'miss')
WORK_FIELDS = ('operations', 'tuples', 'returned_tuples', 'processed_tuples',
               'checksum', 'expected_checksum', 'verified_tuples', 'verified_values')


class AuditError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise AuditError(message)


def integer(value, field, positive=False):
    require(type(value) is int and value >= (1 if positive else 0),
            f'{field}: expected a nonnegative/positive integer, got {value!r}')
    return value


def load(path):
    return json.loads(Path(path).read_text())


class Hashes:
    def __init__(self):
        self.files = {}

    def check(self, path, expected, role):
        path = Path(path).resolve()
        name = str(path)
        if name not in self.files:
            before = path.stat()
            digest = hashlib.sha256()
            with path.open('rb') as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(block)
            after = path.stat()
            identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns,
                                   s.st_ctime_ns)
            require(identity(before) == identity(after), f'File changed while hashing: {path}')
            self.files[name] = {'sha256': digest.hexdigest(), 'bytes': after.st_size,
                                'identity': list(identity(after)),
                                'roles': [], 'recorded_hash_checked': False}
        record = self.files[name]
        now = path.stat()
        require(record['identity'] == [now.st_dev, now.st_ino, now.st_size,
                                       now.st_mtime_ns, now.st_ctime_ns],
                f'Previously hashed file changed during audit: {path}')
        if role not in record['roles']:
            record['roles'].append(role)
        if expected is not None:
            require(record['sha256'] == expected, f'Hash mismatch: {path} ({role})')
            record['recorded_hash_checked'] = True
        return record['sha256']


def parse_perf(path):
    events = {}
    for line in path.read_text().splitlines():
        parts = line.split(';')
        if len(parts) < 5 or line.startswith('#'):
            continue
        event = parts[2].strip()
        require(event not in events, f'Duplicate perf event: {event}')
        value, coverage = float(parts[0]), float(parts[4])
        require(math.isfinite(value) and value >= 0, f'Invalid perf value: {event}')
        require(math.isfinite(coverage) and 99 <= coverage <= 100,
                f'Invalid/low perf coverage: {event}: {coverage}')
        events[event] = {'value': value, 'coverage': coverage}
    for event in ('cpu_core/cycles/u', 'cpu_core/instructions/u', 'task-clock'):
        require(events.get(event, {}).get('value', 0) > 0,
                f'Missing positive counter: {event}')
    return events


def expected_runs(plan):
    cases = plan['cases']
    require(cases and len({c['name'] for c in cases}) == len(cases),
            'Missing or duplicate planned cases')
    repeats = integer(plan.get('repeats', 6), 'plan/repeats', True)
    rows = []
    for repeat in range(repeats):
        rotated = cases[repeat % len(cases):] + cases[:repeat % len(cases)]
        for case in rotated:
            profiles = case['profiles']
            require(profiles and len(set(profiles)) == len(profiles),
                    f'Duplicate/empty profile list: {case["name"]}')
            order = list(itertools.permutations(profiles))
            for position, profile in enumerate(order[repeat % len(order)]):
                rows.append((case, repeat, position, profile))
    return rows


def expected_config(plan, case, repeat, profile, build):
    keys = plan.get('keys', 200000)
    length = case.get('scan_length', 10000)
    if length == 'full':
        length = keys
    config = dict(operation=case['operation'], pattern=case['pattern'],
                  insert_order=case.get('insert_order', 'random'), keys=keys,
                  key_bytes=plan.get('key_bytes', 64),
                  value_bytes=plan.get('value_bytes', 100),
                  requested_ops=case.get('ops', 1), scan_length=length,
                  batches=case.get('batches', 1),
                  seed=plan.get('seed', 20261015) + repeat,
                  cache_mib=plan.get('cache_mib', 512),
                  disk_mib=plan.get('disk_mib', 2048), cpu=plan.get('cpu', 2),
                  miss=case.get('miss', False),
                  prefix_supported=build['prefix_supported'],
                  pack_lexical=profile == 'on',
                  read_lexical=case['pattern'] != 'nonlexical' and profile in ('on', 'off'))
    if case['pattern'] == 'nonlexical':
        require(not config['pack_lexical'] and not config['read_lexical'],
                'Nonlexical workload cannot opt into lexical behavior')
    return config


def validate_result(result, config):
    require(result.get('schema_version') == 1, 'Unknown result schema')
    require(result.get('verified') is True and result.get('resident') is True,
            'Run is not verified and resident')
    for field, expected in config.items():
        require(result[field] == expected, f'Result config mismatch: {field}')
    for field in ZERO_FIELDS:
        require(integer(result[field], field) == 0, f'Nonzero resident {field}')
    for field in ('active_wall_ns', 'process_cpu_ns', 'verified_tuples', 'verified_values'):
        integer(result[field], field, True)
    for field in ('checksum', 'expected_checksum'):
        integer(result[field], field)
    require(result['checksum'] == result['expected_checksum'], 'Checksum mismatch')
    require(result['verified_tuples'] == result['verified_values'],
            'Full-key and value verification counts differ')
    keys, batches, operation = config['keys'], config['batches'], config['operation']
    returned = processed = 0
    if operation in ('insert', 'overwrite'):
        ops = processed = keys * batches
    elif operation == 'pack':
        ops, processed = batches, keys * batches
    elif operation in ('lookup', 'scan'):
        ops = config['requested_ops'] * batches
        returned = (ops * config['scan_length'] if operation == 'scan'
                    else (0 if config['miss'] else ops))
    else:
        raise AuditError('Unsupported operation: ' + operation)
    for field, expected in dict(operations=ops, returned_tuples=returned,
                                processed_tuples=processed, tuples=returned+processed).items():
        require(integer(result[field], field) == expected, f'Incorrect work units: {field}')
    for field in ('packed_bytes', 'leaf_count', 'compressed_leaf_count', 'prefix_bytes'):
        integer(result[field], field)
    require(result['compressed_leaf_count'] <= result['leaf_count'], 'Invalid leaf census')
    if not config['pack_lexical'] or operation in ('insert', 'overwrite'):
        require(result['compressed_leaf_count'] == result['prefix_bytes'] == 0,
                'Unexpected compression in uncompressed or mutable workload')


def validate_command(run, config, build, folder, manifest):
    command = run['command']
    require(isinstance(command, list) and command
            and all(isinstance(v, str) for v in command),
            'Command is not an argv list')
    perf = manifest['perf_events'] is not None
    if perf:
        require(command[0] == 'perf' and command[1] == 'stat', 'Missing perf wrapper')
        require(command[command.index('-e')+1] == manifest['perf_events'], 'Perf event mismatch')
        require(command[command.index('-D')+1] == '-1', 'Perf must start disabled')
        require(Path(command[command.index('-o')+1]).resolve()
                == (folder / (run['label'] + '.stat')).resolve(), 'Perf output mismatch')
        command = command[command.index('--')+1:]
    require(Path(command[0]).resolve() == Path(build['binary']).resolve(), 'Binary argv mismatch')
    options, i = {}, 1
    while i < len(command):
        option = command[i]
        require(option.startswith('--') and option not in options, 'Duplicate/invalid argv option')
        if option == '--miss':
            options[option] = True
            i += 1
        else:
            require(i+1 < len(command), 'Missing argv option value')
            options[option] = command[i+1]
            i += 2
    expected = {
        '--operation': config['operation'], '--pattern': config['pattern'],
        '--compression': 'on' if config['pack_lexical'] else 'off',
        '--read-lexical': 'on' if config['read_lexical'] else 'off',
        '--keys': str(config['keys']), '--key-bytes': str(config['key_bytes']),
        '--value-bytes': str(config['value_bytes']), '--ops': str(config['requested_ops']),
        '--batches': str(config['batches']), '--seed': str(config['seed']),
        '--cache-mib': str(config['cache_mib']), '--disk-mib': str(config['disk_mib']),
        '--cpu': str(config['cpu']),
    }
    for key, value in expected.items():
        require(options.get(key) == value, f'Command config mismatch: {key}')
    require(options.get('--miss', False) == config['miss'], 'Miss argv mismatch')
    require(options.get('--insert-order', 'random') == config['insert_order'], 'Insert-order argv mismatch')
    length = options.get('--scan-length', '10000')
    require((config['keys'] if length == 'full' else int(length)) == config['scan_length'],
            'Scan length argv mismatch')
    allowed = set(expected) | {'--db', '--miss', '--insert-order', '--scan-length'}
    require(set(options) <= allowed and '--db' in options, 'Unexpected/unsafe benchmark option')
    require(Path(options['--db']).name == folder.name + '-scratch.db', 'Scratch image name mismatch')


def audit_builds(builds, hashes):
    entries = {k: v for k, v in builds.items() if not k.startswith('_')}
    require('main' in entries and ('current' in entries or 'highwater' in entries),
            'Missing main/current build metadata')
    require(len({v['source_sha256'] for v in entries.values()}) == 1,
            'Profiles were built from different harness source')
    for name, build in entries.items():
        for field in ('binary', 'library', 'source', 'build_log'):
            path = Path(build[field])
            if field == 'source':
                require(path.resolve().is_relative_to(HERE), 'Harness is not an archive source')
            hashes.check(path, build[field + '_sha256'], name + '/' + field)
        for filename, expected in build['source_files_sha256'].items():
            hashes.check(Path(build['tree']) / filename, expected, name + '/runtime-source')
    metadata = builds['_build']
    require(metadata['runtime_sources_unchanged'] is True, 'Build changed runtime sources')
    hashes.check(metadata['runner'], metadata['runner_sha256'], 'build-runner')
    hashes.check(metadata['input_metadata'], metadata['input_metadata_sha256'], 'build-input')


def audit_campaign(name, hashes):
    folder = HERE / name
    manifest = load(folder / 'manifest.json')
    expected_failure = name == 'smoke'
    require(manifest.get('complete') is (not expected_failure),
            'Unexpected campaign completion state')
    plan = load(folder / 'plan.json')
    require(plan == manifest['plan'], 'Embedded and archived plans differ')
    hashes.check(folder / 'manifest.json', None, 'campaign-manifest')
    for file, field in (('plan.json', 'plan_sha256'), ('runner.py', 'runner_sha256'),
                        ('build.json', 'build_sha256')):
        hashes.check(folder / file, manifest[field], 'campaign-' + file)
    builds = load(folder / 'build.json')
    audit_builds(builds, hashes)
    candidate = 'current' if 'current' in builds else 'highwater'
    expected = expected_runs(plan)
    runs = manifest['runs']
    require(len(runs) == (1 if expected_failure else len(expected)), 'Run count differs from plan')
    if name in KNOWN_COUNTS:
        require(len(runs) == KNOWN_COUNTS[name], 'Known campaign run count changed')
    groups = defaultdict(list)
    limitations, minimum_coverage = [], []
    for index, (run, (case, repeat, position, profile)) in enumerate(zip(runs, expected), 1):
        label = f'{index:04d}-r{repeat}-{case["name"]}-{profile}'
        require((run['label'], run['case'], run['repeat'], run['position'], run['profile'])
                == (label, case['name'], repeat, position, profile), 'Run order/identity mismatch')
        build = builds['main' if profile == 'main' else candidate]
        require(run['binary_sha256'] == build['binary_sha256'], 'Recorded run binary mismatch')
        config = expected_config(plan, case, repeat, profile, build)
        validate_command(run, config, build, folder, manifest)
        log = folder / (label + '.log')
        hashes.check(log, run['log_sha256'], 'run-log')
        text = log.read_text()
        records = [json.loads(line) for line in text.splitlines()
                   if line.startswith('{') and 'schema_version' in line]
        stat = folder / (label + '.stat')
        if expected_failure:
            require(run.get('returncode') == 1 and run.get('error'), 'Expected smoke failure missing')
            require('btree_prefix_bench: perf control acknowledgement failed' in text,
                    'Smoke failed for an unexpected reason')
            require(not records and 'result' not in run, 'Failed smoke supplied a result')
            hashes.check(stat, None, 'expected-failure-perf-observed-only')
            limitations.append('Failed smoke perf file has no original recorded hash; current hash is catalogued only.')
            continue
        require(run.get('returncode') == 0 and not run.get('error'), 'Failed successful-campaign run')
        require(len(records) == 1 and records[0] == run['result'], 'Log/manifest result mismatch')
        result = records[0]
        validate_result(result, config)
        groups[case['name'], repeat].append(result)
        if manifest['perf_events'] is not None:
            hashes.check(stat, run['perf_sha256'], 'run-perf')
            counters = parse_perf(stat)
            require(counters == run['perf'], 'Raw/manifest perf mismatch')
            minimum_coverage.extend(v['coverage'] for v in counters.values())
        else:
            require(not stat.exists() and not run.get('perf'), 'Unexpected perf in no-perf campaign')
    if not expected_failure:
        for group, results in groups.items():
            reference = {k: results[0][k] for k in CONFIG_FIELDS + WORK_FIELDS}
            require(all({k: r[k] for k in reference} == reference for r in results[1:]),
                    f'Profiles used different logical work/configuration: {group}')
    expected_logs = {r['label'] + '.log' for r in runs}
    expected_stats = ({r['label'] + '.stat' for r in runs}
                      if manifest['perf_events'] is not None else set())
    require({p.name for p in folder.glob('*.log')} == expected_logs, 'Unrecorded/missing log files')
    require({p.name for p in folder.glob('*.stat')} == expected_stats, 'Unrecorded/missing perf files')
    return {
        'name': name, 'passed': True, 'complete': manifest['complete'],
        'runs': len(runs), 'validated_runs': 0 if expected_failure else len(runs),
        'expected_failed_runs': 1 if expected_failure else 0,
        'cases': len(plan['cases']), 'repeats': plan.get('repeats', 6),
        'paired_groups_checked': len(groups),
        'minimum_counter_coverage_percent': min(minimum_coverage) if minimum_coverage else None,
        'manifest_sha256': hashes.check(folder / 'manifest.json', None, 'campaign-manifest'),
        'provenance_limitations': limitations,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('campaigns', nargs='*', default=list(DEFAULT_CAMPAIGNS))
    parser.add_argument('--output', type=Path, default=HERE / 'audit.json')
    args = parser.parse_args()
    require(not args.output.exists(), 'Refusing to overwrite an existing audit')
    require(len(set(args.campaigns)) == len(args.campaigns), 'Duplicate campaign arguments')
    for name in args.campaigns:
        require(name.replace('-', '').replace('_', '').isalnum(), 'Invalid campaign name')
    report = {'schema_version': 1, 'started': time.time(), 'campaigns': [], 'errors': [],
              'coordination': 'Exclusive benchmark.lock then machine.lock; no workloads launched',
              'scope': 'Plans, source/artifact identities, result integrity, work units, resident guards, paired work, and raw perf; no performance significance claim',
              'paired_config_fields': list(CONFIG_FIELDS),
              'paired_work_fields': list(WORK_FIELDS),
              'paired_exceptions': 'Pack/read lexical flags and prefix-support capability are checked against each profile/build instead of requiring equality. Timing, counters, and physical tree census are outcomes, not paired logical-work invariants.'}
    hashes = Hashes()
    try:
        os.sched_setaffinity(0, {19})
    except OSError as error:
        report['affinity_note'] = str(error)
    print('Waiting for exclusive benchmark.lock and machine.lock', flush=True)
    with (COORD / 'benchmark.lock').open('rb') as bench, (COORD / 'machine.lock').open('rb') as machine:
        fcntl.flock(bench, fcntl.LOCK_EX)
        fcntl.flock(machine, fcntl.LOCK_EX)
        for name in args.campaigns:
            try:
                report['campaigns'].append(audit_campaign(name, hashes))
            except (AuditError, OSError, KeyError, TypeError, ValueError, IndexError,
                    OverflowError) as error:
                report['errors'].append({'campaign': name, 'error': repr(error)})
        report.update(finished=time.time(), passed=not report['errors'], files=hashes.files)
        report['counts'] = {
            'campaigns_requested': len(args.campaigns),
            'campaigns_passed': len(report['campaigns']),
            'validated_runs': sum(c['validated_runs'] for c in report['campaigns']),
            'expected_failed_runs': sum(c['expected_failed_runs'] for c in report['campaigns']),
            'unique_files_hashed': len(hashes.files),
        }
        report['auditor_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        with args.output.open('x') as stream:
            json.dump(report, stream, indent=2, allow_nan=False)
            stream.write('\n')
    print(json.dumps({'output': str(args.output), 'passed': report['passed'],
                      'counts': report['counts'], 'errors': report['errors']}, indent=2))
    raise SystemExit(0 if report['passed'] else 1)


if __name__ == '__main__':
    main()
