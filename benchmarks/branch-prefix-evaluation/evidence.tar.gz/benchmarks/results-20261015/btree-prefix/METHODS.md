# Resident B-tree prefix experiment

This experiment isolates B-tree operations from SplinterDB's trunk, compaction,
WAL, task scheduler and database iterator. The campaign compares the candidate
at `b9cc3ea4` with the frozen main baseline
`6105c49f66a24d3006ba0464d9558b52e692e27c`. Candidate production sources match the
previously validated highwater build. No runtime source is changed by this
benchmark.

## Workloads

Each process constructs a deterministic 200,000-tuple input: 64-byte keys and
100-byte inline values. Input bytes, tuple descriptors, insertion permutations,
miss keys and query order are prepared before timing. A single worker runs on
CPU2 of an Intel Core i7-12800H. The cache is 512 MiB, with a 2 GiB address space
backed by a disposable file on the workspace filesystem. This is a cache
budget, not a total-process memory cap.

| Pattern | Ordering | Key construction |
| --- | --- | --- |
| Common | Lexical | 48 fixed leading bytes, mixed unique 64-bit word, trailing ID |
| Random | Lexical | Mixed unique 64-bit leading word, dispersed remaining bytes, trailing ID |
| Nonlexical | Custom comparator | Dispersed leading bytes; compare only trailing 8-byte IDs |

Keys for hits and misses are interleaved in sorted order. The same input and
operation stream are used for every profile within a repetition. The seed
changes between repetitions. The actual compressed-leaf census is recorded;
enabling compression does not imply that a leaf qualifies for compression.

The tuple-descriptor and value arrays are sorted and contiguous. Key bytes stay
in their original generation arena: common/random lexical patterns share the
same scattered key-pointer permutation, while nonlexical selected keys have a
regular 128-byte stride. This removes input-iterator computation but does not
equalize input memory locality across all patterns. Thus absolute lexical versus
nonlexical packing rates must not be attributed solely to the comparator or
prefix policy. Within-pattern main/off/on inputs and memory access orders match;
those are the comparisons used for conclusions.

The cases are random fresh insertion, sorted fresh insertion, fixed-size
overwrite, array-fed packing, point hits, point misses, one-key scans,
10,000-key scans, and full 200,000-key scans. Insertions use mutable memtable
B-trees. Reads use packed immutable B-trees. All scan measurements include
iterator initialization and teardown, and consume both key and value bytes.

## Profiles and comparisons

| Profile | Runtime library | Packing lexical flag | Reading lexical flag |
| --- | --- | --- | --- |
| main | Frozen main | Unsupported | Unsupported |
| off | Candidate | False | True |
| on | Candidate | True | True |
| current | Candidate | False | False |
| callback | Candidate, lexical input | False | False |

The callback comparator is identical across profiles for each key pattern.
For lexical reads, `on/off` isolates the compressed representation while holding
lexical comparison eligibility constant. `off/main` measures candidate support
and comparison-dispatch changes without compression. `on/main` measures their
combined effect. For packing, only the construction flag affects timed work;
the reading flag is applied later for verification.

A separate six-repetition supplemental campaign compares `on/callback` for
every lexical read case. This directly measures the full runtime switch,
including both representation and comparison-dispatch changes. It inherits the
primary fixed work counts and uses adjacent AB/BA pairs. Its ratios are analyzed
within that campaign; they are not chained with primary ratios or pooled with
them. This adds 120 read samples to the 396-sample primary matrix.

Nonlexical ordering cannot truthfully enable the lexical flag. Those cases use
`current/main`. Mutable insertion ignores this flag and always writes full
keys, so the main comparison measures insertion overhead from supporting the
feature. A flag-enabled mutable insertion is also checked in the smoke suite.

## Timing boundaries

Every pack receives an array iterator whose current operation copies two
descriptors and whose next operation increments an index. It does no key
reconstruction, allocation, merging, or B-tree traversal. Array generation and
sorting are excluded. The complete `btree_pack()` call is timed, including root
finalization and its allocator release. Request initialization/deinitialization,
output validation and tree reclamation are excluded. One output is live at a
time. Optional filter fingerprints are disabled, and all values are inline.
Pack completion does not imply persistence or flushing.

Insertion timing covers the `btree_insert()` loop. Creation, overwrite prefill,
verification and reclamation are excluded. A separate unmeasured first tree
warms the insertion/packing path. Reads receive a full verified warm replay,
fixed repeated timed batches, another verified replay, and final full-tree
verification. Their timings include small status/shape checks and a checksum.

`active_wall_ns` and `process_cpu_ns` directly bracket active calls. Hardware
counters are enabled/disabled around each active interval, excluding validation,
reclamation and resource snapshots. They include timer and FIFO handshake
overhead around the direct clock bracket. Broader getrusage snapshots include
handshake and snapshot overhead; process CPU is the preferred CPU measure.

## Residency and correctness

Cache data and metadata are prefaulted. Pending I/O is drained before each
interval. Every accepted interval must have zero process read/write bytes,
zero major faults, and zero intercepted synchronous reads/writes or asynchronous
I/O starts. The cache's optional statistics are disabled; their zero counters
are not used as residency evidence. Minor faults are recorded separately.

Validation compares every key and every value byte and checks exact tree
exhaustion after the expected tuple count. Measured reads compare their digest
with an independently calculated expected digest. Overwrites use different
replacement bytes and verify the resulting contents. Packed-tree size and leaf
prefix counts are inspected outside timing.

## Scheduling and analysis

All workload processes are serialized under the shared exclusive
`benchmark.lock` and `machine.lock`. Builds also use `machine.lock` and isolated
temporary directories. The runner reaps its process group before releasing
locks or removing its owned scratch file. It does not change CPU governors or
drop caches.

A separate pilot sets fixed batch counts from the fastest profile in each case,
targeting at least five seconds of aggregate active work under pilot conditions.
All profiles then perform the same fixed work. The primary campaign runs six
repetitions: all six orders for three profiles and alternating AB/BA for two.
Case order rotates between repetitions. Actual sample durations are retained;
calibration is not a runtime stopping condition.

Comparisons use geometric means of within-repetition throughput ratios. Nominal
95% intervals use Student-t on paired log ratios, with five degrees of freedom
for six repetitions. These are small-sample observational intervals, not
equivalence guarantees or simultaneous confidence statements. No cases are
pooled. Hardware instructions and cycles supplement wall-clock observations.

This experiment covers one thread, one tree size, fixed-size inline tuples,
resident synchronous queries, and bounded/full forward scans. It does not
measure disk savings in throughput, concurrent insertion, asynchronous queries,
blobs, reverse scans, variable key lengths, or end-to-end database performance.

## Reproduction and evidence

The reusable source is [btree_prefix_bench.c](../../btree_prefix_bench.c).
The [build helper](../../build_btree_prefix_bench.py) links identical harness
source against each frozen runtime's own private headers and library. Compiler
commands, exact source snapshots, source/library/binary hashes, and build logs
are retained in [build-v2/build.json](build-v2/build.json).

```sh
python3 benchmarks/results-20261015/btree-prefix/runner.py \
  --plan benchmarks/results-20261015/btree-prefix/primary-plan.json \
  --name repeat-primary \
  --build benchmarks/results-20261015/btree-prefix/build-v2/build.json
python3 benchmarks/results-20261015/btree-prefix/analyze.py \
  benchmarks/results-20261015/btree-prefix/repeat-primary/manifest.json \
  benchmarks/results-20261015/btree-prefix/repeat-primary/summary.json
```

The runner refuses existing campaign directories and scratch images. It checks
the binary/library hashes before starting. Each raw log and perf file has a
manifest hash. Smoke and pilot samples are validation/calibration evidence and
are not pooled with the primary timings.

An initial perf smoke failed because this installed perf writes `ack\n\0`,
while the first harness expected repeated `ack\n` lines. The bounded raw FIFO
probe and failed run are preserved. Version2 changes only the acknowledgement
parser and passed the complete perf smoke suite. An earlier build attempt also
stopped before compilation because it tried to open the shared lock for writing;
the build helper now opens that existing file read-only for `flock`.
