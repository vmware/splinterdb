# Full runtime-switch read comparison

This separate six-pair campaign compares candidate packing/read lexical flags both enabled (`on`) with both disabled (`callback`). The callback still implements the same lexical ordering. Positive throughput change is faster; positive user-mode instruction change is more work. These direct ratios are not chained with or pooled into the primary campaign.

Rates are geometric means in millions of returned keys/s, except point misses, which use millions of queries/s. Intervals are nominal paired 95% Student-t intervals; see [methods](METHODS.md).

| Pattern | Operation | Disabled M/s | Enabled M/s | Enabled/disabled throughput | Instructions per key/query |
| --- | --- | ---: | ---: | --- | --- |
| common | Point hit | 1.079 | 1.111 | +2.96% [-2.92, +9.21] | -3.32% [-3.33, -3.31] |
| common | Point miss | 1.090 | 1.170 | +7.29% [+5.23, +9.39] | -4.64% [-4.64, -4.63] |
| common | Scan 1 | 0.904 | 0.967 | +6.90% [+4.74, +9.11] | +3.87% [+3.86, +3.89] |
| common | Scan 10,000 | 53.855 | 52.849 | -1.87% [-4.30, +0.63] | +8.74% [+8.74, +8.74] |
| common | Scan full | 52.604 | 54.749 | +4.08% [+3.60, +4.56] | +8.74% [+8.74, +8.74] |
| random | Point hit | 1.153 | 1.163 | +0.90% [-1.21, +3.06] | -4.34% [-4.34, -4.34] |
| random | Point miss | 1.173 | 1.214 | +3.48% [+0.41, +6.65] | -5.47% [-5.47, -5.46] |
| random | Scan 1 | 0.951 | 1.015 | +6.80% [+4.17, +9.49] | -3.06% [-3.06, -3.06] |
| random | Scan 10,000 | 53.519 | 54.338 | +1.53% [-0.66, +3.76] | -0.01% [-0.01, -0.01] |
| random | Scan full | 52.360 | 52.193 | -0.32% [-2.28, +1.68] | -0.00% [-0.00, -0.00] |

Raw evidence: [manifest](supplemental/manifest.json), [machine-readable analysis](supplemental/summary.json).
