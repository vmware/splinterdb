# Direct B-tree benchmark tables

Rates are millions of processed or returned keys/s; point-miss rates are millions of queries/s. Rates use geometric means across repetitions. Changes are directly paired throughput ratios with nominal 95% intervals. Positive throughput change is faster. See [methods](METHODS.md) for scope and statistical limits.

## Common-prefix lexical keys

| Operation | Main M/s | Current uncompressed M/s | Current on M/s | Uncompressed/main | On/off | On/main |
| --- | ---: | ---: | ---: | --- | --- | --- |
| Random inserts | 0.907 | 0.914 | — | +0.79% [-0.44, +2.04] | — | — |
| Sorted inserts | 1.772 | 1.747 | — | -1.42% [-3.11, +0.31] | — | — |
| Overwrites | 0.908 | 0.911 | — | +0.25% [-0.51, +1.01] | — | — |
| Array-fed pack | 15.806 | 15.760 | 14.481 | -0.29% [-1.99, +1.43] | -8.11% [-10.15, -6.03] | -8.38% [-10.49, -6.22] |
| Point hit | 1.095 | 1.081 | 1.128 | -1.27% [-6.05, +3.75] | +4.35% [-0.42, +9.35] | +3.03% [+1.77, +4.30] |
| Point miss | 1.107 | 1.168 | 1.173 | +5.55% [+4.36, +6.76] | +0.47% [-1.60, +2.57] | +6.05% [+4.63, +7.48] |
| Scan 1 | 0.923 | 0.969 | 0.968 | +4.95% [+4.36, +5.54] | -0.09% [-1.28, +1.12] | +4.86% [+3.86, +5.86] |
| Scan 10,000 | 57.374 | 55.170 | 53.829 | -3.84% [-5.45, -2.21] | -2.43% [-3.62, -1.22] | -6.18% [-7.68, -4.65] |
| Scan full | 54.924 | 53.051 | 55.415 | -3.41% [-5.44, -1.34] | +4.46% [+3.27, +5.65] | +0.89% [-1.48, +3.32] |

## Dispersed lexical keys

| Operation | Main M/s | Current uncompressed M/s | Current on M/s | Uncompressed/main | On/off | On/main |
| --- | ---: | ---: | ---: | --- | --- | --- |
| Random inserts | 0.967 | 0.973 | — | +0.62% [-0.46, +1.72] | — | — |
| Sorted inserts | 1.928 | 1.918 | — | -0.50% [-2.01, +1.04] | — | — |
| Overwrites | 0.949 | 0.961 | — | +1.26% [-0.46, +3.01] | — | — |
| Array-fed pack | 15.650 | 15.353 | 15.686 | -1.89% [-4.30, +0.57] | +2.17% [+0.67, +3.69] | +0.23% [-1.21, +1.70] |
| Point hit | 1.152 | 1.165 | 1.159 | +1.11% [-0.91, +3.17] | -0.54% [-2.83, +1.81] | +0.56% [-2.01, +3.20] |
| Point miss | 1.180 | 1.236 | 1.229 | +4.72% [+2.63, +6.86] | -0.55% [-1.87, +0.77] | +4.14% [+1.88, +6.45] |
| Scan 1 | 0.968 | 1.026 | 1.019 | +5.93% [+4.82, +7.06] | -0.60% [-1.49, +0.30] | +5.29% [+3.74, +6.87] |
| Scan 10,000 | 56.976 | 54.807 | 54.917 | -3.81% [-5.82, -1.74] | +0.20% [-1.62, +2.05] | -3.61% [-4.99, -2.22] |
| Scan full | 55.074 | 52.469 | 52.727 | -4.73% [-5.63, -3.82] | +0.49% [-0.80, +1.80] | -4.26% [-5.07, -3.44] |

## Nonlexical keys

| Operation | Main M/s | Current uncompressed M/s | Current on M/s | Uncompressed/main | On/off | On/main |
| --- | ---: | ---: | ---: | --- | --- | --- |
| Random inserts | 0.941 | 0.938 | — | -0.28% [-2.25, +1.73] | — | — |
| Sorted inserts | 2.128 | 2.145 | — | +0.82% [-0.61, +2.28] | — | — |
| Overwrites | 0.928 | 0.926 | — | -0.26% [-2.15, +1.67] | — | — |
| Array-fed pack | 24.940 | 25.066 | — | +0.51% [-4.07, +5.30] | — | — |
| Point hit | 1.131 | 1.110 | — | -1.84% [-2.45, -1.23] | — | — |
| Point miss | 1.131 | 1.106 | — | -2.16% [-4.44, +0.18] | — | — |
| Scan 1 | 0.937 | 0.921 | — | -1.72% [-4.45, +1.09] | — | — |
| Scan 10,000 | 57.136 | 54.502 | — | -4.61% [-5.58, -3.63] | — | — |
| Scan full | 53.914 | 52.593 | — | -2.45% [-5.15, +0.32] | — | — |

For lexical pack/read cases, current uncompressed means the off profile (pack flag false, read lexical flag true). Mutable inserts/overwrites and nonlexical cases use the current/main comparison. The runtime lexical flag does not affect mutable inserts; enabling it is invalid for the custom nonlexical comparator. These rows therefore have no separate on throughput.

## CPU instruction cost

User-mode instructions use the same key/query denominator as the throughput table. Positive instruction change means more work. Phase perf includes small timer/control overhead.

| Case | Main instructions/key or query | Uncompressed/main | On/off | On/main |
| --- | ---: | --- | --- | --- |
| common-insert-random | 3222.63 | -0.01% [-0.01, -0.01] | — | — |
| common-insert-sorted | 3183.14 | -0.01% [-0.01, -0.01] | — | — |
| common-overwrite | 3215.31 | -0.00% [-0.00, +0.00] | — | — |
| common-pack | 318.27 | +1.52% [+1.52, +1.52] | +30.35% [+30.35, +30.35] | +32.33% [+32.33, +32.33] |
| common-hit | 3290.15 | +0.53% [+0.53, +0.53] | +0.89% [+0.88, +0.90] | +1.42% [+1.42, +1.43] |
| common-miss | 3223.44 | -0.56% [-0.56, -0.56] | +0.62% [+0.61, +0.63] | +0.06% [+0.05, +0.07] |
| common-scan1 | 4575.97 | +2.68% [+2.67, +2.68] | +7.06% [+7.05, +7.07] | +9.93% [+9.91, +9.94] |
| common-scan10000 | 223.48 | +6.79% [+6.79, +6.79] | +8.74% [+8.74, +8.74] | +16.13% [+16.13, +16.13] |
| common-scanfull | 223.07 | +6.80% [+6.80, +6.80] | +8.74% [+8.74, +8.74] | +16.14% [+16.14, +16.14] |
| random-insert-random | 3088.55 | -0.01% [-0.01, -0.01] | — | — |
| random-insert-sorted | 3053.44 | -0.01% [-0.01, -0.01] | — | — |
| random-overwrite | 3084.89 | -0.00% [-0.00, -0.00] | — | — |
| random-pack | 318.27 | +1.52% [+1.52, +1.52] | +0.62% [+0.62, +0.62] | +2.14% [+2.14, +2.14] |
| random-hit | 3157.57 | +0.55% [+0.55, +0.56] | +0.00% [-0.00, +0.00] | +0.55% [+0.55, +0.56] |
| random-miss | 3075.94 | -0.59% [-0.59, -0.59] | +0.00% [-0.00, +0.00] | -0.59% [-0.59, -0.59] |
| random-scan1 | 4443.41 | +2.76% [+2.75, +2.76] | +0.00% [-0.00, +0.00] | +2.76% [+2.75, +2.76] |
| random-scan10000 | 223.47 | +6.79% [+6.79, +6.80] | -0.00% [-0.00, +0.00] | +6.79% [+6.79, +6.80] |
| random-scanfull | 223.07 | +6.80% [+6.80, +6.80] | -0.00% [-0.00, +0.00] | +6.80% [+6.80, +6.80] |
| nonlexical-insert-random | 3102.34 | -0.01% [-0.01, -0.01] | — | — |
| nonlexical-insert-sorted | 3068.29 | -0.01% [-0.01, -0.01] | — | — |
| nonlexical-overwrite | 3089.32 | -0.00% [-0.00, +0.00] | — | — |
| nonlexical-pack | 318.27 | +1.52% [+1.52, +1.52] | — | — |
| nonlexical-hit | 3163.02 | +5.11% [+5.11, +5.11] | — | — |
| nonlexical-miss | 3093.08 | +5.13% [+5.13, +5.13] | — | — |
| nonlexical-scan1 | 4448.85 | +5.99% [+5.99, +5.99] | — | — |
| nonlexical-scan10000 | 223.47 | +6.80% [+6.80, +6.80] | — | — |
| nonlexical-scanfull | 223.07 | +6.80% [+6.80, +6.80] | — | — |

## Packed output

The census below is the first repetition; complete per-repetition census values are in the summary.

| Pattern | Profile | Allocated MiB | Leaves | Compressed leaves | Mean prefix among compressed leaves |
| --- | --- | ---: | ---: | ---: | ---: |
| common | main | 35.129 | 8696 | 0 | 0.00 |
| common | off | 35.129 | 8696 | 0 | 0.00 |
| common | on | 25.379 | 6261 | 6260 | 48.97 |
| random | main | 35.129 | 8696 | 0 | 0.00 |
| random | off | 35.129 | 8696 | 0 | 0.00 |
| random | on | 35.129 | 8696 | 0 | 0.00 |
| nonlexical | main | 35.129 | 8696 | 0 | 0.00 |
| nonlexical | current | 35.129 | 8696 | 0 | 0.00 |
