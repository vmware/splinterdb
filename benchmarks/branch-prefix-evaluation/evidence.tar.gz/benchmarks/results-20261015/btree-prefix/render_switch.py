#!/usr/bin/env python3
"""Render the separate, paired full runtime-switch read comparison."""
import argparse
import json
from pathlib import Path

from render_tables import LABELS, change


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('summary', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    summary = json.loads(args.summary.read_text())
    lines = [
        '# Full runtime-switch read comparison', '',
        'This separate six-pair campaign compares candidate packing/read lexical '
        'flags both enabled (`on`) with both disabled (`callback`). The callback '
        'still implements the same lexical ordering. Positive throughput change '
        'is faster; positive user-mode instruction change is more work. These direct ratios '
        'are not chained with or pooled into the primary campaign.', '',
        'Rates are geometric means in millions of returned keys/s, except point '
        'misses, which use millions of queries/s. Intervals are nominal paired '
        '95% Student-t intervals; see [methods](METHODS.md).', '',
        '| Pattern | Operation | Disabled M/s | Enabled M/s | Enabled/disabled throughput | Instructions per key/query |',
        '| --- | --- | ---: | ---: | --- | --- |',
    ]
    for name, case in summary['cases'].items():
        pattern, operation = name.split('-', 1)
        metric = 'tuples_s' if case['operation'] == 'scan' else 'ops_s'
        instructions = ('user_instructions_per_tuple' if case['operation'] == 'scan'
                        else 'user_instructions_per_operation')
        profiles = case['profiles']
        assert set(profiles) == {'on', 'callback'}, name
        rates = [profiles[p]['metrics'][metric]['geometric_mean'] / 1e6
                 for p in ('callback', 'on')]
        lines.append('| ' + ' | '.join([
            pattern, LABELS[operation], *(f'{r:.3f}' for r in rates),
            change(case, 'on/callback', metric),
            change(case, 'on/callback', instructions),
        ]) + ' |')
    lines += ['', 'Raw evidence: [manifest](supplemental/manifest.json), '
              '[machine-readable analysis](supplemental/summary.json).', '']
    with args.output.open('x') as output:
        output.write('\n'.join(lines))
    print(args.output)


if __name__ == '__main__':
    main()
