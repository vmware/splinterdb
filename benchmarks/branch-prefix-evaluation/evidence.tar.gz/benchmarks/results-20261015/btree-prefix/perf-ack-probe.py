"""Bounded, database-free capture of installed perf FIFO acknowledgement bytes."""
import fcntl
import json
import os
from pathlib import Path
import select
import signal
import subprocess

root = Path(__file__).resolve().parent
scratch = Path('.cache/btree-prefix-bench/ack-probe-01').resolve()
lock_path = Path('/home/rob/projects/splinterdb/.cache/projects-20261011/coordination/machine.lock')
scratch.mkdir()
ctl, ack = scratch/'control', scratch/'ack'
for p in (ctl, ack): os.mkfifo(p)
proc = None
fds = []
records = []
print('Waiting for machine lock for database-free perf acknowledgement probe', flush=True)
try:
    with lock_path.open('r') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        control = os.open(ctl, os.O_RDWR | os.O_NONBLOCK)
        answer = os.open(ack, os.O_RDWR | os.O_NONBLOCK)
        fds = [control, answer]
        with (root/'perf-ack-probe.log').open('x') as log:
            command = ['perf', 'stat', '-D', '-1', '-e', 'task-clock',
                       '--control', f'fifo:{ctl},{ack}', '--', 'sleep', '4']
            proc = subprocess.Popen(command, stdout=log, stderr=log,
                                    start_new_session=True)
            for action in ['enable', 'disable', 'enable', 'disable']:
                os.write(control, (action+'\n').encode())
                if not select.select([answer], [], [], 2)[0]:
                    raise RuntimeError('Acknowledgement timeout')
                data = os.read(answer, 256)
                while select.select([answer], [], [], 0.05)[0]:
                    data += os.read(answer, 256)
                records.append(dict(command=action, raw_hex=data.hex(),
                                    raw_repr=repr(data), length=len(data)))
            code = proc.wait(timeout=6)
            result = dict(command=command, returncode=code, records=records,
                          machine_lock=str(lock_path), database_used=False)
            with (root/'perf-ack-probe.json').open('x') as out:
                json.dump(result, out, indent=2)
                out.write('\n')
            print(json.dumps(result, indent=2), flush=True)
finally:
    if proc is not None:
        try: os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError: pass
        proc.wait()
    for fd in fds: os.close(fd)
    for p in (ctl, ack): p.unlink()
