# Unapplied B-tree hotspot proposals

These are independent source proposals against `src/btree.c` SHA256
`6ceb7b6ea8d9c72c4112433f8dde617a3818de832b3e6e411d5914e3fd419aab`.
They have not been compiled, regression-tested, timed, or applied to any runtime
source tree. Each patch passed `git apply --check` against that source. The
manifest records each patch hash and the exact resulting source hash. Apply one
patch at a time in a new isolated source variant; do not combine the hypotheses
for an initial comparison.

The source review inspected the frozen v2 current binary with SHA256
`44a8b5b55573aa1fbe1e9a03e8f881983463d48152ba7319ddfa1ba5185e5702`
and main binary with SHA256
`b51142810c45ddd452729f7aec110a7ab6169cda1b0d4c5a1ff6104c02afd0e0`.
Their identities are in [build-v2/build.json](../build-v2/build.json). Pilot
throughput prompted the review but is not evidence that any proposal helps.

## 1. Rare blob descriptor scratch

[rare-blob-scratch.patch](rare-blob-scratch.patch) moves the existing
`parsed_blob` local and `blob_parse_descriptor()` call into a non-inlined helper.
The branch/message bounds, flag checks, and descriptor-parsing error propagation
stay in their existing order. Only an actual blob descriptor calls the helper.
There is no new per-key helper on the ordinary inline-value or compressed-key
reconstruction paths.

In the frozen current binary, `btree_iterator_check_current` at `0x11c40`
reserves `0x58` bytes and saves four callee-saved registers, even for ordinary
inline values. It passes its stack address as `parsed_blob` output at `0x11ed8`.
Current `next()` calls this outlined validator; main inlines its validator.
Removing the rare descriptor local may reduce stack/register pressure and
change inlining decisions. That is a compiler-code-generation hypothesis;
stack-pointer subtraction alone is not a demonstrated bottleneck. Blob messages
could incur an additional call, which must be considered explicitly.

This differs from the earlier rejected whole-decode outlining probe, which
added a helper call for every reconstructed key. The rejected generic
force-inline annotation is also not included. See the old
[prefix-slowdown-diagnosis report](../../prefix-slowdown-diagnosis/README.md).

Before adoption, inspect generated `next`/`check_current` assembly, validate
inline and blob values (including malformed descriptors and both iterator
directions), then compare identical uncompressed and compressed scans. No check
may be removed merely to reproduce main's instruction count.

## 2. Lazy parent-pivot buffer

[lazy-pivot-buffer.patch](lazy-pivot-buffer.patch) factors the existing linking
body into a helper taking a pivot whose lifetime is owned by the caller. Internal
node pivots and uncompressed leaf pivots borrow directly from the still-pinned
edge. Only compressed leaf pivots initialize the auto-cleanup key buffer.

The current `btree_pack_link_node()` initializes `pivot_buffer` before testing
height or prefix. `key_buffer_init()` includes an out-of-line
`writable_buffer_resize(..., 0)` call. In frozen `btree_pack_link_extent`, buffer
initialization precedes the prefix check (resize at `0x19973`, prefix load at
`0x19989`); it also occurs on the internal-node path. Main has no corresponding
buffer setup.

The new wrapper retains the height/offset checks. The linking helper retains
unlock/unclaim, parent creation, statistics, unget, and every failure path in the
same order. A borrowed pivot remains pinned until copied into the parent. A
reconstructed pivot's auto-cleanup buffer remains alive until the helper returns,
including recursive parent creation and errors. The patch does not return a key
from a scope after its buffer has been destroyed.

This targets work once per linked page, not once per tuple. Check mixed
compressed/uncompressed leaves, internal levels, small/root-only outputs, pack
abort and allocation-failure cleanup, and full key/value iteration. Measure
pack-only work separately for compression off, enabled-but-uncompressible, and
actually compressed leaves.

## 3. Prefix qualification before rewrite scratch

[prefix-before-scratch.patch](prefix-before-scratch.patch) leaves compression
eligibility, first/last-key prefix detection, and the four-byte minimum unchanged.
It moves the existing page rewrite body into a non-inlined helper reached only
after a prefix qualifies. The helper rereads the unchanged first key and performs
the same scratch construction, tuple copying, and full-page copyback.

Frozen `btree_pack_compress_leaf` saves six registers and subtracts `0x10068`
from the stack pointer before finding and rejecting a prefix shorter than four
bytes. A disabled lexical flag already returns before that prologue. The new
split is meant to keep the enabled-but-uncompressible rejection path small. The
64 KiB stack reservation does not imply a 64 KiB allocation, initialization, or
copy on rejected leaves; those memory operations occur only on successful
compression. This proposal may therefore have only a small effect.

No compression threshold, on-disk encoding, append semantics, or validation is
changed. Compressed pages acquire a helper boundary once per successful rewrite;
measure that case as well as rejection. Check prefix lengths 0/1/3/4 and larger,
variable key/message lengths, leaf transitions, and full tuple verification.
In-place compaction and caller-side flag specialization are separate, unprepared
ideas and are deliberately absent from this patch.

## Limits of source attribution

Uncompressed iterators return keys directly from pinned branch pages; they do
not allocate a decode buffer or copy each key. Current `curr()` adds a prefix
load/test, and validation handles the reserved prefix region and reconstructed
key-length limit. These are actual extra paths but source inspection cannot
assign the pilot's throughput difference to any single instruction.

Both main and current packing call an outlined append helper and marshal the
same key/message descriptors on the stack. The current helper's existence is
not a newly introduced per-tuple call. No proposal here assumes otherwise.
