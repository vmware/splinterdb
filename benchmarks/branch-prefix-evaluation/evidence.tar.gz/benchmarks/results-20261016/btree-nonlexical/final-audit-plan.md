# Final audit plan

Prepared during the final aligned confirmation; no audit, workload, build, or
artifact hashing was run as part of this preparation. The campaign owner must
confirm that the final process has exited and been reaped before execution.
Finish report, source, and analysis writes first; both audit commands acquire
`benchmark.lock` and then `machine.lock` exclusively.

The preserved `audit.py` uses generic profile/build mappings compatible with
`selected-io-alignment` and the unchanged campaign/result schema, but its strict
benchmark log allowlist rejects the separately archived `independent-review.log`.
The new `audit_v2.py` recognizes that exact supplemental name only when its JSON
report matches the campaign, summary, reviewer source, and captured stdout;
both files are hashed separately. It still rejects every other unexpected log.
`reviewer-sources.json` binds each hash already recorded by a review to its
retained source path, covering both the six-pair `review_completed.py` and the
separate 18-pair `review_focused18.py`. The auditor verifies the file against
that recorded hash; it does not infer the reviewer from the pair count or alter
historical review reports.
The v1 auditor and historical evidence remain unchanged. The source delta is
recorded in `audit-v2-from-v1.patch`. Default discovery checks every immediate
manifest directory, including smoke and earlier screen campaigns.
Recorded runner, analyzer, harness, library, binary, runtime source, command,
logical-work, residency, and raw-counter identities are checked per campaign.
Ancillary validation and application records are merely indexed by that audit,
so the separate new `audit_final.py` adds semantic checks without changing a
recorded tool.

Run sequentially from the worktree root, using fresh output names:

```sh
python3 benchmarks/results-20261016/btree-nonlexical/audit_v2.py --output benchmarks/results-20261016/btree-nonlexical/audit-campaigns-final.json
python3 benchmarks/results-20261016/btree-nonlexical/audit_final.py --campaign-audit benchmarks/results-20261016/btree-nonlexical/audit-campaigns-final.json --output benchmarks/results-20261016/btree-nonlexical/audit-final.json
```

Run the second command only if the first passes. Neither starts a workload.
The companion rechecks files from the completed campaign audit, so source or
report changes between commands are detected. Both refuse to replace existing
output files; if a discrepancy requires correction, preserve the failed audit
and use new output names for the subsequent verification.

The companion requires four exact validation histories:

| Validation | Expected recorded outcome | Passing test executions |
| --- | --- | ---: |
| Selected release | Passed | 87 |
| Selected debug/fault/sanitizers | Failed at the original UBSan alignment defect | 144 |
| Original `b9cc3ea4` sanitizer reproduction | Same expected failure | 21 |
| Isolated aligned repair | Passed: sanitizer 36 plus release/debug/fault regression once each | 39 |

The original failed runs retain their `passed=false` status. Their sanitizer
stage remains recorded as `running` because the runner stopped on error; the
finished timestamp, sole failing row, nonzero exit, and specific UBSan log are
checked rather than editing that historical status. Expected evidence is not
reported as a passing runtime test.

For every validation, the companion verifies the original archive hash map,
raw log summaries and counts, recorded test binaries, build artifact maps,
source inventories, and unchanged frozen/runtime identities. ASan/UBSan
settings must still be fatal with no recovery and no added suppressions;
inherited LeakSanitizer-off remains an explicit limitation.
Unique test records, exact per-stage pass counts, a build record and artifact
map for every stage, and recorded binary identities for every test are required.

For final source application, all inventoried sources must match the repaired
variant. The only allowed differences are the exact tests-only overlay and
the recorded one-brace formatting change in `btree.c`; it is checked as an
exact text replacement, not broad whitespace stripping. The four recorded
live hashes and applied patch hashes in `application.json` are required.
Its confirmation-pending flag is historical: actual completion is established
by the independently audited `confirmation-aligned` campaign.
The final build inventory contains 167 entries (`src`, `include`, `tests`, and
`Makefile`), and is checked as the exact corresponding subset of the broader
175-file repaired/validated source inventory. The earlier baseline's 166-entry
build inventory omits `Makefile`; the campaign auditor retains that existing
provenance limitation rather than inventing an original hash.

Audit success establishes evidence and source integrity, not statistical
performance equivalence or approval to merge. Reports must retain the timing
uncertainty, lexical tradeoff, original sanitizer failures, and repaired-binary
confirmation scope.
