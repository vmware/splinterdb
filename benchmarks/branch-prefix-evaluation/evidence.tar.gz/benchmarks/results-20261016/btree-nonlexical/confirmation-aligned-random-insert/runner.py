#!/usr/bin/env python3
"""Serialized fixed-work B-tree probes with explicit binary/flag profiles.

profile_definitions maps each profile to build, compression, and read_lexical.
Each case names two or three profiles; six repetitions counterbalance all
orders. Use purpose=smoke for an explicitly unbalanced one-repetition check.
"""
import argparse
import fcntl
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SCRATCH = ROOT / '.cache/btree-nonlexical-20261016'
COORD = Path('/home/rob/projects/splinterdb/.cache/projects-20261011/coordination')
EVENTS = '{cpu_core/cycles/u,cpu_core/instructions/u},task-clock,context-switches,cpu-migrations'


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for data in iter(lambda: stream.read(1048576), b''):
            digest.update(data)
    return digest.hexdigest()


def save(path, value):
    temp = path.with_suffix(path.suffix + '.new')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    temp.replace(path)


def host(cpu):
    value = {'time': time.time(), 'loadavg': Path('/proc/loadavg').read_text().strip()}
    # Boundary-only reads; avoid firmware-backed hwmon temperature callbacks.
    for name, path in [('frequency_khz', f'/sys/devices/system/cpu/cpu{cpu}/cpufreq/scaling_cur_freq')]:
        try:
            value[name] = int(Path(path).read_text())
        except (OSError, ValueError):
            pass
    return value


def stop(proc):
    # Reap the whole process group, even if perf exited before its child.
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    proc.wait()


def counters(path):
    result = {}
    for line in path.read_text().splitlines():
        parts = line.split(';')
        if len(parts) < 5 or line.startswith('#'):
            continue
        event = parts[2].strip()
        assert event not in result, f'Duplicate perf event {event}'
        try:
            value, coverage = float(parts[0]), float(parts[4])
            assert math.isfinite(value) and value >= 0
            assert math.isfinite(coverage) and 99 <= coverage <= 100
            result[event] = {'value': value, 'coverage': coverage}
        except ValueError:
            result[event] = {'unavailable': parts[0].strip()}
    for event in ('cpu_core/cycles/u', 'cpu_core/instructions/u', 'task-clock'):
        assert result.get(event, {}).get('value', 0) > 0, f'Missing/invalid {event}'
    return result


def ordered_profiles(profiles, repeat):
    # All six permutations for three modes; AB/BA for two.
    permutations = list(itertools.permutations(profiles))
    return permutations[repeat % len(permutations)]


ZERO_FIELDS = ('active_read_bytes', 'active_write_bytes', 'major_faults',
               'io_reads', 'io_writes', 'io_async_reads', 'io_async_writes')
CONFIG_FIELDS = ('operation', 'pattern', 'insert_order', 'keys', 'key_bytes',
                 'value_bytes', 'requested_ops', 'scan_length', 'batches',
                 'seed', 'cache_mib', 'disk_mib', 'cpu', 'miss')
WORK_FIELDS = ('operations', 'tuples', 'returned_tuples', 'processed_tuples',
               'checksum', 'expected_checksum', 'verified_tuples', 'verified_values')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value, field, minimum=0):
    require(type(value) is int and value >= minimum, f'{field}: invalid integer')
    return value


def valid_name(value):
    return isinstance(value, str) and bool(value) and value.replace('-', '').replace('_', '').isalnum()


def validate_plan(plan, builds=None):
    repeats = integer(plan.get('repeats', 6), 'repeats', 1)
    definitions = plan['profile_definitions']
    require(isinstance(definitions, dict) and definitions, 'Missing profile definitions')
    for name, mapping in definitions.items():
        require(valid_name(name) and valid_name(mapping['build']), 'Invalid profile/build name')
        for flag in ('compression', 'read_lexical'):
            require(type(mapping[flag]) is bool, f'{name}/{flag}: must be explicit boolean')
        if builds is not None:
            require(mapping['build'] in builds, f'Missing build {mapping["build"]}')
            supported = builds[mapping['build']]['prefix_supported']
            require(type(supported) is bool, 'Invalid prefix_supported metadata')
            require(supported or not (mapping['compression'] or mapping['read_lexical']),
                    f'{name}: unsupported prefix flags')
    cases = plan['cases']
    require(cases and len({c['name'] for c in cases}) == len(cases), 'Missing/duplicate cases')
    for field, default in (('keys', 200000), ('key_bytes', 64), ('value_bytes', 100),
                           ('cache_mib', 512), ('disk_mib', 2048)):
        integer(plan.get(field, default), field, 1)
    integer(plan.get('cpu', 2), 'cpu')
    integer(plan.get('seed', 20261015), 'seed')
    for case in cases:
        require(valid_name(case['name']), 'Invalid case name')
        require(case['pattern'] in ('common', 'random', 'nonlexical'), 'Invalid pattern')
        require(case['operation'] in ('insert', 'overwrite', 'pack', 'lookup', 'scan'), 'Invalid operation')
        profiles = case['profiles']
        require(1 <= len(profiles) <= 3 and len(set(profiles)) == len(profiles),
                'Cases must have one to three distinct profiles')
        require(set(profiles) <= definitions.keys(), 'Undefined case profile')
        if plan.get('purpose') != 'smoke':
            require(repeats % math.factorial(len(profiles)) == 0,
                    'Measured repetitions must cover complete profile permutations')
        require(case.get('insert_order', 'random') in ('random', 'sorted'), 'Invalid insertion order')
        integer(case.get('ops', 1), 'ops', 1)
        integer(case.get('batches', 1), 'batches', 1)
        length = case.get('scan_length', 10000)
        if length != 'full':
            integer(length, 'scan_length', 1)
            if case['operation'] == 'scan':
                require(length <= plan.get('keys', 200000), 'Scan exceeds input size')
        require(type(case.get('miss', False)) is bool, 'miss must be boolean')
        require(not case.get('miss') or case['operation'] == 'lookup', 'Miss only applies to lookup')
        for profile in profiles:
            mapping = definitions[profile]
            if case['pattern'] == 'nonlexical':
                require(not mapping['compression'] and not mapping['read_lexical'],
                        'Nonlexical comparator cannot enable lexical flags')
        comparisons = case.get('comparisons', plan.get('comparisons'))
        require(isinstance(comparisons, list), 'Explicit comparisons required')
        applicable = []
        for pair in comparisons:
            require(isinstance(pair, list) and len(pair) == 2 and pair[0] != pair[1]
                    and set(pair) <= definitions.keys(), 'Invalid comparison pair')
            if set(pair) <= set(profiles):
                applicable.append(tuple(pair))
        require(len(set(applicable)) == len(applicable), 'Duplicate comparison')
        require(applicable or len(profiles) == 1, 'Case has no applicable comparison')


def expected_config(plan, case, repeat, mapping, supported):
    keys = plan.get('keys', 200000)
    length = case.get('scan_length', 10000)
    return dict(operation=case['operation'], pattern=case['pattern'],
                insert_order=case.get('insert_order', 'random'), keys=keys,
                key_bytes=plan.get('key_bytes', 64), value_bytes=plan.get('value_bytes', 100),
                requested_ops=case.get('ops', 1), scan_length=keys if length == 'full' else length,
                batches=case.get('batches', 1), seed=plan.get('seed', 20261015) + repeat,
                cache_mib=plan.get('cache_mib', 512), disk_mib=plan.get('disk_mib', 2048),
                cpu=plan.get('cpu', 2), miss=case.get('miss', False),
                prefix_supported=supported, pack_lexical=mapping['compression'],
                read_lexical=mapping['read_lexical'])


def validate_result(result, expected):
    require(result.get('schema_version') == 1, 'Unsupported result schema')
    require(result.get('resident') is True and result.get('verified') is True,
            'Result is not resident and verified')
    for field, value in expected.items():
        require(type(result[field]) is type(value) and result[field] == value,
                f'{field}: configuration mismatch')
    for field in ZERO_FIELDS:
        require(integer(result[field], field) == 0, f'{field}: nonzero active I/O/faults')
    for field in ('active_wall_ns', 'process_cpu_ns', 'verified_tuples', 'verified_values'):
        integer(result[field], field, 1)
    require(result['verified_tuples'] == result['verified_values'], 'Verification count mismatch')
    require(integer(result['checksum'], 'checksum') == integer(result['expected_checksum'], 'expected_checksum'),
            'Checksum mismatch')
    count = expected['batches']
    op = expected['operation']
    processed = expected['keys'] * count if op in ('insert', 'overwrite', 'pack') else 0
    operations = (count if op == 'pack' else processed if op in ('insert', 'overwrite')
                  else expected['requested_ops'] * count)
    returned = (operations * expected['scan_length'] if op == 'scan' else
                operations if op == 'lookup' and not expected['miss'] else 0)
    for field, value in dict(operations=operations, processed_tuples=processed,
                             returned_tuples=returned, tuples=processed + returned).items():
        require(integer(result[field], field) == value, f'{field}: wrong work units')
    for field in ('packed_bytes', 'leaf_count', 'compressed_leaf_count', 'prefix_bytes'):
        integer(result[field], field)
    require(result['compressed_leaf_count'] <= result['leaf_count'], 'Invalid compressed leaf count')
    if not expected['pack_lexical'] or op in ('insert', 'overwrite'):
        require(result['compressed_leaf_count'] == 0 and result['prefix_bytes'] == 0,
                'Unexpected compressed leaves')


def logical_signature(result):
    return {field: result[field] for field in CONFIG_FIELDS + WORK_FIELDS}


def validate_builds(builds, used):
    source_hashes = set()
    for name in sorted(used):
        entry = builds[name]
        for field in ('binary', 'library', 'source'):
            require(sha(entry[field]) == entry[field + '_sha256'], f'{name}: changed {field}')
        source_hashes.add(entry['source_sha256'])
        for relative, expected in entry.get('source_files_sha256', {}).items():
            require(sha(Path(entry['tree']) / relative) == expected, f'{name}: changed source {relative}')
    require(len(source_hashes) == 1, 'Profiles must share identical harness source')


def main():
    def interrupted(signum, frame):
        raise KeyboardInterrupt(f'signal {signum}')
    signal.signal(signal.SIGTERM, interrupted)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--name', required=True)
    parser.add_argument('--build', type=Path, default=HERE / 'build.json')
    parser.add_argument('--no-perf', action='store_true')
    parser.add_argument('--timeout', type=int, default=900)
    args = parser.parse_args()
    require(valid_name(args.name), 'Invalid campaign name')
    require(args.timeout > 0, 'Timeout must be positive')
    plan_raw, build_raw = args.plan.read_bytes(), args.build.read_bytes()
    plan, builds = json.loads(plan_raw), json.loads(build_raw)
    validate_plan(plan, builds)
    definitions = plan['profile_definitions']
    used = {definitions[p]['build'] for c in plan['cases'] for p in c['profiles']}
    folder = HERE / args.name
    folder.mkdir(exist_ok=False)
    SCRATCH.mkdir(exist_ok=True, parents=True)
    (folder / 'plan.json').write_bytes(plan_raw)
    (folder / 'runner.py').write_bytes(Path(__file__).read_bytes())
    (folder / 'analyze.py').write_bytes((HERE / 'analyze.py').read_bytes())
    (folder / 'build.json').write_bytes(build_raw)
    data = {'complete': False, 'started': time.time(), 'runs': [],
            'plan': plan, 'plan_sha256': sha(folder / 'plan.json'),
            'runner_sha256': sha(folder / 'runner.py'),
            'analysis_sha256': sha(folder / 'analyze.py'),
            'build_sha256': sha(folder / 'build.json'),
            'build_input': str(args.build.resolve()), 'profile_definitions': definitions,
            'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'host': subprocess.check_output(['lscpu'], text=True),
            'coordination': 'Exclusive benchmark.lock then machine.lock; one child at a time',
            'perf_events': None if args.no_perf else EVENTS}
    save(folder / 'manifest.json', data)
    print('Waiting for exclusive benchmark.lock and machine.lock', flush=True)
    with (COORD / 'benchmark.lock').open('rb') as bench, (COORD / 'machine.lock').open('rb') as machine:
        fcntl.flock(bench, fcntl.LOCK_EX)
        fcntl.flock(machine, fcntl.LOCK_EX)
        storage = subprocess.check_output(['findmnt', '-T', str(SCRATCH), '-n', '-o', 'FSTYPE,SOURCE'], text=True).strip()
        require(storage.split()[0] not in ('tmpfs', 'ramfs', 'overlay'), 'Scratch must use real-disk storage')
        data['scratch_storage'] = storage
        validate_builds(builds, used)
        cases = plan['cases']
        index = 0
        for repeat in range(plan.get('repeats', 6)):
            # Rotate workloads too; comparison modes remain adjacent within a block.
            rotated = cases[repeat % len(cases):] + cases[:repeat % len(cases)]
            for case in rotated:
                paired_work = None
                for position, profile in enumerate(ordered_profiles(case['profiles'], repeat)):
                    index += 1
                    label = f'{index:04d}-r{repeat}-{case["name"]}-{profile}'
                    mapping = definitions[profile]
                    entry = builds[mapping['build']]
                    database = SCRATCH / (args.name + '-scratch.db')
                    assert not database.exists(), 'Refusing to replace an existing scratch database'
                    pack_on = mapping['compression']
                    read_on = mapping['read_lexical']
                    command = [entry['binary'], '--db', str(database), '--operation', case['operation'],
                               '--pattern', case['pattern'], '--compression', 'on' if pack_on else 'off',
                               '--read-lexical', 'on' if read_on else 'off',
                               '--keys', str(plan.get('keys', 200000)),
                               '--key-bytes', str(plan.get('key_bytes', 64)),
                               '--value-bytes', str(plan.get('value_bytes', 100)),
                               '--cache-mib', str(plan.get('cache_mib', 512)),
                               '--disk-mib', str(plan.get('disk_mib', 2048)),
                               '--cpu', str(plan.get('cpu', 2)),
                               '--seed', str(plan.get('seed', 20261015) + repeat),
                               '--ops', str(case.get('ops', 1)), '--batches', str(case.get('batches', 1))]
                    for key in ('scan_length', 'insert_order'):
                        if key in case:
                            command += ['--' + key.replace('_', '-'), str(case[key])]
                    if case.get('miss'):
                        command += ['--miss']
                    env = dict(os.environ)
                    env.pop('PREFIX_PERF_CONTROL', None)
                    env.pop('PREFIX_PERF_ACK', None)
                    control = SCRATCH / (args.name + '-' + label + '.control')
                    ack = SCRATCH / (args.name + '-' + label + '.ack')
                    stat = folder / (label + '.stat')
                    if not args.no_perf:
                        os.mkfifo(control)
                        os.mkfifo(ack)
                        env.update(PREFIX_PERF_CONTROL=str(control), PREFIX_PERF_ACK=str(ack))
                        command = ['perf', 'stat', '-x', ';', '-o', str(stat), '-e', EVENTS,
                                   '-D', '-1', f'--control=fifo:{control},{ack}', '--', *command]
                    record = {'label': label, 'case': case['name'], 'repeat': repeat,
                              'position': position, 'profile': profile, 'command': command,
                              'build': mapping['build'], 'profile_definition': mapping,
                              'prefix_supported': entry['prefix_supported'],
                              'binary_sha256': entry['binary_sha256'],
                              'library_sha256': entry['library_sha256'],
                              'harness_sha256': entry['source_sha256'],
                              'host_start': host(plan.get('cpu', 2))}
                    data['runs'].append(record)
                    save(folder / 'manifest.json', data)
                    print(label, 'running', flush=True)
                    logfile = folder / (label + '.log')
                    try:
                        with logfile.open('w') as log:
                            proc = None
                            try:
                                proc = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log,
                                                        stderr=subprocess.STDOUT, start_new_session=True)
                                code = proc.wait(timeout=args.timeout)
                            finally:
                                if proc is not None:
                                    stop(proc)
                        record.update(returncode=code, host_end=host(plan.get('cpu', 2)), log_sha256=sha(logfile))
                        assert code == 0, f'{label}: exit {code}; see {logfile}'
                        results = [json.loads(line) for line in logfile.read_text().splitlines()
                                   if line.startswith('{') and 'schema_version' in line]
                        assert len(results) == 1, f'{label}: expected one result'
                        result = results[0]
                        record['result'] = result
                        expected = expected_config(plan, case, repeat, mapping, entry['prefix_supported'])
                        validate_result(result, expected)
                        signature = logical_signature(result)
                        if paired_work is None:
                            paired_work = signature
                        else:
                            require(paired_work == signature, f'{label}: unequal paired logical work')
                        if not args.no_perf:
                            record['perf'] = counters(stat)
                            record['perf_sha256'] = sha(stat)
                            assert all('unavailable' not in v for v in record['perf'].values()), record['perf']
                        print(label, 'done', round(result['active_wall_ns'] / 1e9, 3), 'active seconds', flush=True)
                    except BaseException as error:
                        record['error'] = repr(error)
                        if logfile.exists():
                            record['log_sha256'] = sha(logfile)
                        if stat.exists():
                            record['perf_sha256'] = sha(stat)
                        raise
                    finally:
                        save(folder / 'manifest.json', data)
                        for pipe in (control, ack):
                            pipe.unlink(missing_ok=True)
                        # Only our disposable image, and only after its child is reaped.
                        database.unlink(missing_ok=True)
        validate_builds(builds, used)
        data.update(complete=True, finished=time.time(), final_build_identities_verified=True)
        save(folder / 'manifest.json', data)
    print('Completed', len(data['runs']), 'validated samples', flush=True)


if __name__ == '__main__':
    main()
