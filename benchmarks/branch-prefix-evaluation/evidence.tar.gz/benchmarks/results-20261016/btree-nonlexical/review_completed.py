#!/usr/bin/env python3
"""Independent numerical checks of a completed screen; never launches workloads."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics


def estimate(ratios):
    logs = [math.log(x) for x in ratios]
    if len(logs) != 6:
        raise ValueError('This review expects six complete pairs')
    mean = sum(logs) / 6
    variance = sum((x - mean) ** 2 for x in logs) / 5
    half = 2.570581836 * math.sqrt(variance / 6)
    return {'n': 6, 'percent_change': 100 * math.expm1(mean),
            'ci95_percent': [100 * math.expm1(mean-half), 100 * math.expm1(mean+half)],
            'ratios': ratios}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('summary', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError('Refusing to overwrite review')
    raw = args.manifest.read_bytes()
    manifest = json.loads(raw)
    summary = json.loads(args.summary.read_text())
    if manifest.get('complete') is not True:
        raise ValueError('Incomplete campaign')
    groups, coverage, durations = {}, [], []
    for run in manifest['runs']:
        result = run['result']
        if run['returncode'] or result['verified'] is not True or result['resident'] is not True:
            raise ValueError('Unverified or nonresident run')
        if result['checksum'] != result['expected_checksum']:
            raise ValueError('Checksum mismatch')
        for field in ('active_read_bytes', 'active_write_bytes', 'major_faults',
                      'io_reads', 'io_writes', 'io_async_reads', 'io_async_writes'):
            if result[field] != 0:
                raise ValueError('Nonzero ' + field)
        for counter in run['perf'].values():
            if not math.isfinite(counter['value']) or counter['value'] < 0 or not 99 <= counter['coverage'] <= 100:
                raise ValueError('Invalid perf counter')
            coverage.append(counter['coverage'])
        durations.append(result['active_wall_ns'] / 1e9)
        key = run['case'], run['repeat'], run['profile']
        if key in groups:
            raise ValueError('Duplicate sample')
        groups[key] = run
    comparisons = []
    for case in manifest['plan']['cases']:
        for candidate, reference in case.get('comparisons', manifest['plan'].get('comparisons')):
            if candidate not in case['profiles'] or reference not in case['profiles']:
                continue
            pairs = [(groups[case['name'], rep, candidate], groups[case['name'], rep, reference])
                     for rep in range(6)]
            for ca, re in pairs:
                for field in ('operations', 'tuples', 'returned_tuples', 'processed_tuples',
                              'checksum', 'expected_checksum', 'keys', 'key_bytes', 'value_bytes',
                              'requested_ops', 'scan_length', 'batches', 'seed', 'pattern', 'operation', 'miss'):
                    if ca['result'][field] != re['result'][field]:
                        raise ValueError('Unmatched paired ' + field)
            def ratio(ca, re, kind):
                c, r = ca['result'], re['result']
                if kind == 'ops_s':
                    return (c['operations'] / c['active_wall_ns']) / (r['operations'] / r['active_wall_ns'])
                if kind == 'cpu_ns_per_operation':
                    return (c['process_cpu_ns'] / c['operations']) / (r['process_cpu_ns'] / r['operations'])
                event = {'user_instructions_per_operation': 'cpu_core/instructions/u',
                         'user_cycles_per_operation': 'cpu_core/cycles/u'}[kind]
                return (ca['perf'][event]['value'] / c['operations']) / (re['perf'][event]['value'] / r['operations'])
            metrics = {}
            for metric in ('ops_s', 'cpu_ns_per_operation', 'user_cycles_per_operation', 'user_instructions_per_operation'):
                value = estimate([ratio(ca, re, metric) for ca, re in pairs])
                actual = summary['cases'][case['name']]['comparisons'][candidate+'/'+reference]['metrics'][metric]
                if actual['n'] != 6 or any(abs(a-b) > 1e-7 for a,b in zip(
                        [value['percent_change'], *value['ci95_percent']],
                        [actual['percent_change'], *actual['ci95_percent']])):
                    raise ValueError('Summary mismatch: ' + case['name'] + '/' + metric)
                metrics[metric] = value
            comparisons.append({'case': case['name'], 'comparison': candidate+'/'+reference, 'metrics': metrics})
    report = {'passed': True, 'runs': len(manifest['runs']), 'cases': len(manifest['plan']['cases']),
              'minimum_counter_coverage_percent': min(coverage),
              'active_seconds_min_median_max': [min(durations), statistics.median(durations), max(durations)],
              'zero_active_io_and_major_faults': True, 'comparisons': comparisons,
              'scope': 'Independent paired arithmetic and manifest guard checks; artifact hashes audited separately. Nominal intervals are not equivalence guarantees or simultaneous bounds.',
              'manifest_sha256': hashlib.sha256(raw).hexdigest(),
              'summary_sha256': hashlib.sha256(args.summary.read_bytes()).hexdigest(),
              'review_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'passed': True, 'runs': report['runs'], 'coverage': report['minimum_counter_coverage_percent'],
                      'comparisons': [{'case': c['case'], 'comparison': c['comparison'],
                                       'throughput': c['metrics']['ops_s'],
                                       'instructions_pct': c['metrics']['user_instructions_per_operation']['percent_change']}
                                      for c in comparisons]}, indent=2))


if __name__ == '__main__':
    main()
