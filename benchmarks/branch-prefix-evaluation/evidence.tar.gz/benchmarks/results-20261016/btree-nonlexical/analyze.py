#!/usr/bin/env python3
"""Analyze a completed B-tree campaign without changing its raw evidence.

Usage: python3 analyze.py MANIFEST.json SUMMARY.json

Each comparison pairs profiles by case and repetition. Nominal 95% Student-t
intervals use log ratios; six pairs use t(5)=2.570581836. These small-sample
observational intervals assume independent paired differences. They are not
guaranteed bounds, simultaneous confidence statements, or equivalence tests.
Different cases and campaigns are never pooled.
"""

import argparse
from collections import defaultdict
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics


T975 = (
    None, 12.706204736, 4.302652730, 3.182446305, 2.776445105,
    2.570581836, 2.446911851, 2.364624252, 2.306004135, 2.262157163,
    2.228138852, 2.200985160, 2.178812830, 2.160368656, 2.144786688,
    2.131449546, 2.119905299, 2.109815578, 2.100922040, 2.093024054,
    2.085963447, 2.079613845, 2.073873068, 2.068657610, 2.063898562,
    2.059538553, 2.055529439, 2.051830516, 2.048407142, 2.045229642,
    2.042272456,
)

PERF_NAMES = {
    "cycles": "total_cycles", "instructions": "total_instructions",
    "cycles:u": "user_cycles", "instructions:u": "user_instructions",
    "cycles:k": "kernel_cycles", "instructions:k": "kernel_instructions",
    "cpu_core/cycles/": "total_cycles",
    "cpu_core/instructions/": "total_instructions",
    "cpu_core/cycles/u": "user_cycles",
    "cpu_core/instructions/u": "user_instructions",
    "cpu_core/cycles/k": "kernel_cycles",
    "cpu_core/instructions/k": "kernel_instructions",
}


def t975(df):
    if df < 1:
        raise ValueError("Student-t requires positive degrees of freedom")
    if df < len(T975):
        return T975[df]
    # Standard-library approximation, only needed beyond the planned six pairs.
    z = statistics.NormalDist().inv_cdf(0.975)
    return (z + (z**3 + z) / (4 * df)
            + (5*z**5 + 16*z**3 + 3*z) / (96 * df**2)
            + (3*z**7 + 19*z**5 + 17*z**3 - 15*z) / (384 * df**3))


def finite_number(value, label, *, positive=False):
    if isinstance(value, bool):
        raise ValueError(f"{label}: expected a number, not a boolean")
    try:
        number = float(value)
    except (ValueError, TypeError, OverflowError) as exc:
        raise ValueError(f"{label}: invalid number {value!r}") from exc
    if not math.isfinite(number) or number < 0 or (positive and number == 0):
        raise ValueError(f"{label}: invalid nonnegative/positive value {value!r}")
    return number


def count(value, label, *, positive=False):
    number = finite_number(value, label, positive=positive)
    if not number.is_integer():
        raise ValueError(f"{label}: count must be integral")
    return int(value)


def describe(values):
    values = list(values)
    if not values:
        return {"n": 0, "values": []}
    return {
        "n": len(values), "mean": statistics.mean(values),
        "median": statistics.median(values), "min": min(values),
        "max": max(values), "values": values,
        "geometric_mean": (math.exp(statistics.mean(map(math.log, values)))
                           if all(v > 0 for v in values) else None),
    }


def sample(run, warnings):
    label = f"{run['case']}/{run['repeat']}/{run['profile']}"
    result = run["result"]
    if not isinstance(result, dict):
        raise ValueError(f"{label}: result must be an object")
    if result.get("schema_version") != 1:
        raise ValueError(f"{label}: unsupported or missing result schema_version")
    if (run.get("returncode", 0) != 0 or run.get("verified") is False
            or result.get("verified") is not True):
        raise ValueError(f"{label}: failed or unverified run")
    if result.get("resident") is not True:
        raise ValueError(f"{label}: resident benchmark contains storage I/O or major faults")
    for field in ("errors", "violations"):
        if field in result and count(result[field], label + "/" + field):
            raise ValueError(f"{label}: nonzero {field}")
    for field in ("active_read_bytes", "active_write_bytes", "major_faults",
                  "io_reads", "io_writes", "io_async_reads", "io_async_writes"):
        if count(result[field], label + "/" + field):
            raise ValueError(f"{label}: nonzero resident-phase {field}")
    if result["checksum"] != result["expected_checksum"]:
        raise ValueError(f"{label}: checksum mismatch")
    for field in ("verified_tuples", "verified_values"):
        count(result[field], label + "/" + field, positive=True)
    ops = count(result["operations"], label + "/operations", positive=True)
    tuples = count(result["tuples"], label + "/tuples")
    returned = count(result["returned_tuples"], label + "/returned_tuples")
    processed = count(result["processed_tuples"], label + "/processed_tuples")
    if tuples != returned + processed:
        raise ValueError(f"{label}: tuple subtotals do not add up")
    wall = finite_number(result["active_wall_ns"], label + "/active_wall_ns",
                         positive=True)
    cpu = finite_number(result["process_cpu_ns"], label + "/process_cpu_ns",
                        positive=True)
    metrics = {
        "ops_s": 1e9 * ops / wall, "tuples_s": 1e9 * tuples / wall,
        "active_wall_ns": wall, "process_cpu_ns": cpu,
        "wall_ns_per_operation": wall / ops,
        "cpu_ns_per_operation": cpu / ops,
    }
    if tuples:
        metrics.update(wall_ns_per_tuple=wall / tuples,
                       cpu_ns_per_tuple=cpu / tuples)
    for field in ("user_cpu_ns", "system_cpu_ns"):
        if field in result:
            value = finite_number(result[field], label + "/" + field)
            metrics[field] = value
            metrics[field + "_per_operation"] = value / ops
            if tuples:
                metrics[field + "_per_tuple"] = value / tuples
    counters, coverage = {}, {}
    perf = run.get("perf") or {}
    for event, record in perf.items():
        if not isinstance(record, dict):
            raise ValueError(f"{label}: perf/{event} must be an object")
        try:
            value = finite_number(record.get("value"), label + "/" + event)
        except ValueError:
            warnings.append(f"{label}: unavailable counter {event}")
            continue
        try:
            cov = finite_number(record.get("coverage"), label + "/coverage")
            if cov > 100:
                raise ValueError("coverage exceeds 100 percent")
        except ValueError:
            cov = None
            warnings.append(f"{label}: missing/invalid coverage for {event}")
        if cov is not None and cov < 99:
            warnings.append(f"{label}: {event} coverage is {cov}% (<99%)")
        coverage[event] = cov
        name = PERF_NAMES.get(event)
        if name:
            if name in counters:
                raise ValueError(f"{label}: ambiguous counters for {name}")
            counters[name] = value
    for kind in ("cycles", "instructions"):
        if (f"total_{kind}" not in counters
                and f"user_{kind}" in counters
                and f"kernel_{kind}" in counters):
            counters[f"total_{kind}"] = (counters[f"user_{kind}"]
                                          + counters[f"kernel_{kind}"])
    for name, value in counters.items():
        metrics[name + "_per_operation"] = value / ops
        if tuples:
            metrics[name + "_per_tuple"] = value / tuples
    # Preserve the complete result: field names for tree census can evolve
    # without dropping raw compressed-leaf/packed-byte measurements.
    return {
        "repeat": run["repeat"], "position": run["position"],
        "profile": run["profile"], "operations": ops, "tuples": tuples,
        "result": result, "perf": perf, "counter_coverage_percent": coverage,
        "structure": {k: v for k, v in result.items()
                      if "compressed" in k or "packed" in k
                      or k in ("leaf_count", "prefix_bytes")},
        "metrics": metrics,
    }


def paired_metric(reference, candidate, metric):
    pairs, excluded = [], []
    for rep in sorted(reference):
        a = reference[rep]["metrics"].get(metric)
        b = candidate[rep]["metrics"].get(metric)
        if a is None or b is None or a <= 0 or b <= 0:
            excluded.append({"repeat": rep, "reference": a, "candidate": b,
                             "reason": "Log ratios require two positive values"})
            continue
        pairs.append({
            "repeat": rep, "reference": a, "candidate": b,
            "reference_position": reference[rep]["position"],
            "candidate_position": candidate[rep]["position"],
            "ratio": b / a, "log_ratio": math.log(b) - math.log(a),
        })
    out = {"n": len(pairs), "pairs": pairs, "excluded": excluded,
           "geometric_ratio": None, "percent_change": None,
           "ci95_ratio": None, "ci95_percent": None}
    if not pairs:
        return out
    logs = [pair["log_ratio"] for pair in pairs]
    mean = statistics.mean(logs)
    out.update(geometric_ratio=math.exp(mean), percent_change=100*math.expm1(mean),
               mean_log_ratio=mean)
    if len(pairs) > 1:
        se = statistics.stdev(logs) / math.sqrt(len(pairs))
        critical = t975(len(pairs) - 1)
        bounds = [mean - critical * se, mean + critical * se]
        out.update(log_standard_error=se, t_critical=critical,
                   ci95_ratio=[math.exp(v) for v in bounds],
                   ci95_percent=[100*math.expm1(v) for v in bounds])
    return out


ZERO_FIELDS = ('active_read_bytes', 'active_write_bytes', 'major_faults',
               'io_reads', 'io_writes', 'io_async_reads', 'io_async_writes')
CONFIG_FIELDS = ('operation', 'pattern', 'insert_order', 'keys', 'key_bytes',
                 'value_bytes', 'requested_ops', 'scan_length', 'batches',
                 'seed', 'cache_mib', 'disk_mib', 'cpu', 'miss')
WORK_FIELDS = ('operations', 'tuples', 'returned_tuples', 'processed_tuples',
               'checksum', 'expected_checksum', 'verified_tuples', 'verified_values')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value, field, minimum=0):
    require(type(value) is int and value >= minimum, f'{field}: invalid integer')
    return value


def valid_name(value):
    return isinstance(value, str) and bool(value) and value.replace('-', '').replace('_', '').isalnum()


def validate_plan(plan, builds=None):
    repeats = integer(plan.get('repeats', 6), 'repeats', 1)
    definitions = plan['profile_definitions']
    require(isinstance(definitions, dict) and definitions, 'Missing profile definitions')
    for name, mapping in definitions.items():
        require(valid_name(name) and valid_name(mapping['build']), 'Invalid profile/build name')
        for flag in ('compression', 'read_lexical'):
            require(type(mapping[flag]) is bool, f'{name}/{flag}: must be explicit boolean')
        if builds is not None:
            require(mapping['build'] in builds, f'Missing build {mapping["build"]}')
            supported = builds[mapping['build']]['prefix_supported']
            require(type(supported) is bool, 'Invalid prefix_supported metadata')
            require(supported or not (mapping['compression'] or mapping['read_lexical']),
                    f'{name}: unsupported prefix flags')
    cases = plan['cases']
    require(cases and len({c['name'] for c in cases}) == len(cases), 'Missing/duplicate cases')
    for field, default in (('keys', 200000), ('key_bytes', 64), ('value_bytes', 100),
                           ('cache_mib', 512), ('disk_mib', 2048)):
        integer(plan.get(field, default), field, 1)
    integer(plan.get('cpu', 2), 'cpu')
    integer(plan.get('seed', 20261015), 'seed')
    for case in cases:
        require(valid_name(case['name']), 'Invalid case name')
        require(case['pattern'] in ('common', 'random', 'nonlexical'), 'Invalid pattern')
        require(case['operation'] in ('insert', 'overwrite', 'pack', 'lookup', 'scan'), 'Invalid operation')
        profiles = case['profiles']
        require(1 <= len(profiles) <= 3 and len(set(profiles)) == len(profiles),
                'Cases must have one to three distinct profiles')
        require(set(profiles) <= definitions.keys(), 'Undefined case profile')
        if plan.get('purpose') != 'smoke':
            require(repeats % math.factorial(len(profiles)) == 0,
                    'Measured repetitions must cover complete profile permutations')
        require(case.get('insert_order', 'random') in ('random', 'sorted'), 'Invalid insertion order')
        integer(case.get('ops', 1), 'ops', 1)
        integer(case.get('batches', 1), 'batches', 1)
        length = case.get('scan_length', 10000)
        if length != 'full':
            integer(length, 'scan_length', 1)
            if case['operation'] == 'scan':
                require(length <= plan.get('keys', 200000), 'Scan exceeds input size')
        require(type(case.get('miss', False)) is bool, 'miss must be boolean')
        require(not case.get('miss') or case['operation'] == 'lookup', 'Miss only applies to lookup')
        for profile in profiles:
            mapping = definitions[profile]
            if case['pattern'] == 'nonlexical':
                require(not mapping['compression'] and not mapping['read_lexical'],
                        'Nonlexical comparator cannot enable lexical flags')
        comparisons = case.get('comparisons', plan.get('comparisons'))
        require(isinstance(comparisons, list), 'Explicit comparisons required')
        applicable = []
        for pair in comparisons:
            require(isinstance(pair, list) and len(pair) == 2 and pair[0] != pair[1]
                    and set(pair) <= definitions.keys(), 'Invalid comparison pair')
            if set(pair) <= set(profiles):
                applicable.append(tuple(pair))
        require(len(set(applicable)) == len(applicable), 'Duplicate comparison')
        require(applicable or len(profiles) == 1, 'Case has no applicable comparison')


def expected_config(plan, case, repeat, mapping, supported):
    keys = plan.get('keys', 200000)
    length = case.get('scan_length', 10000)
    return dict(operation=case['operation'], pattern=case['pattern'],
                insert_order=case.get('insert_order', 'random'), keys=keys,
                key_bytes=plan.get('key_bytes', 64), value_bytes=plan.get('value_bytes', 100),
                requested_ops=case.get('ops', 1), scan_length=keys if length == 'full' else length,
                batches=case.get('batches', 1), seed=plan.get('seed', 20261015) + repeat,
                cache_mib=plan.get('cache_mib', 512), disk_mib=plan.get('disk_mib', 2048),
                cpu=plan.get('cpu', 2), miss=case.get('miss', False),
                prefix_supported=supported, pack_lexical=mapping['compression'],
                read_lexical=mapping['read_lexical'])


def validate_result(result, expected):
    require(result.get('schema_version') == 1, 'Unsupported result schema')
    require(result.get('resident') is True and result.get('verified') is True,
            'Result is not resident and verified')
    for field, value in expected.items():
        require(type(result[field]) is type(value) and result[field] == value,
                f'{field}: configuration mismatch')
    for field in ZERO_FIELDS:
        require(integer(result[field], field) == 0, f'{field}: nonzero active I/O/faults')
    for field in ('active_wall_ns', 'process_cpu_ns', 'verified_tuples', 'verified_values'):
        integer(result[field], field, 1)
    require(result['verified_tuples'] == result['verified_values'], 'Verification count mismatch')
    require(integer(result['checksum'], 'checksum') == integer(result['expected_checksum'], 'expected_checksum'),
            'Checksum mismatch')
    count = expected['batches']
    op = expected['operation']
    processed = expected['keys'] * count if op in ('insert', 'overwrite', 'pack') else 0
    operations = (count if op == 'pack' else processed if op in ('insert', 'overwrite')
                  else expected['requested_ops'] * count)
    returned = (operations * expected['scan_length'] if op == 'scan' else
                operations if op == 'lookup' and not expected['miss'] else 0)
    for field, value in dict(operations=operations, processed_tuples=processed,
                             returned_tuples=returned, tuples=processed + returned).items():
        require(integer(result[field], field) == value, f'{field}: wrong work units')
    for field in ('packed_bytes', 'leaf_count', 'compressed_leaf_count', 'prefix_bytes'):
        integer(result[field], field)
    require(result['compressed_leaf_count'] <= result['leaf_count'], 'Invalid compressed leaf count')
    if not expected['pack_lexical'] or op in ('insert', 'overwrite'):
        require(result['compressed_leaf_count'] == 0 and result['prefix_bytes'] == 0,
                'Unexpected compressed leaves')


def logical_signature(result):
    return {field: result[field] for field in CONFIG_FIELDS + WORK_FIELDS}



def analyze(manifest):
    if manifest.get("complete") is not True:
        raise ValueError("Only complete campaigns may be analyzed")
    runs = manifest.get("runs")
    if not isinstance(runs, list) or not runs:
        raise ValueError("Campaign has no runs")
    plan = manifest.get("plan")
    plan = plan if isinstance(plan, dict) else None
    if plan is None:
        raise ValueError("Explicit campaign plan is required")
    validate_plan(plan)
    expected = {}
    if plan is not None:
        for case in plan["cases"]:
            if case["name"] in expected:
                raise ValueError("Duplicate planned case: " + case["name"])
            expected[case["name"]] = case
    groups, positions, warnings = {}, defaultdict(set), []
    for run in runs:
        name, profile = run["case"], run["profile"]
        if not isinstance(name, str) or not isinstance(profile, str):
            raise ValueError("Case and profile labels must be strings")
        rep = count(run["repeat"], name + "/repeat")
        position = count(run["position"], name + "/position")
        if position in positions[name, rep]:
            raise ValueError(f"Duplicate position: {name}/{rep}/{position}")
        positions[name, rep].add(position)
        samples = groups.setdefault(name, {}).setdefault(profile, {})
        if rep in samples:
            raise ValueError(f"Duplicate case/profile/repeat: {name}/{profile}/{rep}")
        definition = expected.get(name)
        require(definition is not None and profile in definition['profiles'], 'Unexpected case/profile')
        require(rep < plan.get('repeats', 6), 'Unexpected repetition')
        mapping = plan['profile_definitions'][profile]
        require(run.get('build') == mapping['build'] and run.get('profile_definition') == mapping,
                'Recorded profile/build mapping differs from plan')
        supported = run['prefix_supported']
        require(type(supported) is bool, 'Invalid prefix support metadata')
        require(supported or not (mapping['compression'] or mapping['read_lexical']),
                'Unsupported prefix flags')
        validate_result(run['result'], expected_config(plan, definition, rep, mapping, supported))
        order = list(itertools.permutations(definition['profiles']))
        require(position < len(definition['profiles']) and order[rep % len(order)][position] == profile,
                'Unplanned profile position')
        perf = run.get('perf') or {}
        if manifest.get('perf_events'):
            for event, value in perf.items():
                require(99 <= finite_number(value.get('coverage'), event) <= 100, 'Invalid counter coverage')
                finite_number(value.get('value'), event)
            for event in ('cpu_core/cycles/u', 'cpu_core/instructions/u', 'task-clock'):
                finite_number(perf.get(event, {}).get('value'), event, positive=True)
        else:
            require(not perf, 'Unexpected counters in no-perf campaign')
        normalized = dict(run, repeat=rep, position=position)
        samples[rep] = sample(normalized, warnings)
    if expected and set(groups) != set(expected):
        raise ValueError("Completed cases differ from the embedded plan")
    cases = {}
    for name, profiles in groups.items():
        repeats = set(next(iter(profiles.values())))
        if any(set(samples) != repeats for samples in profiles.values()):
            raise ValueError(f"{name}: profiles have different repetition sets")
        definition = expected.get(name)
        if definition is not None:
            if set(profiles) != set(definition["profiles"]):
                raise ValueError(f"{name}: profiles differ from the embedded plan")
            if len(repeats) != count(plan.get("repeats", 6), "plan/repeats", positive=True):
                raise ValueError(f"{name}: repetition count differs from plan")
            for samples in profiles.values():
                for observation in samples.values():
                    result = observation["result"]
                    for field in ("pattern", "operation", "batches", "scan_length",
                                  "insert_order", "miss"):
                        if field in definition and field in result:
                            expected_value = definition[field]
                            if field == "scan_length" and expected_value == "full":
                                expected_value = result["keys"]
                            if expected_value != result[field]:
                                raise ValueError(f"{name}: result {field} differs from plan")
                    if ("ops" in definition and "requested_ops" in result
                            and definition["ops"] != result["requested_ops"]):
                        raise ValueError(f"{name}: requested operations differ from plan")
        for rep in repeats:
            signatures = [logical_signature(samples[rep]['result']) for samples in profiles.values()]
            require(all(signature == signatures[0] for signature in signatures),
                    f'{name}/{rep}: unequal paired logical work')
        summaries = {}
        for profile, samples in profiles.items():
            ordered = [samples[rep] for rep in sorted(samples)]
            metric_names = set().union(*(s["metrics"] for s in ordered))
            metrics = {m: describe(s["metrics"][m] for s in ordered
                                    if m in s["metrics"])
                       for m in sorted(metric_names)}
            ops = sum(s["operations"] for s in ordered)
            tuples = sum(s["tuples"] for s in ordered)
            wall = sum(s["metrics"]["active_wall_ns"] for s in ordered)
            cpu = sum(s["metrics"]["process_cpu_ns"] for s in ordered)
            summaries[profile] = {
                "n": len(ordered), "samples": ordered, "metrics": metrics,
                "aggregate": {
                    "operations": ops, "tuples": tuples,
                    "active_wall_ns": wall, "process_cpu_ns": cpu,
                    "ops_s": 1e9 * ops / wall, "tuples_s": 1e9 * tuples / wall,
                    "wall_ns_per_operation": wall / ops,
                    "cpu_ns_per_operation": cpu / ops,
                },
            }
        comparisons = {}
        for candidate, reference in definition.get('comparisons', plan.get('comparisons')):
            if candidate not in profiles or reference not in profiles:
                continue
            metric_names = set().union(
                *(s["metrics"] for p in (candidate, reference)
                  for s in profiles[p].values()))
            comparisons[candidate + "/" + reference] = {
                "candidate": candidate, "reference": reference,
                "metrics": {m: paired_metric(profiles[reference],
                                               profiles[candidate], m)
                            for m in sorted(metric_names)},
            }
        if len(repeats) < 6:
            warnings.append(f"{name}: only {len(repeats)} repetitions; exploratory")
        if not comparisons:
            warnings.append(f"{name}: no requested profile comparison is available")
        operations = {s["result"]["operation"] for samples in profiles.values()
                      for s in samples.values()}
        if len(operations) != 1:
            raise ValueError(f"{name}: different operations were grouped in one case")
        operation = next(iter(operations))
        cases[name] = {"definition": definition, "repeats": sorted(repeats),
                       "operation": operation,
                       "primary_rate": "tuples_s" if operation == "pack" else "ops_s",
                       "profiles": summaries, "comparisons": comparisons}
    return {
        "schema_version": 1,
        "method": {
            "pairing": "Same case and repetition; candidate/reference ratios",
            "estimate": "Geometric mean of paired ratios",
            "interval": "Nominal two-sided 95% Student-t interval on log ratios",
            "assumptions": "Independent paired log differences; small-sample observational model",
            "limitations": [
                "Intervals are not guaranteed bounds or simultaneous confidence statements.",
                "No multiple-comparison correction; nonlinear host drift can remain.",
                "A nonsignificant result does not establish equivalence.",
                "Cases and campaigns are never pooled.",
                "Phase perf includes interval-control overhead; tiny costs are not intrinsic API-only costs.",
                "Pack operations count pack calls; tuples/s is the primary packing rate.",
                "Raw tree census fields describe the harness output, not totals across batches.",
                "Positive throughput change is faster; positive time/cost change is worse.",
            ],
            "resource_scopes": {
                "active_wall_ns/process_cpu_ns": "Direct active-operation clock brackets; primary wall and CPU measurements",
                "user_cpu_ns/system_cpu_ns": "Broader rusage snapshots also include perf handshakes and resource-snapshot overhead",
                "perf": "Enabled separately for active intervals, excluding verification/reclamation and /proc/getrusage snapshots, but including timer/FIFO bracket overhead",
                "resident_checks": "Process I/O/fault snapshots plus direct I/O guards; all reported active I/O and major-fault counts must be zero",
            },
            "aggregate_rates": "Descriptive totals divided by total time; comparisons use paired ratios instead",
        },
        "plan": plan, "cases": cases, "warnings": warnings,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    raw = args.manifest.read_bytes()
    summary = analyze(json.loads(raw))
    summary["provenance"] = {
        "manifest": str(args.manifest.resolve()),
        "manifest_sha256": hashlib.sha256(raw).hexdigest(),
        "analysis": str(Path(__file__).resolve()),
        "analysis_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    encoded = json.dumps(summary, indent=2, allow_nan=False) + "\n"
    with args.output.open("x") as stream:
        stream.write(encoded)
    print(args.output)


if __name__ == "__main__":
    main()
