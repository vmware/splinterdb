# Async I/O buffer alignment: reproduced defect and isolated repair

The selected read changes exposed a preexisting production alignment defect
through the new immutable custom-comparator regression. The same failure was
reproduced on the unchanged `b9cc3ea4` candidate with the identical test overlay
and ASan/UBSan flags. A separate selected-derived repair passes all 36 focused
sanitizer tests and the formerly failing cold-read test in release, debug, and
fault-injection builds: 39 passing executions. No live or previously frozen
sources were changed, and no benchmark was run for this repair here.

Original failures are preserved under
`../validation/combined-read-blob-v1-postconfirmation-extra/` and
`../validation/baseline-alignment-reproduction/`. In both, UBSan reports
`laio.c:758:32`, native state address `0x525000000384`, and an eight-byte
alignment requirement. The stack reaches this write during the first cold
`core_range_iterator_init` after close/reopen, before the new test's direct
point probes or deliberate malformed-key checks. The test uses ordinary core
iterator APIs; it does not allocate or supply the I/O state buffer itself.

`src/platform_linux/platform_io.h:74` originally defines the opaque storage as
`uint8[1024]`, whose alignment is one. `clockcache_get_async_state` embeds this
array immediately after a four-byte `platform_status rc`. Debug type records
show the array at offset 116, which is four modulo eight. Alignment of the
outer cache-state payload therefore does not align this interior field.
`laio_async_state_init` casts the buffer to `laio_async_state`, requiring eight
byte alignment, and its first member access triggers UBSan. A correctly aligned
outer state is insufficient to satisfy that cast.

The exact baseline runtime manifest matches all 166 relevant files in the
`b9cc3ea4` source archive. Frozen main `6105c49f` also has the identical unaligned
typedef and the same `rc`-then-`iostate` member order. The main observation is a
source comparison; the controlled failing runtime reproduction used
`b9cc3ea4`, not main.

The minimal repair keeps the opaque byte array and its 1024-byte size, but gives
its typedef `_Alignof(max_align_t)` alignment. This makes embedded, stack, and
array instances satisfy the native backend's alignment. `max_align_t` is already
provided through the directly included `platform_util.h` and `<stddef.h>`.
A new static assertion next to the backend's existing size assertion checks
that the opaque buffer's alignment covers `laio_async_state`. Existing cache
payload size/alignment assertions continue to pass. No validation check or
error path is removed.

The GNU aligned typedef preserves array decay in the existing I/O functions.
It changes private native structure padding, so dependent objects must be
rebuilt together. On this target, `clockcache_get_async_state.iostate` moves
from offset 116 to 128, and the state grows from 1192 to 1200 bytes inside the
unchanged 2048-byte opaque cache payload. The separate writeback
`async_io_state` grows from 1032 to 1040 bytes. No public installed API header or
persisted layout changes. Source review found no new operation in the resident
read algorithm, but repaired binaries still need their own performance check.

The repair source is frozen separately at
`.cache/btree-nonlexical-20261016/variants/selected-io-alignment`.
`async-io-alignment-from-selected.patch` is the two-file runtime delta;
`selected-io-alignment.patch` contains the combined read changes and that repair
against `b9cc3ea4`. `selected-io-alignment.json` records preparation provenance;
its initial validation-in-progress status is superseded by
`repair-validation/summary.json` and `resolution.json`.
`repair-runtime-sources.json` contains every relevant runtime source hash.
Tests were overlaid only in a separate validation clone.

The sanitizer run used address and undefined-behavior checks with fatal errors
and no recovery. No sanitizer suppressions were added. LeakSanitizer remained
disabled under the previously declared validation setting; this result is not
a leak-check pass. All 36 requested sanitizer executions passed, including
large/blob values, malformed leaf and trunk checks, immutable comparator
sync/async hit/miss probes, bidirectional scans/seeks, copied iterator tests,
and pack/error cleanup. The same new cold-read regression also passed once
each in release, debug, and memory-fault-injection builds.

`run_repair.py` and the frozen validation helper record commands, binaries,
compiler options, logs, and source/timed-artifact invariants. The original
failed runs were not edited or reclassified. Independent source review by
`scan_optimizations` passed the storage contract, dependency, and private ABI
assessment. All reproduction and repair sessions exited and were reaped.
