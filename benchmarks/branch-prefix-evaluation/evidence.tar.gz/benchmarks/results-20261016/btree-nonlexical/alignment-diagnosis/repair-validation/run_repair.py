#!/usr/bin/env python3
"""Isolate and validate the opaque async-I/O storage alignment repair."""
from argparse import Namespace
import difflib
import fcntl
import importlib.util
import json
from pathlib import Path
import shutil
import signal
import subprocess
import tarfile
import time

HERE = Path(__file__).resolve().parent
ARCHIVE = HERE.parent
ROOT = HERE.parents[3]
VARIANT = 'selected-io-alignment'
HELPER = ARCHIVE / 'validate_selected.py'
spec = importlib.util.spec_from_file_location('selected_validation', HELPER)
validation = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validation)


def formatted(before, after, path):
    ranges = [(j1 + 1, j2) for op, i1, i2, j1, j2 in
              difflib.SequenceMatcher(None, before.splitlines(), after.splitlines(),
                                      autojunk=False).get_opcodes()
              if op != 'equal' and j2 > j1]
    command = ['clang-format-19', '--style=file', '--assume-filename=' + str(path)]
    command.extend(f'--lines={a}:{b}' for a, b in ranges)
    result = subprocess.check_output(command, input=after, text=True)
    return result, command


def change(before, after, filename):
    return ''.join(difflib.unified_diff(
        before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile='a/' + filename, tofile='b/' + filename))


def main():
    args = Namespace(jobs=6, cc='gcc', minimum_free_gib=12,
                     test_timeout=1200, build_timeout=3600, leak_detection=False)
    archive = HERE / 'repair-validation'
    scratch = ROOT / '.cache/btree-nonlexical-20261016/alignment-repair'
    tree = ROOT / '.cache/btree-nonlexical-20261016/variants' / VARIANT
    archive.mkdir(parents=True, exist_ok=False)
    scratch.mkdir(parents=True, exist_ok=False)
    assert not tree.exists(), tree
    (archive / 'run_repair.py').write_bytes(Path(__file__).read_bytes())
    (archive / 'validate_selected.py').write_bytes(HELPER.read_bytes())
    builds = json.loads((ARCHIVE / 'build.json').read_text())
    selected = builds['combined-read-blob-v1']
    metadata_path = ARCHIVE / 'read-design/combined-read-blob-v1.json'
    parent = json.loads(metadata_path.read_text())
    patch = ARCHIVE / 'proposals/selected-read-tests-v1.patch'
    frozen_patch = archive / 'selected-read-tests-v1.patch'
    frozen_patch.write_bytes(patch.read_bytes())
    validation.save(archive / 'invocation.json', dict(
        parent=selected, parent_metadata_sha256=validation.sha(metadata_path),
        validation_helper_sha256=validation.sha(HELPER),
        test_patch_sha256=validation.sha(frozen_patch),
        args=vars(args), stages=['sanitizers', 'release', 'debug', 'fault'],
        focused_case='test_immutable_branch_custom_comparator'))
    result = dict(passed=False, started=time.time(), variant=VARIANT,
                  stages={}, tree=str(tree), scratch=str(scratch))
    val = validation.Validation(args, archive, scratch, tree)
    parent_before, timed_before, source_before, repair_sources = None, None, None, None
    print('Waiting for exclusive machine lock', flush=True)
    with validation.MACHINE_LOCK.open('rb') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        result['lock_acquired'] = time.time()
        try:
            val.free_guard()
            fs = json.loads(subprocess.check_output(
                ['findmnt', '-T', str(scratch), '-J', '-o', 'SOURCE,FSTYPE,TARGET'],
                text=True))['filesystems'][0]
            assert fs['source'].startswith('/dev/') and fs['fstype'] not in ('tmpfs', 'ramfs')
            validation.save(archive / 'storage.json', fs)
            parent_tree = Path(selected['tree'])
            parent_before = validation.source_manifest(parent_tree)
            for name, digest in selected['source_files_sha256'].items():
                assert parent_before[name] == digest, name
            timed_before = {selected[k]: validation.sha(selected[k])
                            for k in ('binary', 'library')}
            validation.save(archive / 'parent-sources-before.json', parent_before)
            validation.save(archive / 'parent-timed-before.json', timed_before)
            source_archive = Path(parent['source_archive'])
            assert validation.sha(source_archive) == parent['source_archive_sha256']
            tree.mkdir()
            with tarfile.open(source_archive) as tar:
                tar.extractall(tree, filter='data')
            base_btree = (tree / 'src/btree.c').read_text()
            (tree / 'src/btree.c').write_bytes((parent_tree / 'src/btree.c').read_bytes())
            assert validation.source_manifest(tree) == parent_before
            edits = {}
            name = 'src/platform_linux/platform_io.h'
            before = (tree / name).read_text()
            old = 'typedef uint8 io_async_state_buffer[IO_ASYNC_STATE_BUFFER_SIZE];'
            new = '''/* Backends store their native async state in this opaque byte buffer. Its
 * alignment must hold when embedded after a smaller field in another state. */
typedef uint8 io_async_state_buffer[IO_ASYNC_STATE_BUFFER_SIZE]
   __attribute__((aligned(_Alignof(max_align_t))));'''
            assert before.count(old) == 1
            edits[name] = (before, before.replace(old, new))
            name = 'src/platform_linux/laio.c'
            before = (tree / name).read_text()
            old = '''   "laio_async_read_state is to large for IO_ASYNC_STATE_BUFFER_SIZE");
'''
            new = old + '''_Static_assert(_Alignof(laio_async_state) <= _Alignof(io_async_state_buffer),
               "io_async_state_buffer has insufficient alignment");
'''
            assert before.count(old) == 1
            edits[name] = (before, before.replace(old, new))
            commands = {}
            for name, (before, after) in list(edits.items()):
                after, commands[name] = formatted(before, after, tree / name)
                repeated, _ = formatted(before, after, tree / name)
                assert after == repeated
                (tree / name).write_text(after)
                edits[name] = (before, after)
            delta = ''.join(change(a, b, name) for name, (a, b) in edits.items())
            full = change(base_btree, (tree / 'src/btree.c').read_text(), 'src/btree.c') + delta
            delta_path = HERE / 'async-io-alignment-from-selected.patch'
            full_path = HERE / 'selected-io-alignment.patch'
            delta_path.write_text(delta)
            full_path.write_text(full)
            for path in (delta_path, full_path):
                subprocess.run(['git', 'apply', '--reverse', '--check', str(path)],
                               cwd=tree, check=True)
            repair_sources = validation.source_manifest(tree)
            validation.save(HERE / 'selected-io-alignment.json', dict(
                variant=VARIANT, tree=str(tree), parent='combined-read-blob-v1',
                base_commit=parent['base_commit'],
                parent_btree_sha256=parent['btree_sha256'],
                source_files_sha256=repair_sources,
                changed_runtime_files=list(edits),
                delta_patch=str(delta_path), delta_sha256=validation.sha(delta_path),
                full_patch=str(full_path), full_sha256=validation.sha(full_path),
                formatter_commands=commands, formatting_idempotent=True,
                validation_status='in progress', created=time.time()))
            validation_tree = scratch / 'source'
            shutil.copytree(tree, validation_tree)
            assert validation.source_manifest(validation_tree) == repair_sources
            val.tree = validation_tree
            result['validation_tree'] = str(validation_tree)
            val.run('test-overlay-check', ['git', 'apply', '--check', str(frozen_patch)], validation_tree)
            val.run('test-overlay-apply', ['git', 'apply', str(frozen_patch)], validation_tree)
            source_before = validation.source_manifest(validation_tree)
            assert [name for name in source_before
                    if source_before[name] != repair_sources[name]] == [
                        'tests/unit/splinterdb_quick_test.c']
            validation.save(archive / 'sources-before.json', source_before)
            result['stages']['sanitizers'] = 'running'
            val.stage('sanitizers')
            result['stages']['sanitizers'] = 'passed'
            for stage in ('release', 'debug', 'fault'):
                result['stages'][stage] = 'running'
                validation.save(archive / 'summary.json', result)
                build = val.build(stage)
                val.test(stage, build, 'splinterdb_quick',
                         'test_immutable_branch_custom_comparator')
                result['stages'][stage] = 'passed'
            result['passed'] = True
        except BaseException as error:
            result['error'] = repr(error)
            raise
        finally:
            if parent_before is not None:
                after = validation.source_manifest(Path(selected['tree']))
                validation.save(archive / 'parent-sources-after.json', after)
                result['parent_sources_unchanged'] = parent_before == after
                result['passed'] &= result['parent_sources_unchanged']
            if timed_before is not None:
                after = {p: validation.sha(p) for p in timed_before}
                validation.save(archive / 'parent-timed-after.json', after)
                result['parent_timed_unchanged'] = timed_before == after
                result['passed'] &= result['parent_timed_unchanged']
            if repair_sources is not None:
                after = validation.source_manifest(tree)
                validation.save(archive / 'repair-sources-after.json', after)
                result['repair_sources_unchanged'] = repair_sources == after
                result['passed'] &= result['repair_sources_unchanged']
            if source_before is not None:
                after = validation.source_manifest(val.tree)
                validation.save(archive / 'sources-after.json', after)
                result['sources_unchanged'] = source_before == after
                result['passed'] &= result['sources_unchanged']
            result.update(finished=time.time(), unit_test_executions=sum(
                item['ok'] for row in val.records for item in row['summaries']))
            validation.save(archive / 'summary.json', result)
            validation.save(archive / 'sha256.json', {p.name: validation.sha(p)
                for p in sorted(archive.iterdir())
                if p.is_file() and p.name != 'sha256.json'})
    assert result['passed'], archive
    print('Repair validation complete: ' + str(result['unit_test_executions'])
          + ' passed executions; ' + str(archive), flush=True)


if __name__ == '__main__':
    def interrupted(signum, frame):
        raise KeyboardInterrupt(f'signal {signum}')
    signal.signal(signal.SIGTERM, interrupted)
    main()
