#!/usr/bin/env python3
"""Verify final source application and validation evidence after campaign audit.

Do not execute during timing. This companion leaves recorded audit/build/test
tools unchanged, starts no workloads, and takes both coordination locks. Failed
sanitizer reproductions are required evidence, not converted into test passes.
"""
import argparse
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('campaign_audit', HERE / 'audit_v2.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
require, load = audit.require, audit.load
FAILED_CASE = 'sanitizers-splinterdb_quick-test_immutable_branch_custom_comparator'
COUNTS = re.compile(r'RESULTS: (\d+) tests \((\d+) ok, (\d+) failed, (\d+) skipped\)')
RUNS = (
    ('validation/combined-read-blob-v1-preconfirmation-release', True, 87,
     {'release': 'passed'}),
    ('validation/combined-read-blob-v1-postconfirmation-extra', False, 144,
     {'debug': 'passed', 'fault': 'passed', 'sanitizers': 'running'}),
    ('validation/baseline-alignment-reproduction', False, 21,
     {'sanitizers': 'running'}),
    ('alignment-diagnosis/repair-validation', True, 39,
     {'sanitizers': 'passed', 'release': 'passed', 'debug': 'passed', 'fault': 'passed'}),
)


def relative_path(value):
    path = Path(value)
    require(not path.is_absolute() and '..' not in path.parts,
            'Unsafe relative path: ' + value)
    return path


def check_map(hashes, root, values, role):
    require(values, 'Missing hash map: ' + role)
    for name, expected in values.items():
        hashes.check(root / relative_path(name), expected, role)


def validation_run(hashes, name, expected_pass, expected_count, expected_stages):
    folder = HERE / name
    recorded = load(folder / 'sha256.json')
    require(set(recorded) == {p.name for p in folder.iterdir()
                              if p.is_file() and p.name != 'sha256.json'},
            'Unrecorded/missing validation archive files: ' + name)
    check_map(hashes, folder, recorded, name + '/original-archive-hash')
    hashes.check(folder / 'sha256.json', None, name + '/hash-map-observed')
    summary, rows = load(folder / 'summary.json'), load(folder / 'results.json')
    require(rows and len({row['name'] for row in rows}) == len(rows),
            'Missing or duplicate validation rows: ' + name)
    require(summary['passed'] is expected_pass and summary['stages'] == expected_stages,
            'Unexpected validation outcome: ' + name)
    require(summary['finished'] >= summary['lock_acquired'] >= summary['started'],
            'Invalid validation lifecycle: ' + name)
    failures, count = [], 0
    by_stage = {}
    for row in rows:
        log = folder / relative_path(row['log'])
        hashes.check(log, row['log_sha256'], name + '/recorded-log')
        text = log.read_text()
        parsed = [dict(tests=int(a), ok=int(b), failed=int(c), skipped=int(d))
                  for a, b, c, d in COUNTS.findall(text)]
        require(parsed == row['summaries'], 'Raw/recorded test summary mismatch')
        require(not row.get('exception') and not row.get('leftover_process_group'),
                'Runner/process cleanup failure: ' + name + '/' + row['name'])
        if row['expected'] in ('unit', 'single'):
            require(isinstance(row.get('binary_sha256'), str)
                    and len(row['binary_sha256']) == 64,
                    'Missing recorded test binary identity')
        if row.get('binary_sha256'):
            hashes.check(row['command'][0], row['binary_sha256'], name + '/test-binary')
        if row['passed']:
            require(row['returncode'] == 0, 'Passing row has nonzero exit')
            if row['expected'] == 'single':
                require(parsed == [dict(tests=1, ok=1, failed=0, skipped=0)],
                        'Focused test count mismatch')
            elif row['expected'] == 'unit':
                require(len(parsed) == 1 and parsed[0]['tests'] > 0
                        and parsed[0]['ok'] == parsed[0]['tests']
                        and parsed[0]['failed'] == parsed[0]['skipped'] == 0,
                        'Full suite count mismatch')
        else:
            failures.append(row['name'])
            require(row['name'] == FAILED_CASE and row['returncode'] == 1 and not parsed,
                    'Unexpected failure: ' + name + '/' + row['name'])
            require('laio.c:758:32: runtime error: member access within misaligned address' in text
                    and "type 'struct laio_async_state', which requires 8 byte alignment" in text
                    and 'core_range_iterator_init' in text,
                    'Expected original alignment failure missing')
        row_count = sum(v['ok'] for v in parsed)
        count += row_count
        stage = row['name'].split('-', 1)[0]
        by_stage[stage] = by_stage.get(stage, 0) + row_count
        if row['name'].startswith('sanitizers-'):
            env = row['environment']
            if row['name'] == 'sanitizers-build':
                require(env.get('CFLAGS') == '-fsanitize=undefined -fno-sanitize-recover=all -fno-omit-frame-pointer'
                        and env.get('LDFLAGS') == '-fsanitize=undefined'
                        and 'BUILD_ASAN=1' in row['command'],
                        'Changed sanitizer compiler settings')
            else:
                require(env.get('ASAN_OPTIONS') == 'detect_leaks=0:halt_on_error=1'
                        and env.get('UBSAN_OPTIONS') == 'halt_on_error=1:print_stacktrace=1',
                        'Changed sanitizer runtime settings')
    require(failures == ([] if expected_pass else [FAILED_CASE]),
            'Unexpected validation failure list')
    require(count == summary['unit_test_executions'] == expected_count,
            'Passing test execution count mismatch')
    expected_stage_counts = ({'release': 87} if expected_count == 87 else
        {'debug': 87, 'fault': 36, 'sanitizers': 21} if expected_count == 144 else
        {'sanitizers': 21} if expected_count == 21 else
        {'sanitizers': 36, 'release': 1, 'debug': 1, 'fault': 1})
    require({stage: count for stage, count in by_stage.items() if count} == expected_stage_counts,
            'Per-stage validation coverage mismatch')
    stage_files = list(folder.glob('*-build-files.json'))
    require({p.name for p in stage_files} ==
            {stage + '-build-files.json' for stage in expected_stages},
            'Missing or extra build artifact hash map')
    for stage in expected_stages:
        require(sum(row['name'] == stage + '-build' for row in rows) == 1,
                'Missing or duplicate stage build record')
    for stage_file in stage_files:
        stage = stage_file.name.removesuffix('-build-files.json')
        mode = stage if stage in ('release', 'debug') else 'debug'
        build = Path(summary['scratch']) / ('build-' + stage) / (
            mode + ('-asan' if stage == 'sanitizers' else ''))
        check_map(hashes, build, load(stage_file), name + '/' + stage + '-artifacts')
    if name.endswith('repair-validation'):
        for field in ('parent_sources_unchanged', 'parent_timed_unchanged',
                      'repair_sources_unchanged', 'sources_unchanged'):
            require(summary[field] is True, 'Repair source/artifact invariant failed')
        require(by_stage['sanitizers'] == 36 and
                all(by_stage[x] == 1 for x in ('release', 'debug', 'fault')),
                'Repair validation coverage mismatch')
        parent = load(folder / 'invocation.json')['parent']
        before, after = load(folder / 'parent-sources-before.json'), load(folder / 'parent-sources-after.json')
        require(before == after, 'Repair parent sources changed')
        check_map(hashes, Path(parent['tree']), before, 'repair-parent-runtime')
        before, after = load(folder / 'parent-timed-before.json'), load(folder / 'parent-timed-after.json')
        require(before == after, 'Repair parent timed artifacts changed')
        for path, expected in before.items():
            hashes.check(path, expected, 'repair-parent-timed')
        check_map(hashes, Path(summary['tree']), load(folder / 'repair-sources-after.json'),
                  'repair-frozen-runtime')
        source_prefix, source_root = 'sources-', Path(summary['validation_tree'])
    else:
        for field in ('sources_match_timed_build', 'sources_unchanged',
                      'timed_files_unchanged', 'validation_sources_unchanged'):
            require(summary[field] is True, 'Validation source/artifact invariant failed')
        before, after = load(folder / 'sources-before.json'), load(folder / 'sources-after.json')
        require(before == after, 'Frozen sources changed during validation')
        check_map(hashes, Path(summary['tree']), before, name + '/frozen-runtime')
        before, after = load(folder / 'timed-files-before.json'), load(folder / 'timed-files-after.json')
        require(before == after, 'Frozen artifacts changed during validation')
        for path, expected in before.items():
            hashes.check(path, expected, name + '/frozen-artifacts')
        source_prefix, source_root = 'validation-sources-', Path(summary['validation_tree'])
    before, after = load(folder / (source_prefix + 'before.json')), load(folder / (source_prefix + 'after.json'))
    require(before == after, 'Validated source clone changed')
    check_map(hashes, source_root, before, name + '/validated-source')
    return dict(name=name, original_run_passed=expected_pass, integrity_passed=True,
                passing_test_executions=count, expected_failures=failures,
                by_stage=by_stage)


def applied_sources(hashes):
    application = load(HERE / 'application.json')
    hashes.check(HERE / 'application.json', None, 'application-record-observed')
    require(application['variant'] == 'selected-io-alignment', 'Unexpected applied variant')
    for filename, expected in application['patches'].items():
        hashes.check(ROOT / relative_path(filename), expected, 'applied-patch')
    repair = load(HERE / 'alignment-diagnosis/selected-io-alignment.json')
    tree = Path(repair['tree'])
    measured = load(HERE / 'build.json')['selected-io-alignment']
    measured_inventory = {name: digest for name, digest in repair['source_files_sha256'].items()
                          if name == 'Makefile' or Path(name).parts[0] in ('src', 'include', 'tests')}
    require(measured['source_files_sha256'] == measured_inventory,
            'Final measured runtime inventory differs from validated repair')
    expected_files = {'src/btree.c', 'src/platform_linux/platform_io.h',
                      'src/platform_linux/laio.c', 'tests/unit/splinterdb_quick_test.c'}
    require(set(application['files']) == expected_files, 'Unexpected application file scope')
    validation = load(HERE / 'alignment-diagnosis/repair-validation/summary.json')
    validation_tree = Path(validation['validation_tree'])
    for name, record in application['files'].items():
        hashes.check(ROOT / name, record['live_sha256'], 'final-live-source')
        original = (validation_tree if name.startswith('tests/') else tree) / name
        hashes.check(original, record['validated_sha256'], 'validated-application-source')
        if name == 'src/btree.c':
            before = original.read_text()
            old = '   if (offset < hdr->next_entry || page_size < offset + min_size)\n   {\n'
            new = '   if (offset < hdr->next_entry || page_size < offset + min_size) {\n'
            require(before.count(old) == 1 and (ROOT / name).read_text() == before.replace(old, new),
                    'Live B-tree differs beyond recorded one-brace formatting change')
            require(record['whitespace_only_difference'] is True and record['identical'] is False,
                    'Incorrect formatting provenance')
        else:
            require((ROOT / name).read_bytes() == original.read_bytes()
                    and record['identical'] is True, 'Live application mismatch')
    # Extend the four-file application check to every inventoried runtime input.
    # This rejects later unrelated live source changes to the measured variant.
    for name, expected in repair['source_files_sha256'].items():
        hashes.check(tree / relative_path(name), expected, 'final-frozen-source')
        if name not in application['files']:
            hashes.check(ROOT / relative_path(name), expected, 'final-live-unchanged-source')
    return dict(variant=application['variant'], files=application['files'],
                runtime_inventory_files=len(repair['source_files_sha256']),
                measured_runtime_inventory_files=len(measured_inventory),
                application_record_confirmation_pending=application['performance_confirmation_pending'],
                scope='Application record is historical; performance completion is checked against the final campaign audit.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign-audit', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=HERE / 'audit-final.json')
    args = parser.parse_args()
    require(not args.output.exists(), 'Refusing to overwrite final audit')
    report = dict(started=time.time(), passed=False, errors=[], validations=[],
                  scope='Validation integrity and expected failures, final live sources, and completed all-campaign audit; no performance significance claim')
    hashes = audit.Hashes()
    try:
        os.sched_setaffinity(0, {19})
    except OSError:
        pass
    print('Waiting for exclusive benchmark.lock and machine.lock', flush=True)
    with (audit.COORD / 'benchmark.lock').open('rb') as bench, (audit.COORD / 'machine.lock').open('rb') as machine:
        fcntl.flock(bench, fcntl.LOCK_EX)
        fcntl.flock(machine, fcntl.LOCK_EX)
        try:
            previous = load(args.campaign_audit)
            hashes.check(args.campaign_audit, None, 'completed-campaign-audit')
            hashes.check(HERE / 'audit_v2.py', previous['auditor_sha256'],
                         'completed-campaign-auditor')
            require(previous['passed'] is True and not previous['errors'], 'Campaign audit failed')
            actual = {p.name for p in HERE.iterdir() if (p / 'manifest.json').is_file()}
            require({r['name'] for r in previous['campaigns']} == actual,
                    'Campaign audit did not cover every current campaign')
            require('confirmation-aligned' in actual, 'Final aligned confirmation missing')
            for filename, record in previous['files'].items():
                hashes.check(filename, record['sha256'], 'unchanged-since-campaign-audit')
            for row in RUNS:
                report['validations'].append(validation_run(hashes, *row))
            report['application'] = applied_sources(hashes)
            report['campaigns'] = previous['counts']
            report['sanitizers'] = dict(address=True, undefined=True, recover=False,
                                        added_suppressions=[], leak_detection=False)
            report['passed'] = True
        except (audit.AuditError, OSError, KeyError, TypeError, ValueError) as error:
            report['errors'].append(repr(error))
        for filename in tuple(hashes.files):
            try:
                hashes.check(filename, None, 'final-identity-recheck')
            except (audit.AuditError, OSError) as error:
                report['errors'].append(repr(error))
                report['passed'] = False
        report.update(finished=time.time(), files=hashes.files,
                      auditor_sha256=hashes.check(Path(__file__), None, 'final-auditor'),
                      campaign_auditor_sha256=hashes.check(HERE / 'audit_v2.py', None, 'campaign-auditor'))
        with args.output.open('x') as stream:
            json.dump(report, stream, indent=2, allow_nan=False)
            stream.write('\n')
    print(json.dumps(dict(output=str(args.output), passed=report['passed'], errors=report['errors']), indent=2))
    raise SystemExit(0 if report['passed'] else 1)


if __name__ == '__main__':
    main()
