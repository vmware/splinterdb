#!/usr/bin/env python3
"""Validate a frozen selected variant without rebuilding its timed artifacts.

This is an explicit runner, not an automatically launched campaign. Release and
debug run the full existing B-tree and quick API suites plus focused core/error
tests. Fault and sanitizer stages run the focused selection. ASAN+UBSAN are
enabled together; leak detection defaults off because the previous sandbox
capability probe could not perform LeakSanitizer process inspection.
"""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import tempfile
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SCRATCH = ROOT / '.cache/btree-nonlexical-20261016'
MACHINE_LOCK = Path('/home/rob/projects/splinterdb/.cache/projects-20261011/coordination/machine.lock')
SUMMARY = re.compile(r'RESULTS: (\d+) tests \((\d+) ok, (\d+) failed, (\d+) skipped\)')
QUICK_TESTS = (
    'test_branch_prefix_variable_iterator',
    'test_branch_prefix_roundtrip',
    'test_branch_prefix_minimum',
    'test_branch_prefix_malformed_leaf_entries',
    'test_iterator_custom_comparator',
    'test_range_init_error_cleanup_preserves_branches',
    'test_bounded_iterator_start_normalization',
    'test_iterator_prev_and_next',
)
SUPPLEMENTAL_QUICK_TESTS = ('test_immutable_branch_custom_comparator',)
CORE_TESTS = (
    'test_blob_checksums',
    'test_blob_descriptor_sizes',
    'test_btree_pack_abort_releases_reserved_extents',
    'test_btree_pack_rejects_counter_overflow',
    'test_malformed_trunk_pivot_bundle',
    'test_invalid_branch_reference_rejected',
    'test_malformed_trunk_pivot_stats',
    'test_malformed_trunk_child_height',
    'test_cache_read_errors_reach_core_operations',
)
STRESS_TESTS = (
    'iterator_endpoint_error_is_returned_by_init',
    'count_in_range_returns_lookup_error',
    'copied_iterator_bounds',
    'copied_iterator_split_on_release',
    'copied_iterator_prefetch',
)
CORE_OPTIONS = ('--db-location', 'core.db', '--cache-capacity-mib', '128',
                '--db-capacity-gib', '64')
COVERAGE_LIMITATIONS = (
    'The base custom-comparator quick test does not force an immutable packed '
    'branch; the optional immutable-branch test overlay addresses this scope '
    'only when present and passing.',
    'Base malformed leaf tests exercise iterator rejection; the optional '
    'immutable-branch overlay adds sync/async point rejection of a corrupt key '
    'extent, not an exhaustive malformed-page matrix.',
    'Pack-abort coverage injects input iterator I/O failure after one tuple; it '
    'does not inject allocation failure during recursive compressed-pivot creation.',
)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    tmp = path.with_suffix(path.suffix + '.new')
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    tmp.replace(path)


def source_manifest(tree):
    files = [tree / 'Makefile', tree / '.clang-format']
    for folder in ('src', 'include', 'tests', 'tools', 'examples'):
        files.extend(p for p in (tree / folder).rglob('*') if p.is_file())
    return {str(p.relative_to(tree)): sha(p) for p in sorted(files) if p.is_file()}


def stop_group(proc):
    # Kill the group even when the leader has already exited.
    for sig in (signal.SIGTERM, signal.SIGKILL):
        try:
            os.killpg(proc.pid, sig)
        except ProcessLookupError:
            pass
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            pass
    proc.wait()


class Validation:
    def __init__(self, args, archive, scratch, tree):
        self.args, self.archive, self.scratch, self.tree = args, archive, scratch, tree
        self.records = []
        self.environment = dict(os.environ)
        # Reproducible build selection: no inherited make flags or sanitizer
        # options silently change a requested stage.
        for name in ('MAKEFLAGS', 'MFLAGS', 'BUILD_ROOT', 'BUILD_MODE', 'BUILD_ASAN',
                     'BUILD_MSAN', 'BUILD_MEMORY_FAULT_INJECTION', 'CC', 'CFLAGS',
                     'CPPFLAGS', 'LDFLAGS', 'ASAN_OPTIONS', 'UBSAN_OPTIONS'):
            self.environment.pop(name, None)

    def free_guard(self):
        free = shutil.disk_usage(self.scratch).free
        if free < self.args.minimum_free_gib * 1024**3:
            raise RuntimeError(f'Free-space guard: only {free} bytes available')

    def run(self, name, command, cwd, *, environment=None, timeout=None, expected=None):
        self.free_guard()
        command = list(map(str, command))
        env = dict(self.environment if environment is None else environment)
        timeout = timeout or self.args.test_timeout
        log = self.archive / (name + '.log')
        row = dict(name=name, command=command, cwd=str(cwd), started=time.time(),
                   timeout_seconds=timeout, expected=expected,
                   environment={k: env[k] for k in ('TMPDIR', 'CFLAGS', 'LDFLAGS',
                                'ASAN_OPTIONS', 'UBSAN_OPTIONS') if k in env})
        if Path(command[0]).is_file():
            row['binary_sha256'] = sha(command[0])
        proc, error = None, None
        with log.open('x') as stream:
            try:
                proc = subprocess.Popen(command, cwd=cwd, env=env, stdout=stream,
                                        stderr=subprocess.STDOUT, start_new_session=True)
                row['pid'] = proc.pid
                row['returncode'] = proc.wait(timeout=timeout)
                try:
                    os.killpg(proc.pid, 0)
                except ProcessLookupError:
                    pass
                else:
                    row['leftover_process_group'] = True
                    raise RuntimeError('Command exited with owned descendants still running')
            except BaseException as caught:
                error = caught
                row['exception'] = repr(caught)
                if proc is not None:
                    stop_group(proc)
                    row['returncode'] = proc.returncode
                else:
                    row['returncode'] = None
                stream.write('\nRunner exception: ' + repr(caught) + '\n')
        text = log.read_text(errors='replace')
        counts = [dict(tests=int(a), ok=int(b), failed=int(c), skipped=int(d))
                  for a, b, c, d in SUMMARY.findall(text)]
        passed = error is None and row['returncode'] == 0
        if expected == 'unit':
            passed = passed and len(counts) == 1 and all(
                s['tests'] > 0 and s['ok'] == s['tests'] and s['failed'] == 0
                and s['skipped'] == 0 for s in counts)
        elif expected == 'single':
            passed = passed and counts == [dict(tests=1, ok=1, failed=0, skipped=0)]
        row.update(finished=time.time(), passed=bool(passed), summaries=counts,
                   log=log.name, log_sha256=sha(log))
        self.records.append(row)
        save(self.archive / 'results.json', self.records)
        print(name, 'PASS' if passed else 'FAIL', counts, flush=True)
        if error is not None:
            raise error
        if not passed:
            raise RuntimeError(f'{name} failed: {log}')

    def build(self, stage):
        mode = stage if stage in ('release', 'debug') else 'debug'
        sanitize = stage == 'sanitizers'
        buildroot = self.scratch / ('build-' + stage)
        buildroot.mkdir(exist_ok=False)
        command = ['make', f'-j{self.args.jobs}', f'CC={self.args.cc}',
                   f'BUILD_ROOT={buildroot}', f'BUILD_MODE={mode}',
                   f'BUILD_MEMORY_FAULT_INJECTION={int(stage == "fault")}',
                   f'BUILD_ASAN={int(sanitize)}', 'BUILD_MSAN=0', 'libs',
                   'unit/btree_test', 'unit/splinterdb_quick_test',
                   'unit/splinter_test', 'unit/btree_stress_test']
        env = dict(self.environment)
        if sanitize:
            env['CFLAGS'] = '-fsanitize=undefined -fno-sanitize-recover=all -fno-omit-frame-pointer'
            env['LDFLAGS'] = '-fsanitize=undefined'
        with tempfile.TemporaryDirectory(prefix=stage + '-build-', dir=self.scratch) as tmp:
            env['TMPDIR'] = tmp
            self.run(stage + '-build', command, self.tree, environment=env,
                     timeout=self.args.build_timeout)
        build = buildroot / (mode + ('-asan' if sanitize else ''))
        save(self.archive / (stage + '-build-files.json'), {
            str(p.relative_to(build)): sha(p) for folder in ('bin', 'lib')
            for p in sorted((build / folder).rglob('*')) if p.is_file()})
        return build

    def test(self, stage, build, suite, case=None):
        name = suite + ('-' + case if case else '')
        cwd = self.scratch / 'tests' / stage / name
        cwd.mkdir(parents=True, exist_ok=False)
        (cwd / 'tmp').mkdir()
        env = dict(self.environment, TMPDIR=str(cwd / 'tmp'))
        if stage == 'sanitizers':
            env.update(ASAN_OPTIONS=f'detect_leaks={int(self.args.leak_detection)}:halt_on_error=1',
                       UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
        command = [build / 'bin/unit' / (suite + '_test')]
        if suite == 'splinter':
            command.extend(CORE_OPTIONS)
        if case:
            command.append(case)
        self.run(stage + '-' + name, command, cwd, environment=env,
                 expected='single' if case else 'unit')

    def stage(self, stage):
        if stage == 'sanitizers':
            source = self.scratch / 'sanitizer-probe.c'
            source.write_text('#include <stdlib.h>\nint main(void) { char *p = malloc(8); '
                              'if (!p) return 1; p[0] = 1; int n = p[0]-1; free(p); return n; }\n')
            binary = self.scratch / 'sanitizer-probe'
            env = dict(self.environment,
                       ASAN_OPTIONS=f'detect_leaks={int(self.args.leak_detection)}:halt_on_error=1',
                       UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
            self.run('sanitizer-capability-build', [self.args.cc,
                     '-fsanitize=address,undefined', '-fno-sanitize-recover=all',
                     source, '-o', binary], self.scratch, environment=env)
            self.run('sanitizer-capability-run', [binary], self.scratch, environment=env)
        build = self.build(stage)
        self.test(stage, build, 'btree')
        if stage in ('debug', 'release'):
            self.test(stage, build, 'splinterdb_quick')
        else:
            source = (self.tree / 'tests/unit/splinterdb_quick_test.c').read_text()
            extra = tuple(case for case in SUPPLEMENTAL_QUICK_TESTS
                          if f'CTEST2(splinterdb_quick, {case})' in source)
            for case in QUICK_TESTS + extra:
                self.test(stage, build, 'splinterdb_quick', case)
        for suite, cases in (('splinter', CORE_TESTS), ('btree_stress', STRESS_TESTS)):
            for case in cases:
                self.test(stage, build, suite, case)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--variant', required=True)
    parser.add_argument('--name', default=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    parser.add_argument('--stages', nargs='+', choices=('release', 'debug', 'fault', 'sanitizers'),
                        default=['release', 'debug', 'fault', 'sanitizers'])
    parser.add_argument('--jobs', type=int, default=6)
    parser.add_argument('--cc', default='gcc', help='GCC avoids the documented Clang ASAN CTest discovery issue')
    parser.add_argument('--build-timeout', type=int, default=3600)
    parser.add_argument('--test-timeout', type=int, default=1200)
    parser.add_argument('--minimum-free-gib', type=int, default=12)
    parser.add_argument('--leak-detection', action='store_true', help='Opt into LSan capability probe; failure is fatal')
    parser.add_argument('--test-patch', action='append', default=[],
                        help='Tests-only patch applied to an isolated source copy; repeatable')
    args = parser.parse_args()
    for value in (args.variant, args.name):
        if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.-]*', value):
            parser.error('variant/name must be simple filesystem labels')
    if min(args.jobs, args.build_timeout, args.test_timeout, args.minimum_free_gib) < 1:
        parser.error('jobs, timeouts and minimum free space must be positive')
    if len(set(args.stages)) != len(args.stages):
        parser.error('duplicate stages are not allowed')
    metadata = HERE / 'build.json'
    record = json.loads(metadata.read_text()).get(args.variant)
    if not record:
        parser.error('variant must have a completed frozen entry in build.json')
    tree = Path(record['tree']).resolve()
    if not (tree / 'Makefile').is_file():
        parser.error('variant source tree missing')
    label = args.variant + '-' + args.name
    archive = HERE / 'validation' / label
    scratch = SCRATCH / 'validation' / label
    archive.mkdir(parents=True, exist_ok=False)
    scratch.mkdir(parents=True, exist_ok=False)
    (archive / 'validate_selected.py').write_bytes(Path(__file__).read_bytes())
    save(archive / 'invocation.json', vars(args))
    save(archive / 'timed-build.json', record)
    patches = []
    for index, source in enumerate(args.test_patch):
        path = archive / f'test-overlay-{index:02d}.patch'
        path.write_bytes(Path(source).read_bytes())
        patches.append(path)
    save(archive / 'test-overlays.json', [dict(original=source,
         frozen=str(path), sha256=sha(path)) for source, path in zip(args.test_patch, patches)])
    save(archive / 'test-plan.json', dict(quick=QUICK_TESTS, core=CORE_TESTS,
         stress=STRESS_TESTS, limitations=COVERAGE_LIMITATIONS,
         supplemental_quick_if_present=SUPPLEMENTAL_QUICK_TESTS,
         full_suites=['btree', 'splinterdb_quick'], full_suite_stages=['release', 'debug']))
    val = Validation(args, archive, scratch, tree)
    result = dict(passed=False, started=time.time(), variant=args.variant,
                  tree=str(tree), scratch=str(scratch), stages={},
                  leak_detection=args.leak_detection, coverage_limitations=COVERAGE_LIMITATIONS)
    before, timed_before, validation_before = None, None, None
    print('Waiting for exclusive machine lock; archive ' + str(archive), flush=True)
    with MACHINE_LOCK.open('rb') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        result['lock_acquired'] = time.time()
        try:
            fs = json.loads(subprocess.check_output(
                ['findmnt', '-T', str(scratch), '-J', '-o', 'SOURCE,FSTYPE,TARGET'],
                text=True))['filesystems'][0]
            save(archive / 'storage.json', dict(filesystem=fs,
                 available_bytes=shutil.disk_usage(scratch).free))
            if not str(fs['source']).startswith('/dev/') or fs['fstype'] in ('tmpfs', 'ramfs'):
                raise RuntimeError('Validation scratch must reside on a real block device')
            val.free_guard()
            before = source_manifest(tree)
            save(archive / 'sources-before.json', before)
            expected = record.get('source_files_sha256', {})
            if not expected:
                raise RuntimeError('Timed source manifest missing')
            mismatch = [p for p, h in expected.items() if before.get(p) != h]
            if mismatch:
                raise RuntimeError('Sources differ from timed build: ' + ', '.join(mismatch))
            result['sources_match_timed_build'] = True
            timed_before = {record[k]: sha(record[k]) for k in ('binary', 'library')}
            save(archive / 'timed-files-before.json', timed_before)
            for kind in ('binary', 'library'):
                if timed_before[record[kind]] != record[kind + '_sha256']:
                    raise RuntimeError(f'Frozen {kind} differs from timed build')
            if patches:
                clone = scratch / 'source'
                shutil.copytree(tree, clone, symlinks=True,
                                ignore=shutil.ignore_patterns('build', '.git', '.cache'))
                if source_manifest(clone) != before:
                    raise RuntimeError('Isolated source copy differs before overlays')
                for index, patch in enumerate(patches):
                    numstat = subprocess.check_output(
                        ['git', 'apply', '--numstat', str(patch)], cwd=ROOT, text=True)
                    paths = [line.split('\t', 2)[2] for line in numstat.splitlines()]
                    if not paths or any(not p.startswith('tests/') or
                                        '..' in Path(p).parts or
                                        not re.fullmatch(r'[a-zA-Z0-9_./-]+', p)
                                        for p in paths):
                        raise RuntimeError('Overlay must modify only ordinary paths within tests/')
                    command = ['git', 'apply', '--unsafe-paths', '--directory=' + str(clone)]
                    val.run(f'test-overlay-{index:02d}-check',
                            command + ['--check', str(patch)], ROOT)
                    val.run(f'test-overlay-{index:02d}-apply', command + [patch], ROOT)
                val.tree = clone
                validation_before = source_manifest(clone)
                changes = [p for p in set(before) | set(validation_before)
                           if before.get(p) != validation_before.get(p)]
                if not changes or any(not p.startswith('tests/') for p in changes):
                    raise RuntimeError('Overlay changed runtime source or made no test change')
                result['test_source_changes'] = sorted(changes)
                result['validation_tree'] = str(clone)
                save(archive / 'validation-sources-before.json', validation_before)
            compiler = shutil.which(args.cc)
            if compiler is None:
                raise RuntimeError('Compiler unavailable: ' + args.cc)
            save(archive / 'compiler.json', dict(path=compiler, sha256=sha(compiler),
                 version=subprocess.check_output([compiler, '--version'], text=True)))
            quick_source = (val.tree / 'tests/unit/splinterdb_quick_test.c').read_text()
            result['supplemental_tests_present'] = [name for name in SUPPLEMENTAL_QUICK_TESTS
                if f'CTEST2(splinterdb_quick, {name})' in quick_source]
            for stage in args.stages:
                result['stages'][stage] = 'running'
                save(archive / 'summary.json', result)
                val.stage(stage)
                result['stages'][stage] = 'passed'
            result['passed'] = True
        except BaseException as error:
            result['error'] = repr(error)
            raise
        finally:
            if before is not None:
                after = source_manifest(tree)
                save(archive / 'sources-after.json', after)
                result['sources_unchanged'] = before == after
                result['passed'] &= result['sources_unchanged']
            if timed_before is not None:
                timed_after = {p: sha(p) for p in timed_before}
                save(archive / 'timed-files-after.json', timed_after)
                result['timed_files_unchanged'] = timed_before == timed_after
                result['passed'] &= result['timed_files_unchanged']
            if validation_before is not None:
                validation_after = source_manifest(val.tree)
                save(archive / 'validation-sources-after.json', validation_after)
                result['validation_sources_unchanged'] = validation_before == validation_after
                result['passed'] &= result['validation_sources_unchanged']
            result.update(finished=time.time(),
                unit_test_executions=sum(s['ok'] for row in val.records for s in row['summaries']))
            save(archive / 'summary.json', result)
            save(archive / 'sha256.json', {p.name: sha(p) for p in sorted(archive.iterdir())
                                         if p.is_file() and p.name != 'sha256.json'})
    if not result['passed']:
        raise RuntimeError('Validation invariants failed: ' + str(archive))
    print(f"Validation complete: {result['unit_test_executions']} passed test executions; {archive}", flush=True)


if __name__ == '__main__':
    def interrupted(signum, frame):
        raise KeyboardInterrupt(f'signal {signum}')
    signal.signal(signal.SIGTERM, interrupted)
    main()
