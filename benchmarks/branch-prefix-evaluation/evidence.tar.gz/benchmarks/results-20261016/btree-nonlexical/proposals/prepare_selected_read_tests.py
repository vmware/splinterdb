#!/usr/bin/env python3
"""Materialize tests-only proposals; never modifies a runtime or variant tree."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
BASE = 'b9cc3ea4ecfd523d799116798285fb2d7fe0bfaa'
TEST = 'tests/unit/splinterdb_quick_test.c'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def message_cases(text):
    old = '      INVALID_KEY_FLAGS,\n      EXCESSIVE_FULL_KEY,\n'
    new = ('      INVALID_KEY_FLAGS,\n      INVALID_MESSAGE_TYPE,\n'
           '      INVALID_MESSAGE_FLAGS,\n      EXCESSIVE_FULL_KEY,\n')
    assert text.count(old) == 1
    text = text.replace(old, new)
    old = ('         case INVALID_KEY_FLAGS:\n'
           '            entry->key_flags = ONDISK_KEY_DEFAULT_FLAGS ^ 0x80;\n'
           '            break;\n')
    new = old + ('         case INVALID_MESSAGE_TYPE:\n'
                 '            entry->flags &= ~ONDISK_MESSAGE_TYPE_MASK;\n'
                 '            break;\n'
                 '         case INVALID_MESSAGE_FLAGS:\n'
                 '            entry->flags |= 0x80;\n'
                 '            break;\n')
    assert text.count(old) == 1
    return text.replace(old, new)


def formatted(base, text):
    ranges = [(j1 + 1, j2) for op, i1, i2, j1, j2 in
              difflib.SequenceMatcher(None, base.splitlines(), text.splitlines(),
                                      autojunk=False).get_opcodes()
              if op != 'equal' and j2 > j1]
    command = ['clang-format-19', '--style=file', '--assume-filename=' + str(ROOT / TEST)]
    command += [f'--lines={start}:{end}' for start, end in ranges]
    result = subprocess.check_output(command, input=text, text=True)
    return result, command, ranges


def proposal(name, base, unformatted, frozen):
    text, command, ranges = formatted(base, unformatted)
    patch = ''.join(difflib.unified_diff(
        base.splitlines(keepends=True), text.splitlines(keepends=True),
        fromfile='a/' + TEST, tofile='b/' + TEST))
    path = HERE / (name + '.patch')
    if path.exists():
        raise RuntimeError('Refusing to replace proposal: ' + str(path))
    path.write_text(patch)
    subprocess.run(['git', 'apply', '--check', str(path)], cwd=ROOT, check=True)
    stat = subprocess.check_output(['git', 'apply', '--numstat', str(path)],
                                   cwd=ROOT, text=True)
    assert len(stat.splitlines()) == 1 and stat.rstrip().endswith('\t' + TEST)
    metadata = dict(base_commit=BASE, changed_files=[TEST],
                    base_test_sha256=sha(base.encode()),
                    result_test_sha256=sha(text.encode()),
                    patch_sha256=sha(patch.encode()),
                    formatter_command=command, formatted_input_ranges=ranges,
                    formatter_version=subprocess.check_output(
                        ['clang-format-19', '--version'], text=True).strip(),
                    frozen_nonlexical_input=frozen,
                    status='unapplied tests-only proposal; no builds or runtime tests',
                    numstat=stat.strip())
    (HERE / (name + '.json')).write_text(json.dumps(metadata, indent=2) + '\n')
    print(json.dumps(dict(name=name, **{k: metadata[k] for k in
          ('patch_sha256', 'result_test_sha256', 'numstat')}), indent=2))


def main():
    base = subprocess.check_output(['git', 'show', BASE + ':' + TEST], cwd=ROOT, text=True)
    original = HERE / 'nonlexical-branch-test.patch'
    original_meta = json.loads((HERE / 'nonlexical-branch-test.json').read_text())
    original_hash = sha(original.read_bytes())
    assert original_hash == original_meta['patch_sha256']
    fragment = (HERE / 'nonlexical-branch-test.c').read_text()
    anchor = 'CTEST2(splinterdb_quick, test_iterator_custom_comparator)\n'
    assert base.count(anchor) == 1
    existing = base.replace(anchor, fragment + '\n' + anchor)
    assert sha(existing.encode()) == original_meta['result_test_sha256']
    frozen = dict(patch=str(original), sha256=original_hash,
                  result_test_sha256=original_meta['result_test_sha256'])
    proposal('message-flags-test', base, message_cases(base), None)
    proposal('selected-read-tests-v1', base, message_cases(existing), frozen)
    assert sha(original.read_bytes()) == original_hash


if __name__ == '__main__':
    main()
