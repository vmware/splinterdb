# Blob outlining added to the combined read candidate

Source-only review passed for `combined-read-blob-v1`, `src/btree.c` SHA-256
`3d6a3f5d7dcc8ee5f3c474487715247d3ac901d2844f5f72cc2d9a1a0df69fad`.
The focused delta from reviewed `combined-read-v1` has SHA-256
`1412468b6d1cfdc8fe462fee7e65209b9940f13f9a9a48a1881930529a6657a9`.
No source interaction blocker was found. No build, test or workload was run by
this reviewer; no frozen source was changed.

The only additional behavior is a call boundary around the existing descriptor
scratch and parser invocation. `btree_read_leaf_message` still checks allowed
flags, nonzero type and the widened key-plus-message extent before testing the
blob flag and calling the helper. Thus the descriptor pointer and length are
formed only after the same page bounds checks as before.

The calling lookup or iterator owns the leaf's read reference throughout the
synchronous helper call. The descriptor slice borrows those page bytes. In
`blob.h:37`, `parsed_blob` contains a borrowed base pointer, scalar dimensions
and an inline array of three leftover ranges. It owns no allocation or page
reference and requires no destructor. `blob_parse_descriptor` at `blob.c:92`
reads configuration and descriptor bytes, validates their geometry/address
ranges, and fills that temporary object. It performs no I/O or resource
acquisition, stores no global pointer to the object, and has no asynchronous
continuation. Only its status escapes `btree_read_leaf_blob`. Early failures
before the parser initializes scratch are therefore safe as well.

The caller propagates helper errors at the same point as the old direct parser
call. Point lookups still reject a bad message before exposing its value;
iterator positioning still rejects it before decode and clears its exposed
entry on error. Callback-search selection, compressed-prefix handling and
decoded-key ownership are unaffected. The helper moves stack scratch; it does
not remove a heap allocation or change descriptor ownership.

Existing `test_blob_checksums` exercises descriptor format, truncation, length
and address rejection through the parser and blob consumers. The complete
quick suite includes `test_value_size_gt_max_value_size`, whose large-value
close/reopen lookup exercises the healthy packed B-tree blob read path. The
descriptor-sizing test checks encoder sizing boundaries, so it should not be
described as direct coverage of the outlined B-tree call itself. There is no
new descriptor algorithm that requires a separate test fixture here.

At the parent's request, the existing large-value quick test was also added to
the validation runner's focused fault/ASAN+UBSAN selection. This makes that
real B-tree path run under those modes rather than relying only on the direct
parser tests. The sole runner change is one `QUICK_TESTS` entry. Its prior
version is preserved as `validate_selected-before-blob-coverage.py`, with the
revision diff and hashes in `validate-selected-blob-coverage.{patch,json}`.
Current runner SHA-256:
`0acf4b32497bbedb06b3f36cb7999f49c82b23510527b076d77ded913fe1b2e3`.
The existing `selected-read-tests-v1.patch` remains unchanged and suitable for
this runtime candidate. No further new test is proposed before the prepared
validation runs.
