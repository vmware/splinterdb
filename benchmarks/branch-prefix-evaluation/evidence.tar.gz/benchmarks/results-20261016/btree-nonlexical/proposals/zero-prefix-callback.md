# Known-zero-prefix callback contingency

Status: source-only proposal, not built, tested, benchmarked, or selected.
The frozen selected parent `combined-read-blob-v1` and live runtime are unchanged.
The earlier `zero-prefix-search-design.md` records the initial unimplemented
idea; this artifact materializes that idea separately for possible later use.

The full isolated tree is
`.cache/btree-nonlexical-20261016/variants/zero-prefix-callback`.
Its `src/btree.c` SHA-256 is
`2f3d8737bc011e1762994878ed6e869602924ec900f1999e24166dd9cdf1f9d4`.
`zero-prefix-callback-from-selected.patch` is the focused delta against parent
`3d6a3f5d7dcc8ee5f3c474487715247d3ac901d2844f5f72cc2d9a1a0df69fad`;
`zero-prefix-callback.patch` includes the parent's changes against `b9cc3ea4`.
The adjacent JSON records parent, archive, patch, preparation script, and source
hashes and the formatter commands. Changed ranges were formatted with
clang-format-19 and verified idempotent; both patches passed reverse-apply
checks against the new tree. Those checks establish patch applicability, not
C compilation or runtime correctness.

The two small private inline validators now accept `uint16 prefix_length`, the
stored header field's existing type. Ordinary wrappers pass the actual header
value. Only `btree_find_tuple_callback_checked` passes zero. Its unchanged
caller computes `compressed = hdr->prefix_length != 0` and includes
`compressed` in the condition that selects lexical semantics. Thus callback
dispatch implies a zero stored prefix, independent of the configuration flag.
A compressed branch reopened with lexical construction disabled retains the
compressed lexical path. Infinite targets in an uncompressed lexical branch
retain callback comparison semantics.

The checked-search callers operate on immutable branch pages with a held page
reference; mutable memtable searches retain their existing unchecked path.
This already-established lifetime makes the prefix stable during comparator
calls. No validation relies on a new configuration-based assumption.

All existing validation bodies remain shared: index bounds, offset-table and
entry-header bounds, key flags, forbidden infinity encodings, key byte extent,
and the full-key limit for the configured page size. The explicit prefix's
`uint16` type preserves the widened key-plus-prefix arithmetic bound. Entry
outputs are assigned only after successful checks. Branch-header validation,
post-hit message flags and extents, and blob descriptor validation are unchanged.
This does not move message checks into or out of the search loop.

The hypothesis is that constant propagation removes repeated prefix loads and
associated subtraction/addition in the callback loop. No code-generation or
throughput improvement is claimed: register allocation, code size, and inlining
could offset the saving or change other paths. Build, disassembly inspection,
focused immutable custom-comparator/corruption validation, and controlled point
comparisons remain necessary before any adoption. The selected parent's
release validation does not validate this new source tree.
