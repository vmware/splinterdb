# Pack and checked-search source review

Base: `b9cc3ea4ecfd523d799116798285fb2d7fe0bfaa`; base `src/btree.c`
SHA-256 `6ceb7b6ea8d9c72c4112433f8dde617a3818de832b3e6e411d5914e3fd419aab`.
This is source review and a validation plan, not a performance or correctness
test result. The three source variants and patch hashes are recorded in
`pack-point-manifest.json`; they were frozen before the parent built them.

## Individual proposals

`lazy-pivot-buffer.patch` avoids `DECLARE_AUTO_KEY_BUFFER` when linking an
internal page or an uncompressed leaf. The existing buffer initialization at
base `btree.c:5363` executes even when the pivot can borrow the page's key.
Initialization is per linked page, not per tuple, and does not imply a heap
allocation. The wrapper-owned buffer remains live throughout the helper call,
including recursive parent creation; cleanup occurs after the return
expression is evaluated. Borrowed pivots retain the edge read reference until
they have been copied into the parent. Height checks, unlock/unclaim, error
unget, accumulated statistics and successful unget retain their ordering.
No lifetime or error-cleanup defect was found by source review.

`prefix-before-scratch.patch` moves the full rewrite into a noinline helper
after prefix qualification. A pack owns the construction leaf while both
functions execute, so rereading its first key is safe. The threshold, first/
last prefix computation, entry copying and final page replacement are
unchanged. The existing nonlexical guard already precedes the large stack
frame in the measured baseline assembly; this proposal chiefly targets
lexical pages whose common prefix is below four bytes. The scratch declaration
reserves `MAX_PAGE_SIZE` stack space but the final copy is only the configured
page size. It does not avoid a 64 KiB allocation/copy on every nonlexical leaf.
The extra successful-compression call may offset any rejected-leaf saving.

`callback-search.patch` dispatches once per checked leaf search instead of
selecting callback versus direct lexical comparison inside every binary-search
iteration. The baseline frozen B-tree executable has that mode test inside
the loop (`btree_find_tuple_checked.lto_priv.0`, offsets `0xf5cd`–`0xf5d3`,
callback path `0xf630`); this identifies removable instructions, not their
measured share of total query cost. Both loops still call
`btree_read_leaf_key` before comparisons. Equality/miss indices, optional entry
outputs and failure handling are unchanged. The caller still initializes
`found=false`, processes a compressed prefix, and dispatches compressed pages
to lexical suffix comparison. Infinite keys retain `btree_key_compare`
semantics. The helper does not assume that the nonlexical callback orders raw
bytes lexically. Additional code size or a helper call could erase the saving;
generated code and measurement must decide. Independent source review by the
scan agent found no contract change.

For the scan agent's separate `read-design/decode-outline.patch`, the helper is
called only after a checked leaf read and a nonzero prefix. It reloads the state
after `prepare_decode`, dereferences/copies only after success, and leaves the
caller to clear `validated_entry` and record failure exactly as before.
High-water length, prefix replacement, zero-length suffixes and mixed-leaf
transitions are unchanged. No allocation-failure/lifetime issue was found.

## Existing tests and what they establish

The prepared `../validate_selected.py` builds only into separate validation
roots under the exclusive machine lock. It records exact commands, source and
binary hashes, logs, exit codes and CTest counts. Release/debug run full
`btree_test` and `splinterdb_quick_test`; focused core and iterator tests run in
each stage. Fault mode enables allocation hooks. The sanitizer stage enables
ASAN and UBSAN, requires its capability probe to pass, and defaults LSan off
because earlier archived sandbox probes failed process inspection. No test or
workload was launched while preparing this review or runner.

Example coordinator commands (replace `SELECTED` with the frozen build name):

```sh
python3 benchmarks/results-20261016/btree-nonlexical/validate_selected.py --variant SELECTED --name release-debug-01 --stages release debug
python3 benchmarks/results-20261016/btree-nonlexical/validate_selected.py --variant SELECTED --name fault-sanitizers-01 --stages fault sanitizers
```

The standalone test filter is the final argument and uses prefix matching.
For individual follow-ups, use the absolute selected validation binary and a
fresh owned real-disk working directory; retain the shared machine lock:

```sh
/ABS/BUILD/debug/bin/unit/splinterdb_quick_test test_branch_prefix
/ABS/BUILD/debug/bin/unit/btree_test
/ABS/BUILD/debug/bin/unit/btree_stress_test iterator_endpoint_error_is_returned_by_init
/ABS/BUILD/debug/bin/unit/splinter_test --db-location core.db --cache-capacity-mib 128 --db-capacity-gib 64 test_blob_checksums
/ABS/BUILD/debug/bin/unit/splinter_test --db-location core.db --cache-capacity-mib 128 --db-capacity-gib 64 test_btree_pack
```

Relevant source anchors in the base:

| Existing check | Coverage |
| --- | --- |
| `splinterdb_quick_test.c:1380`, `test_branch_prefix_minimum` | Per-leaf prefixes of 1, 3, 4 and 7 bytes; cutoff and full values. |
| `splinterdb_quick_test.c:1544`, `test_branch_prefix_variable_iterator` | 8–512-byte keys, decode growth/shrink, leaf transitions, aliased and strict/non-strict seeks, both directions; fault build exercises decode growth failure. |
| `splinterdb_quick_test.c:1775`, `test_branch_prefix_malformed_leaf_entries` | Invalid flags/infinity lengths, full key bound, short entry header, suffix crossing prefix, message extent and length-sum overflow. Positioning rejects before exposing a current entry. |
| `splinterdb_quick_test.c:1824`, `test_branch_prefix_roundtrip` | Packed/reopened compressed and plain leaves, flipped compression policy, point sync/async, forward/backward, bounds, filtered scans and zero suffix. |
| `splinterdb_quick_test.c:830`, `test_range_init_error_cleanup_preserves_branches` | Initialization failures preserve branch ownership. |
| `btree_test.c:229`–`:359`, invalid branch tests | Synchronous/asynchronous point, iterator and metadata rejection of bad root addresses/format versions. |
| `btree_stress_test.c:1432`, `:1540` | Endpoint read errors surface from synchronous/asynchronous iterator initialization; count-in-range propagates lookup failure. |
| `btree_stress_test.c:1622`, `:1860`, `:1954` | Copied mutable iterator bounds, splitting on release and prefetch controls. |
| `splinter_test.c:1041`, `test_blob_checksums` | Descriptor validation/materialization/clone, malformed format/truncation/length/address and checksum rejection. |
| `splinter_test.c:1343`, `:1388` | Pack abort and counter overflow return extents and leave no published root. |
| `splinter_test.c:1430`, `:1567`, `:1718`, `:1839`, `:5999` | Malformed trunk bundles/references/statistics/child heights and propagated cache read errors. |

Two gaps remain explicit. `test_iterator_custom_comparator` at quick-test line
3272 inserts only 50 keys without forcing checkpoint/pack, so it principally
checks a mutable scan. In `test_branch_prefix_roundtrip`, disabled construction
provides callback-path seek coverage, but reopening flips the flag and its
uncompressed point lookups then use the lexical path. The existing benchmark
nonlexical oracle therefore adds useful packed callback hit/miss/scan coverage;
these unit tests alone do not establish genuinely nonlexical immutable point
semantics or corruption rejection before a user callback. If callback-search
is retained, a focused packed nonlexical point/seek regression is justified.

Second, the existing pack-abort test fails its input iterator after one tuple.
It verifies reservation cleanup but does not inject allocation failure while
forming a compressed pivot during recursive parent creation. The decode fault
test does not close this different coverage gap. No unrun allocation-fault
coverage is claimed for lazy-pivot.

At the parent's subsequent request, `nonlexical-branch-test.patch` prepares a
functional regression for the first gap. It checkpoints/reopens 1,024 shuffled
keys with intentionally different comparator and byte order, checks every key
in an immutable branch through direct synchronous/asynchronous hit and miss
lookups, scans both directions, and tests absent-key starts. It also corrupts
one searched key extent and requires both point APIs to reject it before the
comparator can consume the invalid key; the page is restored before assertions
and teardown. The patch is unapplied and unrun here. Its fragment, patch hash
and resulting test-source hash are archived alongside it.

The validation runner accepts this patch through a separate source copy;
runtime source equality to the timed build remains mandatory:

```sh
python3 benchmarks/results-20261016/btree-nonlexical/validate_selected.py --variant SELECTED --name with-nonlexical-test-01 --test-patch benchmarks/results-20261016/btree-nonlexical/proposals/nonlexical-branch-test.patch
```

It verifies that overlays change only `tests/`, freezes the patch used, runs
the added test in every requested stage (as part of the full suite or as a
focused case), and checks both original and copied source trees afterward.
