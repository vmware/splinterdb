#!/usr/bin/env python3
"""Prepare a source-only callback-search contingency; never builds or runs it."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
ARCHIVE = HERE.parent
VARIANT = 'zero-prefix-callback'
PARENT = 'combined-read-blob-v1'
FILE = 'src/btree.c'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)


def modified(text):
    text = once(text, '''static inline platform_status
btree_read_entry_bounds(const btree_config *cfg,
                        const btree_hdr    *hdr,
                        table_index         idx,
                        uint64              min_size,
                        uint64             *offset_out,
                        uint64             *remaining_out)
''', '''/* prefix_length must equal the stored prefix. Keeping it explicit lets a
 * caller that has already proved it is zero reuse all the same checks. */
static inline platform_status
btree_read_entry_bounds_with_prefix(const btree_config *cfg,
                                    const btree_hdr    *hdr,
                                    uint16              prefix_length,
                                    table_index         idx,
                                    uint64              min_size,
                                    uint64             *offset_out,
                                    uint64             *remaining_out)
''')
    text = once(text,
                '   uint64 page_size = btree_page_size(cfg) - hdr->prefix_length;\n',
                '   uint64 page_size = btree_page_size(cfg) - prefix_length;\n')
    text = once(text, '''static inline platform_status
btree_read_index_key''', '''static inline platform_status
btree_read_entry_bounds(const btree_config *cfg,
                        const btree_hdr    *hdr,
                        table_index         idx,
                        uint64              min_size,
                        uint64             *offset_out,
                        uint64             *remaining_out)
{
   return btree_read_entry_bounds_with_prefix(cfg,
                                              hdr,
                                              hdr->prefix_length,
                                              idx,
                                              min_size,
                                              offset_out,
                                              remaining_out);
}

static inline platform_status
btree_read_index_key''')
    start = text.index('static inline platform_status\nbtree_read_leaf_key(')
    end = text.index('/* Every nonzero value representable', start)
    key_reader = text[start:end]
    new_reader = once(key_reader, '''btree_read_leaf_key(const btree_config *cfg,
                    const btree_hdr    *hdr,
                    table_index         idx,
                    const leaf_entry  **entry_out)''', '''btree_read_leaf_key_with_prefix(const btree_config *cfg,
                                const btree_hdr    *hdr,
                                uint16              prefix_length,
                                table_index         idx,
                                const leaf_entry  **entry_out)''')
    new_reader = once(new_reader, '''   platform_status rc = btree_read_entry_bounds(
      cfg, hdr, idx, sizeof(leaf_entry), &offset, &remaining);''', '''   platform_status rc = btree_read_entry_bounds_with_prefix(
      cfg, hdr, prefix_length, idx, sizeof(leaf_entry), &offset, &remaining);''')
    new_reader = once(new_reader,
                      '(uint64)entry->key_length + hdr->prefix_length',
                      '(uint64)entry->key_length + prefix_length')
    new_reader += '''static inline platform_status
btree_read_leaf_key(const btree_config *cfg,
                    const btree_hdr    *hdr,
                    table_index         idx,
                    const leaf_entry  **entry_out)
{
   return btree_read_leaf_key_with_prefix(
      cfg, hdr, hdr->prefix_length, idx, entry_out);
}

'''
    text = text[:start] + new_reader + text[end:]
    text = once(text, '''/* The caller initializes *found and selects callback semantics once for the
 * leaf. Keep all checked-key reads before invoking the user's comparator. */''', '''/* The caller initializes *found and selects callback semantics once for the
 * leaf. This dispatch implies that the immutable leaf's stored prefix is zero,
 * including infinite targets in an uncompressed lexical tree. Keep all checked
 * key reads before invoking the user's comparator. */''')
    start = text.index('btree_find_tuple_callback_checked(')
    end = text.index('static platform_status\nbtree_find_tuple_checked(', start)
    callback = text[start:end]
    callback = once(callback,
                     '      platform_status   rc = btree_read_leaf_key(cfg, hdr, mid, &entry);',
                     '      platform_status rc =\n         btree_read_leaf_key_with_prefix(cfg, hdr, 0, mid, &entry);')
    text = text[:start] + callback + text[end:]
    return text


def formatted(before, text, source):
    ranges = [(j1 + 1, j2) for op, i1, i2, j1, j2 in
              difflib.SequenceMatcher(None, before.splitlines(), text.splitlines(),
                                      autojunk=False).get_opcodes()
              if op != 'equal' and j2 > j1]
    command = ['clang-format-19', '--style=file', '--assume-filename=' + str(source)]
    command.extend(f'--lines={start}:{end}' for start, end in ranges)
    result = subprocess.check_output(command, input=text, text=True)
    return result, command, ranges


def patch(before, after):
    return ''.join(difflib.unified_diff(
        before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile='a/' + FILE, tofile='b/' + FILE))


def main():
    metadata_path = ARCHIVE / 'read-design' / (PARENT + '.json')
    metadata_bytes = metadata_path.read_bytes()
    parent = json.loads(metadata_bytes)
    parent_source = Path(parent['tree']) / FILE
    parent_bytes = parent_source.read_bytes()
    assert sha(parent_bytes) == parent['btree_sha256']
    source_archive = Path(parent['source_archive'])
    assert sha(source_archive.read_bytes()) == parent['source_archive_sha256']
    tree = ROOT / '.cache/btree-nonlexical-20261016/variants' / VARIANT
    assert not tree.exists(), tree
    output = HERE / (VARIANT + '.json')
    assert not output.exists(), output
    tree.mkdir()
    with tarfile.open(source_archive) as tar:
        tar.extractall(tree, filter='data')
    source = tree / FILE
    base_bytes = source.read_bytes()
    assert sha(base_bytes) == parent['base_btree_sha256']
    before = parent_bytes.decode()
    result, format_command, ranges = formatted(before, modified(before), source)
    repeated, _, _ = formatted(before, result, source)
    assert result == repeated, 'Formatting changed ranges is not idempotent'
    source.write_text(result)
    incremental_path = HERE / (VARIANT + '-from-selected.patch')
    full_path = HERE / (VARIANT + '.patch')
    for path, content in ((incremental_path, patch(before, result)),
                          (full_path, patch(base_bytes.decode(), result))):
        with path.open('x') as output_file:
            output_file.write(content)
    # Reverse application confirms that each patch reconstructs its exact input;
    # no parent, live source, or other frozen variant is ever written.
    for path in (incremental_path, full_path):
        subprocess.run(['git', 'apply', '--reverse', '--check', str(path)],
                       cwd=tree, check=True)
    assert parent_source.read_bytes() == parent_bytes
    inventory = dict(parent['source_files_sha256'])
    inventory[FILE] = sha(source.read_bytes())
    result_metadata = dict(
        variant=VARIANT, tree=str(tree), base_commit=parent['base_commit'],
        base_btree_sha256=parent['base_btree_sha256'], parent_variant=PARENT,
        parent_metadata=str(metadata_path), parent_metadata_sha256=sha(metadata_bytes),
        parent_btree_sha256=sha(parent_bytes), btree_sha256=inventory[FILE],
        parent_source_unchanged=True, source_archive=str(source_archive),
        source_archive_sha256=parent['source_archive_sha256'],
        patch=str(full_path), patch_sha256=sha(full_path.read_bytes()),
        incremental_patch=str(incremental_path),
        incremental_patch_sha256=sha(incremental_path.read_bytes()),
        source_files_sha256=inventory,
        inventory_scope='Derived from verified immutable base archive plus sole changed src/btree.c; coordinator should verify source inventory before building.',
        changes=[FILE], format_command=format_command,
        formatted_input_ranges=ranges, formatting_idempotent=True,
        formatter_version=subprocess.check_output(
            ['clang-format-19', '--version'], text=True).strip(),
        preparation_script=str(Path(__file__).resolve()),
        preparation_script_sha256=sha(Path(__file__).read_bytes()),
        status='source-only contingency; unbuilt, untested, unselected',
        created=time.time())
    with output.open('x') as stream:
        json.dump(result_metadata, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: result_metadata[key] for key in
                     ('variant', 'btree_sha256', 'patch_sha256',
                      'incremental_patch_sha256', 'status')}, indent=2))


if __name__ == '__main__':
    main()
