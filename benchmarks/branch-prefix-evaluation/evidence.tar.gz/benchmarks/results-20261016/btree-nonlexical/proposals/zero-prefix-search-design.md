# Contingency: constant-zero prefix in checked callback searches

Status: **unimplemented and unmeasured**. No patch, build or workload was
produced. Revisit only if the final direct-main comparison still identifies a
material point-query regression. The current screening candidate is unchanged.

Source anchors below refer to frozen `combined-read-blob-v1/src/btree.c`, SHA-256
`3d6a3f5d7dcc8ee5f3c474487715247d3ac901d2844f5f72cc2d9a1a0df69fad`.

At `btree_find_tuple_checked` (line 1548), the wrapper computes
`compressed = hdr->prefix_length != 0` and then
`lexical = compressed || (configured lexical comparison && finite target)`.
It calls `btree_find_tuple_callback_checked` (line 1509) only when `!lexical`.
Therefore this call implies `!compressed` and exactly zero stored prefix.
This includes infinite targets in an uncompressed lexical tree. It does not
follow merely from the configuration's lexical flag: previously compressed
pages can be read with that construction flag disabled and must retain their
stored prefix semantics.

The page remains pinned and is an immutable branch leaf throughout the search.
The comparator cannot legitimately change that stored prefix during a call.
This does not add a new stable-page assumption: the existing search already
snapshots its entry-count bound and compression decision before its loop.
Malformed pages with a nonzero prefix take the existing compressed path;
specializing the zero path would not reinterpret their payload as plain keys.

The possible code scope is limited to two private inline validation helpers
and the callback-loop call. `btree_read_entry_bounds` (line 1297) currently
subtracts the header prefix from the configured page size, and
`btree_read_leaf_key` (line 1357) adds it to the stored key length for the full
key-size check. Factoring their validation bodies to accept an explicit prefix
length would allow this caller to supply constant zero; ordinary wrappers
would continue passing the actual header value. Keep one validation body
rather than duplicating a more permissive plain-page validator.

All existing checks must remain: index within the offset table, offset not
below `next_entry`, complete entry header within the payload, expected key
flags, forbidden infinity encodings, key bytes within the remaining entry
extent, and full key length within the configured page's maximum. The latter
is `MAX_INLINE_KEY_SIZE(page_size)` (`btree.h:71`), not the maximum possible
page size. `btree_read_branch_header` (line 1242) remains unchanged. Preserve
entry-output assignment only after validation and preserve error results.
Post-hit message/flag/blob validation at `btree_read_leaf_message` (line 1403)
must also remain; it is outside the repeated comparison loop and need not be
specialized for this proposal.

The potential saving is a repeated prefix load and the subtraction/addition
derived from it, plus possible register-pressure effects. The compiler may
already share the load within one iteration, while the opaque comparator can
prevent keeping page-derived values across iterations. Only inspection of the
final generated loop can establish which instructions actually disappear.
This is a small per-probe hypothesis, not evidence of a 2–3% throughput gain;
wrapper inlining, code size or register allocation could cancel the benefit.
It should be screened as its own isolated change if needed, without also
hoisting unrelated validation or changing message checks.
