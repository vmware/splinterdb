# Combined read changes: independent source review

Reviewed final `combined-read-v1` against `b9cc3ea4`:

- `src/btree.c` SHA-256: `85a55ca9c873303c4fc851a23adb234c77c8ac2fd3960ea489682e0f6f5a3d93`.
- Combined runtime patch SHA-256: `94bff042846faf69b5a10cb20a219ac4e3b49d501d4d45cb200c7dca2983a48d`.
- Composition: callback-only checked search, outlined compressed-key decoding,
  and removal of the redundant message-class upper-bound check. The earlier
  two-change intermediate is superseded and was not the reviewed final source.

No source interaction blocker was found. This review did not build or run the
candidate. The two small source/patch hashes above were checked against its
metadata; the full source inventory was not rehashed during measurement.

The checked callback loop at final `btree.c:1501` preserves every key read and
validation before invoking the user comparator. The original caller at line
1540 still initializes `found=false`, processes compressed prefixes, and
selects callback handling only for uncompressed nonlexical or infinite target
keys. Compressed suffixes cannot enter that callback loop. Equality, miss
position, optional entry outputs and error returns are unchanged.

Neither search path bypasses message validation. Successful asynchronous and
synchronous branch hits still call `btree_read_leaf_message` at lines 3146 and
3202 before returning a message. A search miss continues to validate probed
keys without validating unrelated messages, as in the base. The message type
is masked first; the new static assertions establish that its possible values
are zero through the maximum valid user type. Removing the impossible upper
bound therefore accepts no new flag byte. Invalid zero, unknown flag bits,
message bounds and blob descriptor validation retain their checks and order.

Iterator positioning at line 3841 still validates the complete current entry
before invoking decode at line 3859. The outlined helper at line 3816 reloads
the prefix state after allocation/growth, dereferences it only on success,
and retains the high-water length and prefix-page update rules. A validation
or decode failure still clears the exposed entry and records the sticky
iterator error. Plain leaves retain the existing borrowed-key path. The
decoder chooses by the stored page prefix, independently of the search mode
or current compression-creation policy, preserving reopened compressed pages.

No iterator layout, allocation ownership, mutable insertion, packing or
on-disk format change is part of this combination. That source observation is
not a performance claim: code layout can still affect the measured binary.

## Focused validation

The existing prefix minimum, mixed/variable-length iterator, roundtrip and
fault-injection checks cover prefix replacement, growing/shrinking keys,
aliased/strict seeks, both directions, zero suffixes, allocation failure, and
reopening with the compression policy changed. The prepared immutable
nonlexical regression adds direct packed sync/async hits and misses, complete
key visitation, scans, absent-key starts and corrupt-key rejection before the
custom comparator. Its matching suffix-only hash preserves comparator/hash
equivalence. Keeping the branch iterator alive pins the deliberately corrupted
leaf, and the key length is restored before assertions and normal teardown.

One actual gap in the base malformed-leaf table was invalid message flags.
`message-flags-test.patch` adds just two cases: clear the type bits to zero;
or preserve the valid type and set reserved bit `0x80`. They reuse the existing
full-page save/restore, invalid-state, no-current and cleared-entry assertions.
These are observable corruption outcomes, not copies of the implementation's
predicate. The scan agent independently reviewed both additions.

`selected-read-tests-v1.patch` combines those eight added lines with the
unchanged, previously reviewed immutable-nonlexical test. Both proposals were
formatted only in their changed ranges with `clang-format-19`, and both apply
cleanly to the base test file. The original nonlexical test patch and its
provenance remain unchanged.

The prepared validation runner can consume the combined tests-only overlay:

```sh
python3 benchmarks/results-20261016/btree-nonlexical/validate_selected.py --variant combined-read-v1 --name selected-01 --test-patch benchmarks/results-20261016/btree-nonlexical/proposals/selected-read-tests-v1.patch
```

It requires the selected frozen build metadata, creates a separate test-source
copy and separate build roots, verifies runtime source equality before and
after the overlay, and keeps the original source and timed binary/library
hashes unchanged. The full quick suite picks up the new test in release/debug;
the focused fault and sanitizer selections detect its presence in the copied
source and run it explicitly. The two added flag cases retain the existing
test name and are therefore included in every selected stage. Stage-specific
invocations remain available. ASAN+UBSAN are enabled in the sanitizer stage;
LeakSanitizer remains explicitly disabled by default.

This combination does not justify another new test fixture or a mirrored
256-flag predicate test. Run the prepared suites and overlays first. The
previously noted recursive compressed-pivot pack-allocation-failure gap belongs
to the separate lazy-pivot proposal, which is absent from this candidate.
