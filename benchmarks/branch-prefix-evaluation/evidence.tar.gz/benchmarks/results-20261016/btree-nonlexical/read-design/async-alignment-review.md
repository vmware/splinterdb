# Independent source review: opaque async I/O buffer alignment

Result: the proposed two-file repair is appropriate and has no source-level
correctness blocker. This review did not compile, reproduce, test or benchmark
the repair. The reproduction and serialized validation belong to the separate
alignment investigation.

Reviewed [delta](../alignment-diagnosis/async-io-alignment-from-selected.patch)
SHA256: `0902a4601b2200f73ebfe92337c0d4ced059ee82fae4a7ae26b32cbcc3ed05f4`.
The source variant is `selected-io-alignment`. Recorded resulting source hashes
are `aed5d9cefd9add9bd87c8a866c6e6f26992a1be327097d6d92b087ec5f1c841b`
for `platform_io.h` and
`53dc4334861d8f228c1d1a06cc3096c1a8f9ccce712b0bfcdbeb7921d2d73290`
for `laio.c`; B-tree source remains the selected `3d6a3f5d...` version.

## Cause and repair contract

The existing `io_async_state_buffer` typedef is a 1024-byte `uint8` array with
only byte alignment. `clockcache_get_async_state` embeds it after a
`platform_status` field. The async I/O API casts that buffer to a native
`laio_async_state`, whose pointers, uint64 fields and kernel request structure
require stronger alignment. A caller declaring the documented typedef can
therefore receive an invalid native-state address without any API misuse.
Aligning only the containing payload does not align a byte-array member at an
arbitrary internal offset. This is a production storage-contract defect.

Giving the array typedef `aligned(_Alignof(max_align_t))` repairs that contract
for standalone, embedded and array instances. The type remains a byte array,
its capacity stays 1024 bytes, and function parameters continue decaying to byte
pointers. Backend initialization, descriptor capacity, callbacks and ownership
do not change. The new `laio_async_state` alignment assertion complements its
existing size assertion. A backend requiring more than the declared buffer
alignment will fail compilation instead of silently accepting invalid storage.

`max_align_t` is already declared by `stddef.h`, included through the header's
existing direct include of `platform_util.h`. GNU type-alignment attributes fit
this Linux GCC/Clang codebase, which already uses GNU extensions and C11 static
assertions. No formatter or dependency installation is needed. Existing cache
assertions check that the generated async state still fits and is aligned for
`page_get_async_state_payload`, whose union already includes pointer, uint64 and
long-double members. Typed heap allocations use cache-line alignment, sufficient
for this target's fundamental alignment requirements.

## ABI, dependencies and performance scope

This changes the alignment of a private type. Structures embedding it can gain
padding, a larger alignment or a changed array stride. In particular,
`async_io_state` contains the buffer after a pointer, and the generated cache
async-read state contains it after status fields. All dependent objects must be
rebuilt together; mixing old/new object layouts would be invalid. The Makefile
uses generated `-MMD -MP` dependency files, and fresh build roots are the clearest
way to demonstrate consistent headers. The opaque public cache payload size,
installed public API headers, B-tree iterator layout and persisted formats are
not changed by the patch. This is an internal layout repair, not a claim of
binary compatibility for external code directly including private headers.

There is no new runtime alignment check or allocation in the patch. Its direct
behavioral changes affect native async I/O storage and associated private
structure layout. The resident B-tree benchmark uses synchronous lookups,
initializes scans with prefetch disabled, and requires zero async I/O calls
inside the timed intervals. Its measured algorithms therefore do not gain new
work from this repair; async-state reserve allocation occurs during setup.
Nevertheless, rebuilding with changed header alignment can alter code layout,
and source inspection does not establish identical generated instructions or
identical timings.

The completed 378-sample campaign must remain attributed to the exact original
selected binary. If adopting this repair, preserve it as a separate logical
change and record the fresh validation and any final performance verification
against the repaired binary. The source review supports adoption once those
checks pass; there is no reason to retain known misaligned production I/O
storage merely to keep an old benchmark hash. A fresh focused performance check
is more proportionate than automatically discarding or silently relabeling the
completed campaign.
