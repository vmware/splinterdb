# Proposed combined read/blob variant v1

This is a separate source-only proposed variant, not a selected candidate. It is
unbuilt and untested at preparation. The original `combined-read-v1` and every
independent variant remain unchanged. Base commit:
`b9cc3ea4ecfd523d799116798285fb2d7fe0bfaa`.

Source tree:
`.cache/btree-nonlexical-20261016/variants/combined-read-blob-v1`.
B-tree source SHA256:
`3d6a3f5d7dcc8ee5f3c474487715247d3ac901d2844f5f72cc2d9a1a0df69fad`.
[Full patch](combined-read-blob-v1.patch) SHA256:
`a1395974b0b18fb347c074bd6316aa4b8de56f1c5a6487d0bda428a959006898`.
[Delta from the frozen parent](combined-read-blob-v1-from-combined.patch) SHA256:
`1412468b6d1cfdc8fe462fee7e65209b9940f13f9a9a48a1881930529a6657a9`.
The [manifest](combined-read-blob-v1.json) records exact base, parent source,
input patches, format command/ranges and the derived source inventory. No full
tree or runtime binary was hashed during active measurements. The later build
must verify the inventory.

The variant contains frozen `combined-read-v1` (decode-outline, message-type,
callback-search) plus the already reviewed rare-blob change. The focused delta
only gives the `parsed_blob` scratch local, descriptor slice and
`blob_parse_descriptor()` call their own non-inlined helper. The descriptor is
still parsed only after entry/key/message bounds and flag checks have succeeded.
The local parse result has no owned resource and is not used after the call.
The same parser status returns to the same message validator and caller.

On an invalid descriptor, the iterator still clears its validated entry and
sets validation status before returning an error. On a valid compressed tuple,
message validation still precedes decode; the existing highwater decode helper
has exactly the same allocation, prefix and suffix behavior. Callback key
search is unchanged by the added helper. No new iterator lifecycle, page format,
public API, ownership, or allocation rule is introduced.

The interaction hypothesis is narrower than the independent rare-blob probe.
Decode-outline alone enabled inlining of validation into ordinary `next`, but
that function retained an `0x50` stack frame for blob scratch. Rare-blob alone
removed scratch from its validator without enabling inlining. Together, the
compiler may retain inlined validation while moving that scratch frame to the
rare blob path. This must be verified in the combined binary; source composition
does not prove an inlining decision or speedup. Blob values acquire an extra
helper call, and compressed keys retain the decode helper call, so both remain
explicit tradeoffs for validation and measurement.

Changed ranges were formatted with clang-format-19.1.7 and a second pass was
identical. The frozen parent and rare-blob source hashes were checked unchanged.
Independent final source review passed for the exact source hash above. The
review confirmed that the descriptor remains in the caller's pinned leaf,
`parsed_blob` adds no allocation or reference ownership, and only parser status
escapes the helper. Existing extent/type/flag validation and point/iterator error
ordering remain intact. This is source review only; no workload was launched.
