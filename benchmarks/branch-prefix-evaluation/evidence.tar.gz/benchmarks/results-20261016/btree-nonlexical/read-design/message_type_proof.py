#!/usr/bin/env python3
"""Exhaustively compare the two leaf-message flag predicates; no C workload."""
import argparse
import hashlib
import json
from pathlib import Path
import re


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("tree", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    public = args.tree / "include/splinterdb/data.h"
    internal = args.tree / "src/data_internal.h"
    body = re.search(r"typedef enum message_type\s*\{(.*?)\}\s*message_type;",
                     public.read_text(), re.S).group(1)
    types, previous = {}, -1
    for item in body.split(","):
        pieces = item.strip().split("=", 1)
        if not pieces[0]:
            continue
        name = pieces[0].strip()
        if len(pieces) == 1:
            value = previous + 1
        else:
            expression = pieces[1].strip()
            value = types[expression] if expression in types else int(expression, 0)
        types[name] = previous = value
    definitions = internal.read_text()
    assert re.search(r"typedef\s+uint8\s+ondisk_flags;", definitions)
    bits = int(re.search(r"#define ONDISK_MESSAGE_TYPE_BITS\s+\((\d+)\)",
                         definitions).group(1))
    assert "#define ONDISK_MESSAGE_TYPE_MASK ((0x1 << ONDISK_MESSAGE_TYPE_BITS) - 1)" in definitions
    mask = (1 << bits) - 1
    blob = int(re.search(r"#define ONDISK_MESSAGE_IS_BLOB\s+\((0x[0-9a-fA-F]+)\)",
                         definitions).group(1), 0)
    invalid, maximum = (types["MESSAGE_TYPE_INVALID"],
                        types["MESSAGE_TYPE_MAX_VALID_USER_TYPE"])
    assert invalid == 0 and maximum == mask
    allowed = mask | blob
    rows = []
    for flags in range(256):
        kind = flags & mask
        original = not (flags & ~allowed or kind == invalid or kind > maximum)
        proposed = not (flags & ~allowed or kind == invalid)
        assert original == proposed, flags
        rows.append(dict(flags=flags, message_type=kind,
                         original_accepts=original, proposed_accepts=proposed))
    accepted = [row["flags"] for row in rows if row["original_accepts"]]
    assert accepted == [1, 2, 3, 5, 6, 7]
    result = dict(
        scope="Exhaustive flag-predicate equivalence only; no compiled/runtime tests",
        inputs={str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in (public, internal)},
        constants=dict(invalid=invalid, maximum=maximum, type_mask=mask,
                       blob_flag=blob, allowed_flags_mask=allowed),
        values_checked=len(rows), equivalent=True, accepted_flags=accepted, rows=rows)
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps({k: v for k, v in result.items() if k not in ("rows", "inputs")}))


if __name__ == "__main__":
    main()
