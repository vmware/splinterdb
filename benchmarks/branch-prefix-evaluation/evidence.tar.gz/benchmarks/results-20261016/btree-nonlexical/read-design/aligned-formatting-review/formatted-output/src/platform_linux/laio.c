// Copyright 2018-2026 VMware, Inc.
// SPDX-License-Identifier: Apache-2.0

/*
 * laio.c --
 *
 *     This file contains the implementation for a libaio wrapper.
 *
 * The external callable interfaces are defined in io.h. This module
 * supports both synchronous and async IO.
 *
 * - Sync  IO interfaces: io_read(), io_write()
 * - Async IO interfaces: io_read_async(), io_write_async()
 * - Async IO completion interfaces: io_cleanup(), io_cleanup_all()
 * - The Async IO functions require obtaining an io_async_req via
 *   laio_get_async_req(), followed by filling in its metadata and iovec
 *   members using laio_get_metadata() and laio_get_iovec().
 */

#include "platform_status.h"
#define POISON_FROM_PLATFORM_IMPLEMENTATION

#include "laio.h"
#include "platform_typed_alloc.h"
#include "async.h"
#include "platform_log.h"
#include "platform_sleep.h"
#include <linux/fs.h>
#include <sys/prctl.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#if defined(__has_feature)
#   if __has_feature(memory_sanitizer)
#      include <sanitizer/msan_interface.h>
#   endif
#endif
#include <string.h>

#define LAIO_CLEANER_TERMINATE_CALLBACK NULL

static inline process_context_state
laio_state_load(io_process_context *pctx)
{
   return __atomic_load_n(&pctx->state, __ATOMIC_ACQUIRE);
}

static inline void
laio_state_store(io_process_context *pctx, process_context_state state)
{
   __atomic_store_n(&pctx->state, state, __ATOMIC_RELEASE);
}

static inline uint64
laio_io_count_load(io_process_context *pctx)
{
   return __atomic_load_n(&pctx->io_count, __ATOMIC_ACQUIRE);
}

static inline void
laio_io_count_store(io_process_context *pctx, uint64 count)
{
   __atomic_store_n(&pctx->io_count, count, __ATOMIC_RELAXED);
}

static inline void
laio_record_submit_depth(io_process_context *pctx, uint64 depth)
{
   uint64 bucket = MIN(depth, (uint64)LAIO_QD_HIST_BUCKETS - 1);
   pctx->io_submit_hist[bucket]++;
   pctx->io_submit_count++;
   pctx->max_observed_io_count = MAX(pctx->max_observed_io_count, depth);
}

static void
laio_reset_stats(io_handle *ioh)
{
   laio_handle *io = (laio_handle *)ioh;

   for (uint64 i = 0; i < MAX_THREADS; i++) {
      io_process_context *pctx    = &io->ctx[i];
      pctx->io_submit_count       = 0;
      pctx->io_submit_eagain      = 0;
      pctx->max_observed_io_count = laio_io_count_load(pctx);
      memset(pctx->io_submit_hist, 0, sizeof(pctx->io_submit_hist));
   }
}

static void
laio_print_stats(io_handle *ioh, platform_log_handle *log_handle)
{
   laio_handle *io                         = (laio_handle *)ioh;
   uint64       total_submit_count         = 0;
   uint64       total_submit_eagain        = 0;
   uint64       max_observed_depth         = 0;
   uint64       hist[LAIO_QD_HIST_BUCKETS] = {0};

   for (uint64 i = 0; i < MAX_THREADS; i++) {
      io_process_context *pctx = &io->ctx[i];
      total_submit_count += pctx->io_submit_count;
      total_submit_eagain += pctx->io_submit_eagain;
      max_observed_depth = MAX(max_observed_depth, pctx->max_observed_io_count);
      for (uint64 bucket = 0; bucket < LAIO_QD_HIST_BUCKETS; bucket++) {
         hist[bucket] += pctx->io_submit_hist[bucket];
      }
   }

   platform_log(log_handle, "LAIO Queue Depth Histogram\n");
   platform_log(
      log_handle,
      "------------------------------------------------------------\n");
   platform_log(log_handle, "successful submits: %lu\n", total_submit_count);
   platform_log(log_handle, "EAGAIN retries:     %lu\n", total_submit_eagain);
   platform_log(log_handle, "max observed depth: %lu\n", max_observed_depth);
   platform_log(log_handle, "submit-depth histogram:\n");
   for (uint64 bucket = 0; bucket < LAIO_QD_HIST_BUCKETS; bucket++) {
      if (hist[bucket] == 0) {
         continue;
      }
      if (bucket + 1 == LAIO_QD_HIST_BUCKETS) {
         platform_log(log_handle,
                      "  >=%-3u : %lu\n",
                      IO_DEFAULT_KERNEL_QUEUE_SIZE,
                      hist[bucket]);
      } else {
         platform_log(log_handle, "  %-5lu: %lu\n", bucket, hist[bucket]);
      }
   }
   platform_log(
      log_handle,
      "------------------------------------------------------------\n");
}

/*
 * Context management
 */

static int
laio_cleanup_one(io_process_context *pctx, int mincnt)
{
   struct io_event event = {0};
   int             status;

   status = io_getevents(pctx->ctx, mincnt, 1, &event, NULL);
   if (status < 0
       && laio_state_load(pctx) != PROCESS_CONTEXT_STATE_SHUTTING_DOWN)
   {
      platform_error_log("%s(): OS-pid=%d, "
                         "io_count=%lu,"
                         "failed with errorno=%d: %s\n",
                         __func__,
                         platform_get_os_pid(),
                         laio_io_count_load(pctx),
                         -status,
                         strerror(-status));
   }
   if (status <= 0) {
      return 0;
   }

   io_callback_t callback = (io_callback_t)event.data;

   // When we are being shut down, the main thread will set the callback to this
   // value to indicate that we should exit.
   if (callback == LAIO_CLEANER_TERMINATE_CALLBACK) {
      __sync_fetch_and_sub(&pctx->io_count, 1);
      return 0;
   }

   // Invoke the callback for the one event that completed.
   callback(pctx->ctx, event.obj, event.res, 0);

   // Release one waiter if there is one
   async_wait_queue_release_one(&pctx->submit_waiters);

   __sync_fetch_and_sub(&pctx->io_count, 1);

   return 1;
}

static void *
laio_cleaner(void *arg)
{
   io_process_context *pctx = (io_process_context *)arg;
   prctl(PR_SET_NAME, "laio_cleaner", 0, 0, 0);
   while (laio_state_load(pctx) != PROCESS_CONTEXT_STATE_SHUTTING_DOWN) {
      laio_cleanup_one(pctx, 1);
   }
   return NULL;
}

/*
 * A size cache is invalidated, rather than updated, after writes because writes
 * need not be append-only and a short write may still have extended the file.
 * The next range query obtains the authoritative logical size from the kernel.
 */
static inline void
laio_invalidate_logical_size(laio_handle *io)
{
   __atomic_fetch_add(&io->write_generation, 1, __ATOMIC_RELEASE);
}

static platform_status
laio_get_logical_size(laio_handle *io, uint64 *size)
{
   if (io->backing_type == LAIO_BACKING_REGULAR) {
      struct stat statbuf;
      if (fstat(io->fd, &statbuf) != 0) {
         int saved_errno = errno;
         platform_error_log("fstat failed while querying logical size: %s\n",
                            strerror(saved_errno));
         return CONST_STATUS(saved_errno);
      }
      if (statbuf.st_size < 0) {
         platform_error_log("fstat returned negative logical size %ld\n",
                            (long)statbuf.st_size);
         return STATUS_IO_ERROR;
      }
      *size = (uint64)statbuf.st_size;
      return STATUS_OK;
   }

   if (io->backing_type == LAIO_BACKING_BLOCK) {
      uint64 block_size;
      if (ioctl(io->fd, BLKGETSIZE64, &block_size) != 0) {
         int saved_errno = errno;
         platform_error_log(
            "BLKGETSIZE64 failed while querying logical size: %s\n",
            strerror(saved_errno));
         return CONST_STATUS(saved_errno);
      }
      *size = block_size;
      return STATUS_OK;
   }

   platform_error_log("Cannot query the logical size of this backing object\n");
   return STATUS_NOTSUP;
}

static platform_status
laio_range_is_readable(io_handle *ioh,
                       uint64     addr,
                       uint64     bytes,
                       bool32    *readable)
{
   laio_handle *io = (laio_handle *)ioh;

   if (readable == NULL) {
      return STATUS_BAD_PARAM;
   }
   *readable = FALSE;

   if (UINT64_MAX - addr < bytes) {
      return STATUS_BAD_PARAM;
   }

   uint64 logical_size;
   while (TRUE) {
      uint64 write_generation =
         __atomic_load_n(&io->write_generation, __ATOMIC_ACQUIRE);
      uint64 size_generation =
         __atomic_load_n(&io->logical_size_generation, __ATOMIC_ACQUIRE);

      if (size_generation == write_generation) {
         logical_size = __atomic_load_n(&io->logical_size, __ATOMIC_RELAXED);
      } else {
         /* Only one query may publish the size/generation pair. Recheck the
          * generation after acquiring the lock: another refresh or write may
          * have completed while we were waiting. */
         uint64 expected = 0;
         if (!__atomic_compare_exchange_n(&io->logical_size_refresh_lock,
                                          &expected,
                                          1,
                                          FALSE,
                                          __ATOMIC_ACQUIRE,
                                          __ATOMIC_RELAXED))
         {
            platform_sleep_ns(100);
            continue;
         }
         if (__atomic_load_n(&io->write_generation, __ATOMIC_ACQUIRE)
             != write_generation)
         {
            __atomic_store_n(
               &io->logical_size_refresh_lock, 0, __ATOMIC_RELEASE);
            continue;
         }
         platform_status rc = laio_get_logical_size(io, &logical_size);
         if (!SUCCESS(rc)) {
            __atomic_store_n(
               &io->logical_size_refresh_lock, 0, __ATOMIC_RELEASE);
            return rc;
         }

         /* Do not publish a size observed concurrently with a completion. */
         if (__atomic_load_n(&io->write_generation, __ATOMIC_ACQUIRE)
             != write_generation)
         {
            __atomic_store_n(
               &io->logical_size_refresh_lock, 0, __ATOMIC_RELEASE);
            continue;
         }

         __atomic_store_n(&io->logical_size, logical_size, __ATOMIC_RELAXED);
         __atomic_store_n(
            &io->logical_size_generation, write_generation, __ATOMIC_RELEASE);
         __atomic_store_n(&io->logical_size_refresh_lock, 0, __ATOMIC_RELEASE);
      }

      /*
       * A completion after either the cached load or the cache publication
       * invalidates the value.  Retry so that a query starting after io_write()
       * returns, or running from an async completion callback, cannot see the
       * pre-write EOF.
       */
      if (__atomic_load_n(&io->write_generation, __ATOMIC_ACQUIRE)
          != write_generation)
      {
         continue;
      }
      break;
   }

   *readable = addr <= logical_size && bytes <= logical_size - addr;
   return STATUS_OK;
}

/*
 * laio_read() - Basically a wrapper around pread().
 */
static platform_status
laio_read(io_handle *ioh, void *buf, uint64 bytes, uint64 addr)
{
   laio_handle *io;
   ssize_t      ret;

   io = (laio_handle *)ioh;
   do {
      ret = pread(io->fd, buf, bytes, addr);
   } while (ret < 0 && errno == EINTR);
#if defined(__has_feature)
#   if __has_feature(memory_sanitizer)
   if (ret > 0) {
      __msan_unpoison(buf, ret);
   }
#   endif
#endif
   if (ret >= 0 && (uint64)ret == bytes) {
      return STATUS_OK;
   }
   if (ret < 0) {
      platform_error_log("laio_read: pread failed for addr %lu, bytes %lu: "
                         "%s\n",
                         addr,
                         bytes,
                         strerror(errno));
   } else {
      platform_error_log("laio_read: short read for addr %lu, bytes %lu, "
                         "read %ld\n",
                         addr,
                         bytes,
                         (long)ret);
   }
   return STATUS_IO_ERROR;
}

/*
 * laio_write() - Basically a wrapper around pwrite().
 */
static platform_status
laio_write(io_handle *ioh, void *buf, uint64 bytes, uint64 addr)
{
   laio_handle *io        = (laio_handle *)ioh;
   char        *cursor    = buf;
   uint64       offset    = addr;
   uint64       remaining = bytes;

   /*
    * Finish a short write rather than reporting it. pwrite() is permitted to
    * satisfy only part of the request, and the cache's writeback-retry path
    * treats any failure here as a hard I/O error -- so returning early on a
    * write that was merely chunked would mark a perfectly good page as failed
    * and have it retried forever.
    */
   while (remaining > 0) {
      ssize_t ret = pwrite(io->fd, cursor, remaining, offset);
      if (ret < 0) {
         if (errno == EINTR) {
            continue;
         }
         platform_error_log("laio_write: pwrite failed for addr %lu, "
                            "bytes %lu, remaining %lu: %s\n",
                            addr,
                            bytes,
                            remaining,
                            strerror(errno));
         return STATUS_IO_ERROR;
      }
      if (ret == 0) {
         platform_error_log("laio_write: pwrite made no progress for addr %lu, "
                            "bytes %lu, remaining %lu\n",
                            addr,
                            bytes,
                            remaining);
         return STATUS_IO_ERROR;
      }
      laio_invalidate_logical_size(io);
      cursor += ret;
      offset += ret;
      remaining -= ret;
   }
   return STATUS_OK;
}

/*
 *--------------------------------------------------------------------------
 * laio_durable_barrier --
 *
 * Make completed writes durable. Waiting for asynchronous I/O only tells us
 * that the kernel accepted the writes; fdatasync() supplies the persistence
 * ordering needed by checkpoint publication on buffered files.
 *--------------------------------------------------------------------------
 */
static platform_status
laio_durable_barrier(io_handle *ioh)
{
   laio_handle *io = (laio_handle *)ioh;
   int          ret;

   do {
      ret = fdatasync(io->fd);
   } while (ret != 0 && errno == EINTR);

   if (ret == 0) {
      return STATUS_OK;
   }

   int saved_errno = errno;
   platform_error_log("laio_durable_barrier: fdatasync failed: %s\n",
                      strerror(saved_errno));
   return CONST_STATUS(saved_errno);
}

/*
 * Accessor method: Return opaque handle to IO-context setup by io_setup().
 */
static io_process_context *
laio_get_thread_context(laio_handle *io)
{
   threadid pid = platform_linux_get_pid();
   platform_assert(pid < MAX_THREADS, "Invalid pid=%lu", pid);
   io_process_context *pctx = &io->ctx[pid];
   if (laio_state_load(pctx) == PROCESS_CONTEXT_STATE_UNINITIALIZED) {
      while (__sync_lock_test_and_set(&pctx->lock, 1)) {
         // spin
      }
      if (laio_state_load(pctx) != PROCESS_CONTEXT_STATE_UNINITIALIZED) {
         __sync_lock_release(&pctx->lock);
         return pctx;
      }
      laio_io_count_store(pctx, 0);
      pctx->io_submit_count       = 0;
      pctx->io_submit_eagain      = 0;
      pctx->max_observed_io_count = 0;
      memset(pctx->io_submit_hist, 0, sizeof(pctx->io_submit_hist));
      int status = io_setup(io->cfg->kernel_queue_size, &pctx->ctx);
      if (status != 0) {
         platform_error_log(
            "io_setup() failed for PID=%lu, ctx=%p with error=%d: %s\n",
            pid,
            &pctx->ctx,
            -status,
            strerror(-status));
         __sync_lock_release(&pctx->lock);
         return NULL;
      }
      async_wait_queue_init(&pctx->submit_waiters);
      int pthread_status =
         pthread_create(&pctx->io_cleaner, NULL, laio_cleaner, pctx);
      if (pthread_status != 0) {
         platform_error_log("pthread_create() failed for laio cleaner "
                            "PID=%lu: %s\n",
                            pid,
                            strerror(pthread_status));
      }
      platform_assert(pthread_status == 0);
      laio_state_store(pctx, PROCESS_CONTEXT_STATE_INITIALIZED);
      __sync_lock_release(&pctx->lock);
   }
   return pctx;
}

typedef struct laio_async_state {
   io_async_state      super;
   async_state         __async_state_stack[1];
   laio_handle        *io;
   io_async_cmd        cmd;
   uint64              addr;
   async_callback_fn   callback;
   void               *callback_arg;
   async_waiter        waiter_node;
   io_process_context *pctx;
   platform_status     rc;
   struct iocb         req;
   struct iocb        *reqs[1];
   long                status;
   uint64              iovlen;
   struct iovec        iovs[];
} laio_async_state;

_Static_assert(
   sizeof(laio_async_state) <= IO_ASYNC_STATE_BUFFER_SIZE,
   "laio_async_read_state is to large for IO_ASYNC_STATE_BUFFER_SIZE");
_Static_assert(_Alignof(laio_async_state) <= _Alignof(io_async_state_buffer),
               "io_async_state_buffer has insufficient alignment");

static void
laio_async_state_deinit(io_async_state *ios)
{
}

static platform_status
laio_async_state_append_page(io_async_state *ios, void *buf)
{
   laio_async_state *lios = (laio_async_state *)ios;
   uint64            pages_per_extent =
      lios->io->cfg->extent_size / lios->io->cfg->page_size;

   if (lios->iovlen == pages_per_extent) {
      platform_error_log("laio_async_state_append_page: request for addr %lu "
                         "already has %lu pages, limit %lu\n",
                         lios->addr,
                         lios->iovlen,
                         pages_per_extent);
      return STATUS_LIMIT_EXCEEDED;
   }

   lios->iovs[lios->iovlen].iov_base = buf;
   lios->iovs[lios->iovlen].iov_len  = lios->io->cfg->page_size;
   lios->iovlen++;
   return STATUS_OK;
}

static const struct iovec *
laio_async_state_get_iovec(io_async_state *ios, uint64 *iovlen)
{
   laio_async_state *lios = (laio_async_state *)ios;
   *iovlen                = lios->iovlen;
   return lios->iovs;
}

static void
laio_async_callback(io_context_t ctx, struct iocb *iocb, long res, long res2)
{
   laio_async_state *ios =
      (laio_async_state *)((char *)iocb - offsetof(laio_async_state, req));
   ios->status = res;
   /*
    * A positive short completion may have extended a regular file.  Invalidate
    * for every write completion, including failures, because the completion
    * result alone does not have to prove that no bytes reached the device.
    * Publish the invalidation before the client callback may issue a query.
    */
   if (ios->cmd == io_async_pwritev) {
      laio_invalidate_logical_size(ios->io);
   }
   if (ios->callback) {
      ios->callback(ios->callback_arg);
   }
}

static async_status
laio_async_run(io_async_state *gios)
{
   // Reset submit_status to 1 every time we enter the function (1 is the return
   // value from a successful call to io_submit).  This enables us to avoid
   // mutating the state (e.g. by storing the submit_status in the state) and
   // still exit the loop after yielding when the io_submit is successful..
   int submit_status = 1;

   // Every other iteration we try optimisitically
   async_wait_queue *queue = NULL;

   laio_async_state *ios = (laio_async_state *)gios;

   async_begin(ios, 0);

   if (ios->iovlen == 0) {
      async_return(ios);
   }

   ios->pctx = laio_get_thread_context(ios->io);
   if (ios->pctx == NULL) {
      platform_error_log("laio_async_run: failed to get thread context for "
                         "addr %lu\n",
                         ios->addr);
      ios->status = -EIO;
      async_return(ios);
   }
   if (ios->cmd == io_async_preadv) {
      io_prep_preadv(&ios->req, ios->io->fd, ios->iovs, ios->iovlen, ios->addr);
   } else {
      io_prep_pwritev(
         &ios->req, ios->io->fd, ios->iovs, ios->iovlen, ios->addr);
   }
   io_set_callback(&ios->req, laio_async_callback);

   // We increment the io_count before submitting the request to avoid
   // having the io_count go negative if another thread calls io_cleanup.
   __sync_fetch_and_add(&ios->pctx->io_count, 1);

   // Submit the request to the kernel and, if it succeeds, yield without making
   // any further accesses to ios.  This is necessary to avoid racing with
   // calls from io_cleanup to our callback function.  Furthermore, wait on the
   // submit_waiters queue until the request succeeds or fails hard (i.e. not
   // EAGAIN).  This also means that we can't save the result of io_submit in
   // the state, so we save it in a local variable, submit_status.  This is safe
   // because the only times we yield between writing and reading submit_status
   // is on success, which is why we reset submit_status to 1 at the beginning
   // of the function.

   // The following code is equivalent to the commented out code below, but
   // avoids a goto into a statement expression, which some compilers do not
   // allow.

   //
   // async_wait_on_queue_until(
   //    ({
   //       async_yield_if(
   //          ios,
   //          (submit_status = io_submit(ios->pctx->ctx, 1, ios->reqs)) == 1);
   //       submit_status != EAGAIN;
   //    }),
   //    ios,
   //    &ios->pctx->submit_waiters,
   //    &ios->waiter_node,
   //    ios->callback,
   //    ios->callback_arg);


   while (1) {
      ios->__async_state_stack[0] = &&io_has_completed;

      if (queue != NULL) {
         async_wait_queue_lock(queue);
      }

      io_process_context *pctx = ios->pctx;

      submit_status = io_submit(pctx->ctx, 1, ios->reqs);

      if (submit_status == 1) {
         // Successfully submitted, which means that our state was stored on the
         // kernel's wait queue for this io, which means we have "given away"
         // our state and therefore must not touch it again before returning.
         laio_record_submit_depth(pctx, laio_io_count_load(pctx));
         if (queue != NULL) {
            async_wait_queue_unlock(queue);
         }
         return ASYNC_STATUS_RUNNING;

      io_has_completed:
         // The IO has completed, so we can safely access the state again.
         async_return(ios);

      } else if (submit_status != -EAGAIN) {
         // Hard failure, which means we still own our state.  Bail out.
         if (queue != NULL) {
            async_wait_queue_unlock(queue);
         }
         __sync_fetch_and_sub(&ios->pctx->io_count, 1);
         ios->status = submit_status - 1; // Don't set status to 0
         platform_error_log("%s(): OS-pid=%d, tid=%lu"
                            ", io_submit errorno=%d: %s\n",
                            __func__,
                            platform_get_os_pid(),
                            platform_get_tid(),
                            -submit_status,
                            strerror(-submit_status));
         async_return(ios);

      } else if (queue != NULL) {
         // Transient failure to submit, so we still own our state.  Wait to try
         // again.
         ios->pctx->io_submit_eagain++;
         async_wait_queue_append(
            queue, &ios->waiter_node, ios->callback, ios->callback_arg);
         async_yield_after(ios, async_wait_queue_unlock(queue));
         // queue will be reset to NULL upon re-entry
      } else {
         // Transient failure to submit, so we still own our state, but we were
         // trying optimistically to submit w/o locking our wait queue.  So try
         // again with lock held.
         ios->pctx->io_submit_eagain++;
         queue = &ios->pctx->submit_waiters;
         continue;
      }
   }

   platform_assert(0, "Should not reach here");
}

static platform_status
laio_async_state_get_result(io_async_state *gios)
{
   laio_async_state *ios = (laio_async_state *)gios;
   if (ios->status < 0) {
      platform_error_log("laio_async_state_get_result: async %s failed for "
                         "addr %lu, pages %lu, status %ld: %s\n",
                         ios->cmd == io_async_preadv ? "read" : "write",
                         ios->addr,
                         ios->iovlen,
                         ios->status,
                         strerror(-ios->status));
      return STATUS_IO_ERROR;
   }

   /* Linux AIO reports the preadv/pwritev return value in io_event.res, which
    * laio_async_callback() stores in status.  A nonnegative value can still be
    * a short completion, so success requires every requested byte. */
   uint64 expected_bytes = 0;
   for (uint64 i = 0; i < ios->iovlen; i++) {
      expected_bytes += ios->iovs[i].iov_len;
   }
   if ((uint64)ios->status != expected_bytes) {
      platform_error_log("laio_async_state_get_result: async %s was short for "
                         "addr %lu, pages %lu: requested %lu bytes, "
                         "completed %ld bytes\n",
                         ios->cmd == io_async_preadv ? "read" : "write",
                         ios->addr,
                         ios->iovlen,
                         expected_bytes,
                         ios->status);
      return STATUS_IO_ERROR;
   }
   return STATUS_OK;
}

static io_async_state_ops laio_async_state_ops = {
   .append_page = laio_async_state_append_page,
   .run         = laio_async_run,
   .get_result  = laio_async_state_get_result,
   .get_iovec   = laio_async_state_get_iovec,
   .deinit      = laio_async_state_deinit,
};

static platform_status
laio_async_state_init(io_async_state   *state,
                      io_handle        *gio,
                      io_async_cmd      cmd,
                      uint64            addr,
                      async_callback_fn callback,
                      void             *callback_arg)
{
   laio_async_state *ios = (laio_async_state *)state;
   laio_handle      *io  = (laio_handle *)gio;

   ios->super.ops              = &laio_async_state_ops;
   ios->__async_state_stack[0] = ASYNC_STATE_INIT;
   ios->io                     = io;
   ios->cmd                    = cmd;
   ios->addr                   = addr;
   ios->callback               = callback;
   ios->callback_arg           = callback_arg;
   async_waiter_init(&ios->waiter_node);
   ios->reqs[0] = &ios->req;
   ios->iovlen  = 0;
   ios->status  = 0;
   return STATUS_OK;
}

/*
 * laio_cleanup() - Handle completion of outstanding IO requests for currently
 * running process. Up to 'count' outstanding IO requests will be processed.
 * Specify 'count' as 0 to process completion of all pending IO requests.
 */
static void
laio_cleanup(io_handle *ioh, uint64 count)
{
   laio_handle *io = (laio_handle *)ioh;

   threadid pid = platform_linux_get_pid();
   platform_assert(pid < MAX_THREADS, "Invalid pid=%lu", pid);
   io_process_context *pctx = &io->ctx[pid];

   // Check for completion of up to 'count' events, one event at a time.
   // Or, check for all outstanding events (count == 0)
   int i = 0;
   while ((count == 0 || i < count) && 0 < laio_io_count_load(pctx)) {
      i += laio_cleanup_one(pctx, 0);
   }
}

/*
 * laio_wait_all() - Handle completion of outstanding IO requests for our
 * process, and wait for all other process's IOs to complete.
 */
static void
laio_wait_all(io_handle *ioh)
{
   laio_handle *io;
   uint64       i;

   io = (laio_handle *)ioh;
   for (i = 0; i < MAX_THREADS; i++) {
      if (i == platform_linux_get_pid()) {
         io_cleanup(ioh, 0);
      } else {
         while (0 < laio_io_count_load(&io->ctx[i])) {
            io_cleanup(ioh, 0);
         }
      }
   }
}

static platform_status
laio_wakeup_cleaner(io_process_context *pctx,
                    struct iocb        *iocb,
                    int                 fd,
                    char                buf[1])
{
   __sync_fetch_and_add(&pctx->io_count, 1);
   io_prep_pread(iocb, fd, buf, 1, 0);
   io_set_callback(iocb, LAIO_CLEANER_TERMINATE_CALLBACK);
   int status = io_submit(pctx->ctx, 1, &iocb);
   if (status != 1) {
      platform_error_log("laio_wakeup_cleaner: io_submit failed, status=%d: "
                         "%s\n",
                         status,
                         status < 0 ? strerror(-status) : "unexpected result");
      return STATUS_IO_ERROR;
   }
   return STATUS_OK;
}


static void
laio_process_termination_callback(threadid pid, void *arg)
{
   laio_handle        *io   = (laio_handle *)arg;
   io_process_context *pctx = &io->ctx[pid];

   if (laio_state_load(pctx) == PROCESS_CONTEXT_STATE_INITIALIZED) {
      laio_cleanup(&io->super, 0);
      while (__sync_lock_test_and_set(&pctx->lock, 1)) {
         // spin
      }
      if (laio_state_load(pctx) != PROCESS_CONTEXT_STATE_INITIALIZED) {
         __sync_lock_release(&pctx->lock);
         return;
      }
      uint64 io_count = laio_io_count_load(pctx);
      platform_assert(io_count == 0, "io_count=%lu", io_count);

      laio_state_store(pctx, PROCESS_CONTEXT_STATE_SHUTTING_DOWN);
      struct iocb     iocb;
      char            buf[1];
      platform_status rc = laio_wakeup_cleaner(pctx, &iocb, io->fd, buf);
      if (!SUCCESS(rc)) {
         platform_error_log("laio_wakeup_cleaner() failed: %s\n",
                            strerror(errno));
      }
      pthread_join(pctx->io_cleaner, NULL);
      int status = io_destroy(pctx->ctx);
      platform_assert(status == 0,
                      "io_destroy() failed with error=%d: %s\n",
                      -status,
                      strerror(-status));
      async_wait_queue_deinit(&pctx->submit_waiters);

      // subsequent io_setup calls on this ctx will fail if we don't reset it.
      // Seems like a bug in libaio/linux.
      //
      // Furthermore, clang-tidy generates a warning about the sizeof expression
      // because pctx->ctx is a pointer and it is often a bug to memcpy onto a
      // pointer (as opposed to memcpying to the location that the pointer
      // points to).  But here we want to use memcpy, rather than assigning
      // NULL, because the type of pctx->ctx is supposed to be opaque.  So we
      // disable the warning.
      memset(&pctx->ctx,
             0,
             sizeof(pctx->ctx)); // NOLINT(bugprone-sizeof-expression)

      laio_state_store(pctx, PROCESS_CONTEXT_STATE_UNINITIALIZED);
      __sync_lock_release(&pctx->lock);
   }
}

/*
 * Define an implementation of the abstract IO Ops interface methods.
 */
static io_ops laio_ops = {
   .read              = laio_read,
   .write             = laio_write,
   .range_is_readable = laio_range_is_readable,
   .async_state_init  = laio_async_state_init,
   .cleanup           = laio_cleanup,
   .wait_all          = laio_wait_all,
   .durable_barrier   = laio_durable_barrier,
   .print_stats       = laio_print_stats,
   .reset_stats       = laio_reset_stats,
};

/*
 * Given an IO configuration, validate it. Allocate memory for various
 * sub-structures and allocate the SplinterDB device. Initialize the IO
 * sub-system, registering the file descriptor for SplinterDB device.
 * Returns a pointer to the created io_handle, or NULL on error.
 */
io_handle *
laio_handle_create(io_config *cfg, platform_heap_id hid)
{
   // Validate IO-configuration parameters
   platform_status rc = laio_config_valid(cfg);
   if (!SUCCESS(rc)) {
      return NULL;
   }

   laio_handle *io = TYPED_MALLOC(hid, io);
   if (io == NULL) {
      platform_error_log("laio_handle_create: failed to allocate io handle\n");
      return NULL;
   }

   memset(io, 0, sizeof(*io));
   io->super.ops = &laio_ops;
   io->cfg       = cfg;
   io->heap_id   = hid;

   bool32 is_create = ((cfg->flags & O_CREAT) != 0);
   if (is_create) {
      io->fd = open(cfg->filename, cfg->flags, cfg->perms);
   } else {
      io->fd = open(cfg->filename, cfg->flags);
   }
   if (io->fd == -1) {
      platform_error_log(
         "open() '%s' failed: %s\n", cfg->filename, strerror(errno));
      platform_free(hid, io);
      return NULL;
   }

   struct stat statbuf;
   int         r = fstat(io->fd, &statbuf);
   if (r) {
      platform_error_log("fstat failed: %s\n", strerror(errno));
      close(io->fd);
      platform_free(hid, io);
      return NULL;
   }

   if (S_ISREG(statbuf.st_mode)) {
      io->backing_type = LAIO_BACKING_REGULAR;
   } else if (S_ISBLK(statbuf.st_mode)) {
      io->backing_type = LAIO_BACKING_BLOCK;
   } else {
      io->backing_type = LAIO_BACKING_UNSUPPORTED;
   }
   /* Generation zero is reserved for an invalid, never-populated size cache. */
   io->write_generation = 1;


// 32 4KB pages
#define EXTENT_SIZE (32 * 4 * 1024)

   if (S_ISREG(statbuf.st_mode) && statbuf.st_size < EXTENT_SIZE) {
      r = fallocate(io->fd, 0, 0, EXTENT_SIZE);
      if (r && errno == EOPNOTSUPP) {
         if (statbuf.st_size == 0) {
            uint8_t zeroes[EXTENT_SIZE] = {0};
            r = pwrite(io->fd, &zeroes, EXTENT_SIZE, 0);
            if (r != EXTENT_SIZE) {
               platform_error_log("fallocate not supported by filesystem and "
                                  "fallback write failed: %s\n",
                                  strerror(errno));
               goto write_failed;
            }
            r = lseek(io->fd, 0, SEEK_SET);
            if (r != 0) {
               platform_error_log("fallocate not supported by filesystem and "
                                  "seek back to 0 failed: %s\n",
                                  strerror(errno));
               goto seek_failed;
            }
         } else {
            platform_error_log(
               "database file has non-zero length (%ld) less than "
               "size of superblock and filesystem does not support fallocate",
               statbuf.st_size);
            goto no_fallocate_and_bad_size;
         }
      } else if (r) {
         platform_error_log("fallocate failed: %s\n", strerror(errno));
         goto fallocate_failed;
      }
   }

#undef EXTENT_SIZE

   io->pecnode.termination = laio_process_termination_callback;
   io->pecnode.arg         = io;
   rc = platform_linux_add_process_event_callback(&io->pecnode);
   if (!SUCCESS(rc)) {
      platform_error_log("failed to register process event callback: %s\n",
                         platform_status_to_string(rc));
      goto process_event_callback_failed;
   }

   // leave req_hand set to 0
   return (io_handle *)io;

process_event_callback_failed:
write_failed:
seek_failed:
no_fallocate_and_bad_size:
fallocate_failed:
   close(io->fd);
   platform_free(hid, io);
   return NULL;
}

/*
 * Dismantle the handle for the IO sub-system, close file and release memory.
 */
void
laio_handle_destroy(io_handle *ioh)
{
   laio_handle *io = (laio_handle *)ioh;
   int          status;

   platform_linux_remove_process_event_callback(&io->pecnode);
   threadid pid = platform_linux_get_pid();
   laio_process_termination_callback(pid, ioh);

   for (int i = 0; i < MAX_THREADS; i++) {
      if (laio_state_load(&io->ctx[i]) != PROCESS_CONTEXT_STATE_UNINITIALIZED) {
         platform_error_log("ERROR: io_handle_destroy(): IO context for PID=%d"
                            " is still active.\n",
                            i);
      }
   }

   status = close(io->fd);
   if (status != 0) {
      platform_error_log("close failed, status=%d, with error %d: %s\n",
                         status,
                         errno,
                         strerror(errno));
   }
   platform_assert(status == 0);

   platform_free(io->heap_id, io);
}

/*
 *  Config ops
 */

static inline bool32
laio_config_valid_page_size(io_config *cfg)
{
   return (cfg->page_size == IO_DEFAULT_PAGE_SIZE);
}

static inline bool32
laio_config_valid_extent_size(io_config *cfg)
{
   return (cfg->extent_size == IO_DEFAULT_EXTENT_SIZE);
}


/*
 * Do basic validation of IO configuration so we don't have to deal
 * with unsupported configurations that may creep through there.
 */
platform_status
laio_config_valid(io_config *cfg)
{
   if (!laio_config_valid_page_size(cfg)) {
      platform_error_log(
         "Page-size, %lu bytes, is an invalid IO configuration.\n",
         cfg->page_size);
      return STATUS_BAD_PARAM;
   }

   if (!laio_config_valid_extent_size(cfg)) {
      platform_error_log(
         "Extent-size, %lu bytes, is an invalid IO configuration.\n",
         cfg->extent_size);
      return STATUS_BAD_PARAM;
   }
   uint64 pages_per_extent = cfg->extent_size / cfg->page_size;

   if (IO_ASYNC_STATE_BUFFER_SIZE
       < sizeof(laio_async_state) + pages_per_extent * sizeof(struct iovec))
   {
      return STATUS_BAD_PARAM;
   }

   return STATUS_OK;
}
