// Copyright 2018-2026 VMware, Inc.
// SPDX-License-Identifier: Apache-2.0

/*
 * io.h --
 *
 *     This file contains the abstract interface for IO.
 */

#pragma once

#include "async.h"
#include "platform_status.h"
#include "platform_string.h"
#include "platform_util.h"
#include "platform_heap.h"
#include "platform_time.h"
#include <fcntl.h>

typedef struct io_handle      io_handle;
typedef struct io_async_req   io_async_req;
typedef struct io_async_state io_async_state;

struct iovec;

/*
 * SplinterDB can be configured with different page-sizes, given by these
 * min & max values.
 */
#define IO_MIN_PAGE_SIZE (4096)
#define IO_MAX_PAGE_SIZE (8192)

#define IO_DEFAULT_PAGE_SIZE        IO_MIN_PAGE_SIZE
#define IO_DEFAULT_PAGES_PER_EXTENT 32
#define IO_DEFAULT_EXTENT_SIZE                                                 \
   (IO_DEFAULT_PAGES_PER_EXTENT * IO_DEFAULT_PAGE_SIZE)

#define IO_DEFAULT_FLAGS             (O_RDWR | O_CREAT)
#define IO_DEFAULT_PERMS             (0600)
#define IO_DEFAULT_KERNEL_QUEUE_SIZE (256)
#define IO_DEFAULT_ASYNC_QUEUE_DEPTH (256)

/*
 * IO Configuration structure - used to setup the run-time IO system.
 */
typedef struct io_config {
   uint64 kernel_queue_size;
   uint64 page_size;
   uint64 extent_size;
   char   filename[MAX_STRING_LENGTH];
   int    flags;
   uint32 perms;
} io_config;

typedef void (*io_callback_fn)(void           *metadata,
                               struct iovec   *iovec,
                               uint64          count,
                               platform_status status);

typedef platform_status (*io_read_fn)(io_handle *io,
                                      void      *buf,
                                      uint64     bytes,
                                      uint64     addr);
typedef platform_status (*io_write_fn)(io_handle *io,
                                       void      *buf,
                                       uint64     bytes,
                                       uint64     addr);
typedef platform_status (*io_range_is_readable_fn)(io_handle *io,
                                                   uint64     addr,
                                                   uint64     bytes,
                                                   bool32    *readable);

#define IO_ASYNC_STATE_BUFFER_SIZE (1024)
/* Backends store their native async state in this opaque byte buffer. Its
 * alignment must hold when embedded after a smaller field in another state. */
typedef uint8 io_async_state_buffer[IO_ASYNC_STATE_BUFFER_SIZE]
   __attribute__((aligned(_Alignof(max_align_t))));
typedef enum { io_async_preadv, io_async_pwritev } io_async_cmd;
typedef platform_status (*io_async_state_init_fn)(io_async_state   *state,
                                                  io_handle        *io,
                                                  io_async_cmd      cmd,
                                                  uint64            addr,
                                                  async_callback_fn callback,
                                                  void *callback_arg);

typedef void (*io_cleanup_fn)(io_handle *io, uint64 count);
typedef void (*io_wait_all_fn)(io_handle *io);
typedef platform_status (*io_durable_barrier_fn)(io_handle *io);
typedef void (*io_register_thread_fn)(io_handle *io);
typedef void (*io_deregister_thread_fn)(io_handle *io);
typedef bool32 (*io_max_latency_elapsed_fn)(io_handle *io, timestamp ts);
typedef void (*io_print_stats_fn)(io_handle *io, platform_log_handle *log);
typedef void (*io_reset_stats_fn)(io_handle *io);

typedef void *(*io_get_context_fn)(io_handle *io);

/*
 * An abstract IO interface, holding different IO Ops function pointers.
 */
typedef struct io_ops {
   io_read_fn                read;
   io_write_fn               write;
   io_range_is_readable_fn   range_is_readable;
   io_async_state_init_fn    async_state_init;
   io_cleanup_fn             cleanup;
   io_wait_all_fn            wait_all;
   io_durable_barrier_fn     durable_barrier;
   io_register_thread_fn     register_thread;
   io_deregister_thread_fn   deregister_thread;
   io_max_latency_elapsed_fn max_latency_elapsed;
   io_print_stats_fn         print_stats;
   io_reset_stats_fn         reset_stats;
   io_get_context_fn         get_context;
} io_ops;

/*
 * To sub-class io, make an io your first field;
 */
struct io_handle {
   const io_ops *ops;
};

typedef void (*io_async_state_deinit_fn)(io_async_state *state);
typedef platform_status (*io_async_state_append_page_fn)(io_async_state *state,
                                                         void           *buf);
typedef const struct iovec *(
   *io_async_state_get_iovec_fn)(io_async_state *state, uint64 *iovlen);
typedef async_status (*io_async_io_fn)(io_async_state *state);

typedef platform_status (*io_async_state_get_result_fn)(io_async_state *state);

typedef struct io_async_state_ops {
   io_async_state_append_page_fn append_page;
   io_async_io_fn                run;
   io_async_state_get_result_fn  get_result;
   io_async_state_get_iovec_fn   get_iovec;
   io_async_state_deinit_fn      deinit;
} io_async_state_ops;

struct io_async_state {
   const io_async_state_ops *ops;
};

static inline platform_status
io_read(io_handle *io, void *buf, uint64 bytes, uint64 addr)
{
   return io->ops->read(io, buf, bytes, addr);
}

/*
 * Report whether the complete half-open range [addr, addr + bytes) is
 * currently readable from the backing object.  This is a logical-size query,
 * not a promise that the range contains allocated blocks, was ever written, or
 * is durable: a sparse hole below a regular file's EOF is readable and reports
 * TRUE.  Callers must still validate the data they subsequently read.
 * Regular files are bounded by their current logical EOF; block devices are
 * bounded by the capacity reported by the kernel.
 *
 * Query errors are returned separately from absence.  On success, a zero-byte
 * range is readable exactly when addr is no greater than the logical size.
 * An overflowing range is invalid and returns STATUS_BAD_PARAM.
 *
 * The result is coherent with writes made through this io_handle.  As with the
 * rest of the IO interface, modifying the backing object independently is not
 * supported.
 */
static inline platform_status
io_range_is_readable(io_handle *io, uint64 addr, uint64 bytes, bool32 *readable)
{
   return io->ops->range_is_readable(io, addr, bytes, readable);
}

static inline platform_status
io_write(io_handle *io, void *buf, uint64 bytes, uint64 addr)
{
   return io->ops->write(io, buf, bytes, addr);
}

static inline platform_status
io_async_state_init(io_async_state_buffer buffer,
                    io_handle            *io,
                    io_async_cmd          cmd,
                    uint64                addr,
                    async_callback_fn     callback,
                    void                 *callback_arg)
{
   io_async_state *state = (io_async_state *)buffer;
   return io->ops->async_state_init(
      state, io, cmd, addr, callback, callback_arg);
}

static inline void
io_async_state_deinit(io_async_state_buffer buffer)
{
   io_async_state *state = (io_async_state *)buffer;
   return state->ops->deinit(state);
}

static inline platform_status
io_async_state_append_page(io_async_state_buffer buffer, void *buf)
{
   io_async_state *state = (io_async_state *)buffer;
   return state->ops->append_page(state, buf);
}

static inline const struct iovec *
io_async_state_get_iovec(io_async_state_buffer buffer, uint64 *iovlen)
{
   io_async_state *state = (io_async_state *)buffer;
   return state->ops->get_iovec(state, iovlen);
}

static inline async_status
io_async_run(io_async_state_buffer buffer)
{
   io_async_state *state = (io_async_state *)buffer;
   return state->ops->run(state);
}

static inline platform_status
io_async_state_get_result(io_async_state_buffer buffer)
{
   io_async_state *state = (io_async_state *)buffer;
   return state->ops->get_result(state);
}

static inline void
io_cleanup(io_handle *io, uint64 count)
{
   return io->ops->cleanup(io, count);
}

// Wait until we have seen each process's I/O be quiescent.
//
// This means that all I/Os that were in-flight at the start of this call are
// guaranteed to have finished before this call returns.
//
// But I/Os that are issued after this call starts may not be complete when
// this call returns.
static inline void
io_wait_all(io_handle *io)
{
   return io->ops->wait_all(io);
}

/*
 *--------------------------------------------------------------------------
 * io_durable_barrier
 *
 * Ensure that writes which completed before this call survive a power loss.
 * This is deliberately distinct from io_wait_all(), which only waits for
 * asynchronous I/O completion.
 *--------------------------------------------------------------------------
 */
static inline platform_status
io_durable_barrier(io_handle *io)
{
   return io->ops->durable_barrier(io);
}

static inline void
io_register_thread(io_handle *io)
{
   if (io->ops->register_thread) {
      return io->ops->register_thread(io);
   }
}

static inline void
io_deregister_thread(io_handle *io)
{
   if (io->ops->deregister_thread) {
      return io->ops->deregister_thread(io);
   }
}

static inline bool32
io_max_latency_elapsed(io_handle *io, timestamp ts)
{
   if (io->ops->max_latency_elapsed) {
      return io->ops->max_latency_elapsed(io, ts);
   }
   return TRUE;
}

static inline void
io_print_stats(io_handle *io, platform_log_handle *log_handle)
{
   if (io->ops->print_stats) {
      io->ops->print_stats(io, log_handle);
   }
}

static inline void
io_reset_stats(io_handle *io)
{
   if (io->ops->reset_stats) {
      io->ops->reset_stats(io);
   }
}

/*
 *-----------------------------------------------------------------------------
 * io_config_init --
 *
 *      Initialize io config values
 *
 *  (Stores a copy of io_filename to io_cfg->filename, so the caller may
 *  deallocate io_filename once this returns)
 *-----------------------------------------------------------------------------
 */

static inline void
io_config_init(io_config  *io_cfg,
               uint64      page_size,
               uint64      extent_size,
               int         flags,
               uint32      perms,
               uint64      async_queue_depth,
               const char *io_filename)
{
   ZERO_CONTENTS(io_cfg);

   io_cfg->page_size   = page_size;
   io_cfg->extent_size = extent_size;

   int rc = snprintf(io_cfg->filename, MAX_STRING_LENGTH, "%s", io_filename);
   platform_assert(rc < MAX_STRING_LENGTH);

   io_cfg->flags             = flags;
   io_cfg->perms             = perms;
   io_cfg->kernel_queue_size = async_queue_depth;
}

platform_status
io_config_valid(io_config *cfg);

platform_status
io_read_bootstrap(const char *filename, void *buf, uint64 bytes, uint64 addr);


io_handle *
io_handle_create(io_config *cfg, platform_heap_id hid);

void
io_handle_destroy(io_handle *ioh);
