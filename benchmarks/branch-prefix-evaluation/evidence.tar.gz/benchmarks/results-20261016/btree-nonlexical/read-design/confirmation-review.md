# Independent confirmation/report review

The completed confirmation supports the requested nonlexical throughput goal
for the measured resident workloads. Every selected/main estimate is within
about 1.2% of main, and all nine individual nominal 95% lower bounds exceed
−3%. This is evidence against a 3% loss in each tested case, not a simultaneous
equivalence guarantee. A strict 2% margin remains unresolved for the one-key
scan. No additional nonlexical performance experiment is needed to address the
stated 2–3% tolerance on this machine; correctness validation remains separate.

The [review record](confirmation-review.json) independently recomputes all 63
primary throughput estimates and Student-t log-ratio intervals from the
summary's embedded result records. All match. All 378 samples verify their
checksums, report resident operation, zero active I/O and major faults, and
100% reported counter coverage. This is not a second raw-log parser or artifact
hash audit.

| Nonlexical case | Selected/main throughput | Nominal 95% interval | User instructions | User cycles |
| --- | ---: | ---: | ---: | ---: |
| Random inserts | +0.818% | [−0.567%, +2.223%] | −0.006% | −0.063% |
| Sorted inserts | +0.909% | [−0.491%, +2.330%] | −0.006% | −0.576% |
| Overwrites | −0.626% | [−1.423%, +0.177%] | approximately 0% | +0.054% |
| Pack | +1.162% | [−0.682%, +3.039%] | +1.517% | −0.956% |
| Point hits | +0.860% | [−1.849%, +3.644%] | +3.627% | −0.682% |
| Point misses | +0.382% | [−1.382%, +2.178%] | +3.467% | −1.398% |
| One-key scans | −0.450% | [−2.405%, +1.544%] | +3.635% | +0.130% |
| 10,000-key scans | +0.216% | [−1.444%, +1.905%] | +2.342% | −0.287% |
| Full scans | +0.131% | [−1.500%, +1.789%] | +2.339% | +0.062% |

Instructions and cycles are per operation for inserts, overwrites and point
queries, and per processed/returned tuple for packing and scans. Long-scan
instruction overhead falls from about 6.80% in the original candidate to 2.34%
in the selection: roughly 238.67 to 228.70 instructions per key for 10,000-key
scans, compared with main's 223.47. Point-hit instructions remain about 3277.74
per operation versus main's 3163.02. Therefore the correct conclusion is
throughput recovery, not elimination of all prefix-support CPU work. The
zero-prefix callback contingency is not required by these throughput results;
it could address a separately chosen instruction-budget or portability goal.

## Lexical limits and tradeoffs

The broader claim that every workload avoids losses above 2–3% is unsupported:

* Common-prefix pack remains −7.528% [−8.542%, −6.502%] versus main, with
  +32.326% user instructions. Its −0.315% [−1.943%, +1.339%] change versus the
  original candidate is unresolved; the selected read changes do not fix pack.
* Common-prefix 10,000-key scans remain −5.488% [−6.586%, −4.378%] versus main.
  The selection is −0.395% [−1.523%, +0.746%] versus the original candidate, but
  adds 2.708% instructions to that already compressed path. It executes about
  19.277% more instructions than main.
* Common-prefix full scans are −0.725% [−6.304%, +5.186%] versus main; this wide
  interval does not clear a 3% margin. The selection is −2.594%
  [−5.132%, +0.013%] versus the original candidate and uses +2.713% instructions.
  The earlier combination screen resolved a −2.27% loss versus the original;
  confirmation retains a negative estimate but narrowly includes zero. Report
  both separately, without pooling or claiming neutrality.
* Common-prefix hits, misses and one-key scans improve versus main by +2.00%,
  +6.20%, and +4.26%. Hits lose 1.12% [−1.88%, −0.36%] versus the original
  candidate, a small resolved selection tradeoff within the requested tolerance.
* Random lexical inputs have no compressed leaves. Selected pack is −0.177%
  [−1.349%, +1.009%] versus main, so the earlier tentative random-pack regression
  is not reproduced here. Random 10,000-key scans are +2.168%
  [+0.479%, +3.886%], and full scans are −0.905% [−1.947%, +0.149%].

Common-prefix trees occupy 26,611,712 bytes versus 36,835,328 bytes for main,
with 6260 compressed leaves out of 6261. That is a size observation; these
resident measurements do not demonstrate any on-disk throughput benefit.
Lexical main comparisons also change comparator dispatch eligibility as well as
stored representation. They are whole-branch comparisons, not isolated
compression-only effects. Selected versus original candidate holds those
policies and packed geometry constant.

## Report corrections and next decisions

At review time the root README still presents confirmation and debug/fault/
sanitizer work as future or queued. Replace that pending language with the
completed confirmation and exact final validation outcome once the separate
sanitizer investigation finishes. Do not describe all sanitizers as passed on
the basis of completed earlier tests.

The phrase "hardware instruction and cycle counters cover the active interval
only" should say the counters cover the separately enabled intervals including
timer/FIFO-control overhead, while excluding verification, reclamation and
resource snapshots. Active wall/process-CPU clock brackets remain primary.
The summary already states this distinction accurately.

There is no need to repeat the complete nonlexical matrix or measure another
read variant just because instruction overhead remains. A targeted one-key
scan repetition would be justified only for a strict 2% requirement. A focused
compressed full-scan confirmation could help quantify the selection tradeoff
if lexical neutrality is a release condition, but it cannot erase the already
resolved common-prefix pack and 10,000-key scan losses. Addressing those would
require another hypothesis and a separately defined performance objective.
