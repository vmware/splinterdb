# Independent source review: zero-prefix callback contingency

Result: no source correctness or invariant blocker found. This is source review
only; no compilation, runtime test, benchmark, or selection is implied. Exact
identities and body-equivalence checks are recorded in the
[review record](zero-prefix-callback-review.json).

Reviewed B-tree source SHA256:
`2f3d8737bc011e1762994878ed6e869602924ec900f1999e24166dd9cdf1f9d4`.
Parent `combined-read-blob-v1` remains unchanged at
`3d6a3f5d7dcc8ee5f3c474487715247d3ac901d2844f5f72cc2d9a1a0df69fad`.
The [focused delta](../proposals/zero-prefix-callback-from-selected.patch) SHA256
is `31b08025ae320700fa322a454fd7d9888bce2253c2e4671e3676a99097a10c59`.

The only callback-helper call remains guarded by `!lexical`, where
`lexical = compressed || (configured_lexical && finite_target)` and
`compressed = hdr->prefix_length != 0`. Consequently callback entry proves the
stored prefix equals zero. The proof depends on stored page metadata, not the
configuration flag. A previously compressed branch reopened with that flag
false still takes prefix comparison and lexical suffix search; it cannot enter
the specialized callback loop.

The checked search runs while its immutable branch leaf retains a cache read
reference. That keeps its bytes available, and the branch's immutability keeps
the prefix stable across comparator calls. Existing search already snapshots
entry count and compression policy before the loop, so this adds no new mutable
page assumption. Callback code is private and has just the one guarded caller.
Mutable memtable search remains on its existing separate path.

Both explicit-prefix parameters are `uint16`, matching the stored field without
truncation. Ordinary wrappers pass the actual stored prefix. The bounds helper
body is unchanged apart from substituting the explicit parameter for that field:
it retains index bounds before offset access, `next_entry` lower bound, complete
header extent, widened endpoint arithmetic, and output assignment only on
success. The leaf-key body similarly retains exact key flags, both forbidden
infinity length encodings, key-byte extent, and widened full-key length against
the configured page's maximum. `remaining - sizeof(entry)` remains safe because
the header-size check succeeds first. The shared body avoids a second validator
with potentially different acceptance rules.

Header validation, full entry/message/blob checks, checked-search dispatch,
sync/async lookup consumers, iterator positioning and rank search have unchanged
function bodies. Helper errors still return before comparator invocation or
entry output assignment. The callback loop's found/index/output updates and
comparison call are unchanged. Infinite targets on uncompressed lexical pages
still use `btree_key_compare`; infinite targets on compressed pages still leave
through the existing prefix comparison. Stored infinite leaf keys remain
invalid in either path.

Existing `test_branch_prefix_roundtrip` explicitly reopens both construction
policies with the lexical flag reversed and exercises boundary scans/seeks.
The selected tests overlay adds packed nonlexical sync/async hits, misses,
malformed key rejection, and forward/reverse/absent-key starts. Those are useful
future validation coverage for this variant, alongside the malformed leaf and
message tests; their earlier results do not count as this variant being tested.
Generated-loop inspection and measured performance remain pending coordinator
decisions.
