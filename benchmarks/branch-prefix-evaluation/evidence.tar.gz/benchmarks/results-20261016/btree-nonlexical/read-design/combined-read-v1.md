# Proposed combined read variant v1

Status: source frozen for review, unbuilt, untested, unselected. No production
source, existing frozen variant, build artifact, or selected alias was changed.
The coordinator will decide whether to build and measure this combination after
the independent message-type screen.

Base: `b9cc3ea4ecfd523d799116798285fb2d7fe0bfaa`, exported into
`.cache/btree-nonlexical-20261016/variants/combined-read-v1` from the previously
recorded immutable Git archive. Original B-tree source SHA256:
`6ceb7b6ea8d9c72c4112433f8dde617a3818de832b3e6e411d5914e3fd419aab`.
Final B-tree source SHA256:
`85a55ca9c873303c4fc851a23adb234c77c8ac2fd3960ea489682e0f6f5a3d93`.
[Combined patch](combined-read-v1.patch) SHA256:
`94bff042846faf69b5a10cb20a219ac4e3b49d501d4d45cb200c7dca2983a48d`.
The [manifest](combined-read-v1.json) records exact input patches, formatter
command/ranges, archive identity and source inventory. Only `src/btree.c` changes.

Composition, in application order:

1. **decode-outline** moves current compressed-key reconstruction into a
   non-inlined helper after entry validation. It preserves highwater buffer
   growth, page-prefix replacement, suffix copy and state reload after a
   fallible preparation call. On failure, the caller still clears its validated
   entry and poisons validation status before returning.
2. **message-type** retains allowed-flag and nonzero-type checks under exact
   compile-time range assertions. The independently recorded exhaustive proof
   covers every flag byte and preserves accepted values `1,2,3,5,6,7`. Entry
   bounds, message lengths and blob parsing are unchanged.
3. **callback-search** selects the callback-only checked binary-search loop
   once per leaf. Compressed-prefix handling still happens before dispatch;
   callback search receives full keys only. Each comparator invocation follows
   the unchanged checked-key read. Hits, misses, infinity handling, output
   indices and error propagation keep their prior semantics.

The edits do not overlap semantically: checked search chooses and validates a
candidate key; message validation checks the selected tuple's payload; iterator
reconstruction runs only after full entry validation. The callback-only search
continues to use the common checked-key reader. The message predicate is
unchanged in meaning in both search-result and scan validation. Decoder failure
cannot be hidden by either earlier change. No iterator-table or cached-page
constant design is included, so no additional page-transition lifecycle is
introduced. Mutable insertion and packing code are unchanged.

Changed ranges were formatted with Debian clang-format 19.1.7; a second pass
with the recorded ranges was identical. Formatter-only diffs are retained.
The two original read variants' B-tree hashes were checked unchanged. The full
export inventory is derived from the same archived source plus the sole edited
file, avoiding whole-tree hashing during active timing. The coordinator must
verify that inventory during the later build stage.

Compiler expectations are conditional. Independent decode-outline caused
validation to inline into `next`; independent message-type removed three
instructions from its flag-check path; callback specialization removed a
per-search-step dispatch decision. The combination may preserve these changes,
but LTO inlining, register allocation and layout must be inspected again. The
individual speed changes cannot be added, and the extra call for each compressed
key remains a real tradeoff requiring a compressed guardrail measurement.

The briefly prepared two-component combination was never built or selected.
Its patch and manifest are retained as `combined-read-v1-before-callback.*` for
provenance only; they are superseded and do not describe the current tree.
Independent final source interaction review passed for source SHA85a55ca9.
The proposed selected-read-tests-v1 overlay also passed source review: it retains
the packed nonlexical lookup/scan regression and adds malformed message-type-zero
and reserved-flag cases with full page restoration. These are source reviews;
no claim of measured performance improvement or completed regression validation
is made here.
