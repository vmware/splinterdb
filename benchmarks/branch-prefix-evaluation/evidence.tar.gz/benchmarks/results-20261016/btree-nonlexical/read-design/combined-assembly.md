# Compiled combined read variants

Both combinations preserve inlined validation in ordinary `btree_iterator_next`.
Adding rare-blob outlining removes one saved register and reduces that function's
local stack reservation from 80 to 24 bytes. It does not eliminate the stack
frame. These are compiled-code observations, not throughput measurements.

The coordinator built both frozen sources. Focused `nm` and `objdump` output is
in [assembly/combined](assembly/combined/manifest.json), with exact symbol sizes,
addresses, saved-register/local-stack instructions, call sites, and text hashes.
Binary identities below come from completed coordinator build records; this
inspection did not independently rehash binaries or source trees. All binary
reads completed before the subsequent measured screen. No build, test, or
benchmark was launched by this inspection.

| Variant | B-tree source SHA256 | Binary SHA256 |
| --- | --- | --- |
| combined-read-v1 | `85a55ca9c873303c4fc851a23adb234c77c8ac2fd3960ea489682e0f6f5a3d93` | `74a795b4fdc52ade30523628bb680c8b37568516a709a235681651c5103ba4c9` |
| combined-read-blob-v1 | `3d6a3f5d7dcc8ee5f3c474487715247d3ac901d2844f5f72cc2d9a1a0df69fad` | `7980d32dbbb5d52659d0f45745983448ec22dfd7e342c01b6a346d476216fc27` |

## Iterator code shape

Sizes include cold paths and alignment. Stack columns describe function entry
prologues and exclude the return address; they are not allocations per iterator.
The original candidate and its rare-blob/message-type probes call the separate
checker on ordinary advancement, so their small `next` sizes do not imply less
total work. Baseline/independent rows use the earlier archived disassembly.

| Variant | `next` bytes | Ordinary validation inline? | `next` saved registers / local bytes | Separate checker bytes | Checker saved registers / local bytes |
| --- | ---: | --- | --- | ---: | --- |
| main | `0x34f` | yes | 3 / `0x50` | `0x207` | 3 / `0x50` |
| original candidate | `0x12a` | no | 1 / 0 | `0x2ff` | 4 / `0x58` |
| rare-blob only | `0x12a` | no | 1 / 0 | `0x2f4` | 4 / `0x08` |
| message-type only | `0x12a` | no | 1 / 0 | `0x2ff` | 4 / `0x58` |
| decode-outline only | `0x38b` | yes | 3 / `0x50` | `0x233` | 3 / `0x50` |
| combined-read-v1 | `0x38b` | yes | 3 / `0x50` | `0x223` | 3 / `0x50` |
| combined-read-blob-v1 | `0x377` | yes | 2 / `0x18` | `0x210` | 2 / `0x18` |

In `combined-read-v1`, `next` starts at `0x16cb0` and saves `r12/rbp/rbx`.
In `combined-read-blob-v1`, it starts at `0x16d50` and saves only `rbp/rbx`.
Neither function calls `btree_iterator_check_current`. Both validate entry
bounds, key/message flags, lengths, and the blob descriptor before exposing an
entry; only a nonzero prefix calls the separate decode helper. The blob variant
spills the entry pointer at `rsp+8` only on its blob branch; ordinary inline
messages still pay the smaller entry/exit frame adjustments.

The combined blob helper is `0x22` bytes at `0xefb0`; it reserves `0x58` stack
bytes and calls `blob_parse_descriptor`. Its call in `next` is at `0x170a3`,
behind the blob flag branch. The extra helper call remains a tradeoff for blob
values. In both combinations the decode helper is `0x101` bytes and its
instructions match the independent decode-outline probe after address
normalization. `curr` remains `0x263` bytes and matches the original candidate
after address normalization. This combination does not remove `curr`'s prefix
test. `next_leaf` is `0x68e` in combined-read and `0x69e` in the blob combination,
both with six saved registers and `0xa8` local stack bytes.

## Message predicate and search dispatch

The shorter accepted-message predicate survives LTO and inlining in both
combinations. Immediately after loading flags, it is `test $3; je; cmp $7; ja`:
four instructions and two rejection branches. The original candidate used seven
instructions for the same predicate. In combined-read `next`, these instructions
are at `0x16e1a` through `0x16e28`; in the blob combination they are at `0x16eb6`
through `0x16ec4`. Full bounds validation and the blob-flag branch remain.

`btree_find_tuple_checked.lto_priv.0` is `0x595` bytes in each combination and
matches instruction-for-instruction after address normalization. The compiler
inlines the callback helper into a separate loop. In combined-read, prefix
selection is at `0xf29c`, and the reader lexical flag is loaded/tested at
`0xf2aa`/`0xf2ad`, before either loop. Ordinary callback-key search enters the
loop at `0xf4ca`, calls the comparator at `0xf5d2`, and takes backedges to
`0xf4b8`/`0xf4c5`; those edges do not revisit lexical dispatch. The lexical loop
starts at `0xf30d` and calls `memcmp` at `0xf3bc`. The blob binary has the same
search code with each address shifted by `0x30`.

The callback loop still loads the leaf prefix at `0xf4fc` to validate key bounds.
Moving dispatch outside the loop does not itself specialize that shared key
reader for a known-zero prefix. That is a separate possible hypothesis, not a
change in either inspected binary.

The smaller blob-combination frame is a real compiler interaction that the
standalone rare-blob probe did not produce. Throughput, full correctness testing,
and any adoption decision remain separate coordinator gates.
