
/home/rob/projects/splinterdb/.cache/projects-20261011/worktrees/branch-prefix/.cache/btree-nonlexical-20261016/combined-read-v1-btree-prefix-bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000012080 <btree_iterator_check_current>:
   12080:	push   %r12
   12082:	push   %rbp
   12083:	xor    %ebp,%ebp
   12085:	push   %rbx
   12086:	sub    $0x50,%rsp
   1208a:	cmpl   $0x2,0x1c(%rdi)
   1208e:	movq   $0x0,0xb8(%rdi)
   12099:	jne    121a2 <btree_iterator_check_current+0x122>
   1209f:	mov    0xb4(%rdi),%ebp
   120a5:	mov    %rdi,%rbx
   120a8:	test   %ebp,%ebp
   120aa:	jne    121a0 <btree_iterator_check_current+0x120>
   120b0:	mov    0x90(%rdi),%rdx
   120b7:	mov    0xa0(%rdi),%rax
   120be:	cmp    %rax,0x68(%rdi)
   120c2:	je     121e0 <btree_iterator_check_current+0x160>
   120c8:	cmp    %rdx,0x98(%rdi)
   120cf:	jg     121a2 <btree_iterator_check_current+0x122>
   120d5:	mov    0x80(%rbx),%rax
   120dc:	mov    0x10(%rbx),%rsi
   120e0:	cmpb   $0x0,0x20(%rax)
   120e4:	movzwl 0x24(%rax),%ecx
   120e8:	jne    121b0 <btree_iterator_check_current+0x130>
   120ee:	cmp    %cx,%dx
   120f1:	jae    121c0 <btree_iterator_check_current+0x140>
   120f7:	movzwl %dx,%edx
   120fa:	movzwl 0x28(%rax,%rdx,2),%ecx
   120ff:	cmp    0x22(%rax),%cx
   12103:	jb     121c0 <btree_iterator_check_current+0x140>
   12109:	mov    0x10(%rsi),%rdx
   1210d:	movzwl 0x26(%rax),%esi
   12111:	lea    0x6(%rcx),%r8
   12115:	mov    %rdx,%r9
   12118:	mov    %rsi,%rdi
   1211b:	sub    %rsi,%r9
   1211e:	cmp    %r8,%r9
   12121:	jb     121c0 <btree_iterator_check_current+0x140>
   12127:	lea    (%rax,%rcx,1),%r12
   1212b:	cmpb   $0x0,0x2(%r12)
   12131:	jne    121c0 <btree_iterator_check_current+0x140>
   12137:	movzwl (%r12),%r8d
   1213c:	mov    %rdx,%r9
   1213f:	shr    $0x3,%r9
   12143:	lea    (%r8,%rsi,1),%rax
   12147:	cmp    %rax,%r9
   1214a:	jb     121c0 <btree_iterator_check_current+0x140>
   1214c:	movzbl 0x5(%r12),%r9d
   12152:	test   $0x3,%r9b
   12156:	je     121c0 <btree_iterator_check_current+0x140>
   12158:	cmp    $0x7,%r9b
   1215c:	ja     121c0 <btree_iterator_check_current+0x140>
   1215e:	movzwl 0x3(%r12),%r10d
   12164:	lea    -0x6(%rdx),%rax
   12168:	sub    %rsi,%rax
   1216b:	lea    (%r8,%r10,1),%r11
   1216f:	sub    %rcx,%rax
   12172:	cmp    %r11,%rax
   12175:	jb     121c0 <btree_iterator_check_current+0x140>
   12177:	and    $0x4,%r9d
   1217b:	jne    12274 <btree_iterator_check_current+0x1f4>
   12181:	mov    %r12,0xb8(%rbx)
   12188:	test   %di,%di
   1218b:	je     121a2 <btree_iterator_check_current+0x122>
   1218d:	mov    %r12,%rsi
   12190:	mov    %rbx,%rdi
   12193:	call   11d00 <btree_iterator_decode_current>
   12198:	test   %eax,%eax
   1219a:	je     121a2 <btree_iterator_check_current+0x122>
   1219c:	mov    %eax,%ebp
   1219e:	jmp    121c5 <btree_iterator_check_current+0x145>
   121a0:	xor    %ebp,%ebp
   121a2:	add    $0x50,%rsp
   121a6:	mov    %ebp,%eax
   121a8:	pop    %rbx
   121a9:	pop    %rbp
   121aa:	pop    %r12
   121ac:	ret
   121ad:	nopl   (%rax)
   121b0:	cmp    %cx,%dx
   121b3:	jb     12208 <btree_iterator_check_current+0x188>
   121b5:	data16 cs nopw 0x0(%rax,%rax,1)
   121c0:	mov    $0x16,%ebp
   121c5:	movq   $0x0,0xb8(%rbx)
   121d0:	mov    %ebp,0xb4(%rbx)
   121d6:	jmp    121a2 <btree_iterator_check_current+0x122>
   121d8:	nopl   0x0(%rax,%rax,1)
   121e0:	mov    0xa8(%rdi),%rax
   121e7:	cmp    %rdx,%rax
   121ea:	jle    121a2 <btree_iterator_check_current+0x122>
   121ec:	mov    0x98(%rdi),%rcx
   121f3:	cmp    %rcx,%rax
   121f6:	je     121a2 <btree_iterator_check_current+0x122>
   121f8:	cmp    %rdx,%rcx
   121fb:	jg     121a2 <btree_iterator_check_current+0x122>
   121fd:	jmp    120d5 <btree_iterator_check_current+0x55>
   12202:	nopw   0x0(%rax,%rax,1)
   12208:	movzwl %dx,%edx
   1220b:	movzwl 0x28(%rax,%rdx,2),%edx
   12210:	cmp    0x22(%rax),%dx
   12214:	jb     121c0 <btree_iterator_check_current+0x140>
   12216:	movzwl 0x26(%rax),%ecx
   1221a:	mov    0x10(%rsi),%rsi
   1221e:	sub    %rcx,%rsi
   12221:	lea    0x17(%rdx),%rcx
   12225:	cmp    %rcx,%rsi
   12228:	jb     121c0 <btree_iterator_check_current+0x140>
   1222a:	add    %rdx,%rax
   1222d:	movzbl 0x16(%rax),%edi
   12231:	cmp    $0x1,%dil
   12235:	ja     121c0 <btree_iterator_check_current+0x140>
   12237:	movzwl 0x14(%rax),%ecx
   1223b:	mov    %rcx,%r8
   1223e:	add    $0x17,%rcx
   12242:	cmp    $0xfffd,%r8w
   12247:	mov    $0x17,%r8d
   1224d:	cmova  %r8,%rcx
   12251:	test   %dil,%dil
   12254:	lea    0xc(%rcx),%r8
   12258:	cmovne %r8,%rcx
   1225c:	sub    %rdx,%rsi
   1225f:	cmp    %rcx,%rsi
   12262:	jb     121c0 <btree_iterator_check_current+0x140>
   12268:	mov    %rax,0xb8(%rbx)
   1226f:	jmp    121a2 <btree_iterator_check_current+0x122>
   12274:	lea    0x6(%r12,%r8,1),%rax
   12279:	mov    0x8(%rbx),%rdi
   1227d:	mov    %rsp,%rcx
   12280:	mov    %r10,%rsi
   12283:	mov    %rax,%rdx
   12286:	call   242c0 <blob_parse_descriptor>
   1228b:	test   %eax,%eax
   1228d:	jne    1219c <btree_iterator_check_current+0x11c>
   12293:	mov    0x80(%rbx),%rax
   1229a:	movzwl 0x26(%rax),%edi
   1229e:	jmp    12181 <btree_iterator_check_current+0x101>

Disassembly of section .fini:
