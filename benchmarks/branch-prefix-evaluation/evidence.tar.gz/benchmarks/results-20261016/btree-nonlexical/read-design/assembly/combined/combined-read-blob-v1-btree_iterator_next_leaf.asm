
/home/rob/projects/splinterdb/.cache/projects-20261011/worktrees/branch-prefix/.cache/btree-nonlexical-20261016/combined-read-blob-v1-btree-prefix-bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000166b0 <btree_iterator_next_leaf>:
   166b0:	push   %r15
   166b2:	push   %r14
   166b4:	push   %r13
   166b6:	push   %r12
   166b8:	push   %rbp
   166b9:	push   %rbx
   166ba:	mov    %rdi,%rbx
   166bd:	sub    $0xa8,%rsp
   166c4:	mov    0x1c(%rdi),%ecx
   166c7:	mov    0x68(%rdi),%r12
   166cb:	cmp    $0x2,%ecx
   166ce:	jne    16930 <btree_iterator_next_leaf+0x280>
   166d4:	mov    0x80(%rdi),%rsi
   166db:	mov    0x18(%rsi),%rbp
   166df:	cmp    $0xffffffffffffffff,%rbp
   166e3:	je     168d9 <btree_iterator_next_leaf+0x229>
   166e9:	add    $0x1,%rbp
   166ed:	lea    0x68(%rdi),%r14
   166f1:	xor    %r13d,%r13d
   166f4:	testb  $0x2,0x21(%rsi)
   166f8:	jne    16717 <btree_iterator_next_leaf+0x67>
   166fa:	mov    0x10(%rdi),%rdi
   166fe:	xor    %edx,%edx
   16700:	mov    0x10(%rdi),%r13
   16704:	add    %r12,%r13
   16707:	mov    %r13,%rax
   1670a:	divq   0x18(%rdi)
   1670e:	test   %rdx,%rdx
   16711:	jne    16717 <btree_iterator_next_leaf+0x67>
   16713:	mov    0x8(%rsi),%r13
   16717:	cmpq   $0x0,0x70(%rbx)
   1671c:	je     16898 <btree_iterator_next_leaf+0x1e8>
   16722:	mov    0x8(%rbx),%rdi
   16726:	lea    0x70(%rbx),%rsi
   1672a:	mov    (%rdi),%rax
   1672d:	call   *0x30(%rax)
   16730:	pxor   %xmm0,%xmm0
   16734:	mov    0x1c(%rbx),%ecx
   16737:	movq   $0x0,0x80(%rbx)
   16742:	movups %xmm0,0x70(%rbx)
   16746:	mov    0x10(%rbx),%rsi
   1674a:	mov    0x8(%rbx),%rdi
   1674e:	mov    %r13,0x68(%rbx)
   16752:	mov    %r14,%rdx
   16755:	call   f820 <btree_node_get_checked.lto_priv.0>
   1675a:	test   %eax,%eax
   1675c:	jne    16950 <btree_iterator_next_leaf+0x2a0>
   16762:	cmpl   $0x2,0x1c(%rbx)
   16766:	je     16960 <btree_iterator_next_leaf+0x2b0>
   1676c:	mov    0x20(%rbx),%ecx
   1676f:	test   %ecx,%ecx
   16771:	je     16900 <btree_iterator_next_leaf+0x250>
   16777:	cmpq   $0x0,0x70(%rbx)
   1677c:	je     16900 <btree_iterator_next_leaf+0x250>
   16782:	mov    0x10(%rbx),%rax
   16786:	mov    0x88(%rbx),%rdi
   1678d:	mov    0x80(%rbx),%rsi
   16794:	mov    0x10(%rax),%rdx
   16798:	call   32e0 <memcpy@plt>
   1679d:	mov    0x8(%rbx),%rdi
   167a1:	lea    0x70(%rbx),%rsi
   167a5:	mov    (%rdi),%rax
   167a8:	call   *0x30(%rax)
   167ab:	mov    0x68(%rbx),%rdi
   167af:	mov    0x1c(%rbx),%ecx
   167b2:	pxor   %xmm0,%xmm0
   167b6:	mov    0x88(%rbx),%rsi
   167bd:	movups %xmm0,0x70(%rbx)
   167c1:	mov    %rdi,0xa0(%rbx)
   167c8:	mov    %rsi,0x80(%rbx)
   167cf:	movzwl 0x24(%rsi),%r13d
   167d4:	movl   $0x1,0xb0(%rbx)
   167de:	cmp    $0x3,%ecx
   167e1:	je     16825 <btree_iterator_next_leaf+0x175>
   167e3:	cmp    $0x2,%ecx
   167e6:	jne    16949 <btree_iterator_next_leaf+0x299>
   167ec:	cmpl   $0x3,0x48(%rbx)
   167f0:	sete   %al
   167f3:	test   %r13,%r13
   167f6:	sete   %dl
   167f9:	or     %edx,%eax
   167fb:	mov    %eax,%r8d
   167fe:	testb  $0x2,0x21(%rsi)
   16802:	jne    169e8 <btree_iterator_next_leaf+0x338>
   16808:	mov    0x10(%rbx),%r9
   1680c:	xor    %edx,%edx
   1680e:	mov    0x10(%r9),%r14
   16812:	add    %rdi,%r14
   16815:	mov    %r14,%rax
   16818:	divq   0x18(%r9)
   1681c:	test   %rdx,%rdx
   1681f:	jne    16b20 <btree_iterator_next_leaf+0x470>
   16825:	cmpl   $0x3,0x48(%rbx)
   16829:	mov    0x8(%rsi),%r14
   1682d:	je     168b0 <btree_iterator_next_leaf+0x200>
   16833:	test   %r13,%r13
   16836:	je     168b0 <btree_iterator_next_leaf+0x200>
   16838:	movdqu 0x48(%rbx),%xmm0
   1683d:	lea    0x38(%rsp),%rcx
   16842:	sub    $0x20,%rsp
   16846:	lea    -0x1(%r13),%rdx
   1684a:	mov    %rbx,%rdi
   1684d:	movups %xmm0,(%rsp)
   16851:	mov    0x58(%rbx),%rax
   16855:	mov    %rax,0x10(%rsp)
   1685a:	call   11250 <btree_iterator_compare_node_key.lto_priv.0>
   1685f:	add    $0x20,%rsp
   16863:	test   %eax,%eax
   16865:	jne    16950 <btree_iterator_next_leaf+0x2a0>
   1686b:	mov    0x38(%rsp),%eax
   1686f:	test   %eax,%eax
   16871:	jle    16a00 <btree_iterator_next_leaf+0x350>
   16877:	xor    %eax,%eax
   16879:	test   %r14,%r14
   1687c:	jne    16882 <btree_iterator_next_leaf+0x1d2>
   1687e:	mov    0x68(%rbx),%rax
   16882:	mov    %rax,0xa0(%rbx)
   16889:	mov    0x1c(%rbx),%ecx
   1688c:	mov    %r13,0xa8(%rbx)
   16893:	jmp    168c7 <btree_iterator_next_leaf+0x217>
   16895:	nopl   (%rax)
   16898:	movq   $0x0,0x80(%rbx)
   168a3:	jmp    16746 <btree_iterator_next_leaf+0x96>
   168a8:	nopl   0x0(%rax,%rax,1)
   168b0:	xor    %eax,%eax
   168b2:	test   %r14,%r14
   168b5:	mov    %r13,0xa8(%rbx)
   168bc:	cmovne %rax,%rdi
   168c0:	mov    %rdi,0xa0(%rbx)
   168c7:	cmp    $0x2,%ecx
   168ca:	jne    16900 <btree_iterator_next_leaf+0x250>
   168cc:	mov    0x80(%rbx),%rax
   168d3:	cmp    %rbp,0x18(%rax)
   168d7:	je     16900 <btree_iterator_next_leaf+0x250>
   168d9:	movl   $0x16,0xb4(%rbx)
   168e3:	mov    $0x16,%eax
   168e8:	add    $0xa8,%rsp
   168ef:	pop    %rbx
   168f0:	pop    %rbp
   168f1:	pop    %r12
   168f3:	pop    %r13
   168f5:	pop    %r14
   168f7:	pop    %r15
   168f9:	ret
   168fa:	nopw   0x0(%rax,%rax,1)
   16900:	movdqa 0x1a998(%rip),%xmm0        # 312a0 <__func__.13+0x68>
   16908:	mov    %rbx,%rdi
   1690b:	movups %xmm0,0x90(%rbx)
   16912:	call   116d0 <btree_iterator_prepare_end_idx.lto_priv.0>
   16917:	test   %eax,%eax
   16919:	jne    168e8 <btree_iterator_next_leaf+0x238>
   1691b:	mov    $0x1,%edx
   16920:	mov    %r12,%rsi
   16923:	mov    %rbx,%rdi
   16926:	call   14990 <btree_iterator_prefetch_on_advance>
   1692b:	xor    %eax,%eax
   1692d:	jmp    168e8 <btree_iterator_next_leaf+0x238>
   1692f:	nop
   16930:	mov    0x80(%rdi),%rax
   16937:	test   %rax,%rax
   1693a:	je     16d39 <btree_iterator_next_leaf+0x689>
   16940:	cmp    $0x3,%ecx
   16943:	je     169c8 <btree_iterator_next_leaf+0x318>
   16949:	call   15820 <btree_hdr_next_addr.part.0.lto_priv.0>
   1694e:	xchg   %ax,%ax
   16950:	mov    %eax,0xb4(%rbx)
   16956:	jmp    168e8 <btree_iterator_next_leaf+0x238>
   16958:	nopl   0x0(%rax,%rax,1)
   16960:	mov    0x80(%rbx),%rax
   16967:	movzbl 0x20(%rax),%eax
   1696b:	cmp    %eax,0x18(%rbx)
   1696e:	jne    16990 <btree_iterator_next_leaf+0x2e0>
   16970:	mov    0x20(%rbx),%edx
   16973:	test   %edx,%edx
   16975:	je     168cc <btree_iterator_next_leaf+0x21c>
   1697b:	cmpq   $0x0,0x70(%rbx)
   16980:	jne    16782 <btree_iterator_next_leaf+0xd2>
   16986:	jmp    168cc <btree_iterator_next_leaf+0x21c>
   1698b:	nopl   0x0(%rax,%rax,1)
   16990:	mov    0x8(%rbx),%rdi
   16994:	lea    0x70(%rbx),%rsi
   16998:	mov    (%rdi),%rax
   1699b:	call   *0x30(%rax)
   1699e:	pxor   %xmm0,%xmm0
   169a2:	mov    $0x16,%eax
   169a7:	movq   $0x0,0x80(%rbx)
   169b2:	movl   $0x16,0xb4(%rbx)
   169bc:	movups %xmm0,0x70(%rbx)
   169c0:	jmp    168e8 <btree_iterator_next_leaf+0x238>
   169c5:	nopl   (%rax)
   169c8:	xor    %ebp,%ebp
   169ca:	cmpq   $0x0,0x70(%rbx)
   169cf:	mov    0x8(%rax),%r13
   169d3:	lea    0x68(%rdi),%r14
   169d7:	jne    16722 <btree_iterator_next_leaf+0x72>
   169dd:	jmp    16898 <btree_iterator_next_leaf+0x1e8>
   169e2:	nopw   0x0(%rax,%rax,1)
   169e8:	test   %al,%al
   169ea:	je     16b00 <btree_iterator_next_leaf+0x450>
   169f0:	mov    %r13,0xa8(%rbx)
   169f7:	jmp    168cc <btree_iterator_next_leaf+0x21c>
   169fc:	nopl   0x0(%rax)
   16a00:	mov    0x40(%rbx),%eax
   16a03:	mov    %eax,0x14(%rsp)
   16a07:	cmp    $0x3,%eax
   16a0a:	ja     16d45 <btree_iterator_next_leaf+0x695>
   16a10:	movdqu 0x48(%rbx),%xmm0
   16a15:	mov    0x58(%rbx),%r13
   16a19:	mov    0x18(%rbx),%eax
   16a1c:	mov    0x80(%rbx),%r14
   16a23:	mov    %r13,0x50(%rsp)
   16a28:	movaps %xmm0,0x40(%rsp)
   16a2d:	test   %eax,%eax
   16a2f:	jne    16b40 <btree_iterator_next_leaf+0x490>
   16a35:	mov    0x10(%rbx),%rax
   16a39:	cmpl   $0x2,0x1c(%rbx)
   16a3d:	mov    %rax,(%rsp)
   16a41:	je     16b7d <btree_iterator_next_leaf+0x4cd>
   16a47:	mov    0x44(%rsp),%edx
   16a4b:	mov    0x40(%rsp),%eax
   16a4f:	movl   $0x0,0x3c(%rsp)
   16a57:	movzwl 0x24(%r14),%r8d
   16a5c:	mov    %edx,0x10(%rsp)
   16a60:	mov    0x48(%rsp),%rdx
   16a65:	mov    %rdx,0x8(%rsp)
   16a6a:	test   %r8,%r8
   16a6d:	je     16d3e <btree_iterator_next_leaf+0x68e>
   16a73:	cmp    $0x2,%eax
   16a76:	je     16bcf <btree_iterator_next_leaf+0x51f>
   16a7c:	mov    %r8,%rdx
   16a7f:	sar    $1,%rdx
   16a82:	cmp    $0x2,%eax
   16a85:	jg     16ab0 <btree_iterator_next_leaf+0x400>
   16a87:	jmp    16b13 <btree_iterator_next_leaf+0x463>
   16a8c:	data16 cs nopw 0x0(%rax,%rax,1)
   16a97:	nopw   0x0(%rax,%rax,1)
   16aa0:	add    %r8,%rdx
   16aa3:	mov    %rdx,%rax
   16aa6:	shr    $0x3f,%rax
   16aaa:	add    %rax,%rdx
   16aad:	sar    $1,%rdx
   16ab0:	add    $0x1,%rdx
   16ab4:	cmp    %rdx,%r8
   16ab7:	jg     16aa0 <btree_iterator_next_leaf+0x3f0>
   16ab9:	lea    -0x1(%rdx),%r15
   16abd:	mov    0x14(%rsp),%edx
   16ac1:	mov    $0x3,%eax
   16ac6:	sub    %edx,%eax
   16ac8:	cmp    $0x2,%eax
   16acb:	je     16cf4 <btree_iterator_next_leaf+0x644>
   16ad1:	cmp    $0x3,%eax
   16ad4:	je     16cfd <btree_iterator_next_leaf+0x64d>
   16ada:	test   %eax,%eax
   16adc:	jne    16af0 <btree_iterator_next_leaf+0x440>
   16ade:	cmpl   $0x1,0x3c(%rsp)
   16ae3:	adc    $0xffffffffffffffff,%r15
   16ae7:	nopw   0x0(%rax,%rax,1)
   16af0:	mov    %r15,0xa8(%rbx)
   16af7:	mov    0x1c(%rbx),%ecx
   16afa:	jmp    168c7 <btree_iterator_next_leaf+0x217>
   16aff:	nop
   16b00:	xor    %r14d,%r14d
   16b03:	jmp    16838 <btree_iterator_next_leaf+0x188>
   16b08:	nopl   0x0(%rax,%rax,1)
   16b10:	sar    $1,%rdx
   16b13:	test   %rdx,%rdx
   16b16:	jne    16b10 <btree_iterator_next_leaf+0x460>
   16b18:	jmp    16ab9 <btree_iterator_next_leaf+0x409>
   16b1a:	nopw   0x0(%rax,%rax,1)
   16b20:	test   %r8b,%r8b
   16b23:	je     16838 <btree_iterator_next_leaf+0x188>
   16b29:	movq   $0x0,0xa0(%rbx)
   16b34:	jmp    169f0 <btree_iterator_next_leaf+0x340>
   16b39:	nopl   0x0(%rax)
   16b40:	movzbl 0x20(%r14),%edx
   16b45:	cmp    %eax,%edx
   16b47:	jb     16bc0 <btree_iterator_next_leaf+0x510>
   16b49:	cmpl   $0x2,0x1c(%rbx)
   16b4d:	mov    0x10(%rbx),%rdi
   16b51:	je     16d0b <btree_iterator_next_leaf+0x65b>
   16b57:	lea    0x3c(%rsp),%rdx
   16b5c:	mov    %r14,%rsi
   16b5f:	sub    $0x20,%rsp
   16b63:	mov    %r13,0x10(%rsp)
   16b68:	movups %xmm0,(%rsp)
   16b6c:	call   9ea0 <btree_find_pivot>
   16b71:	add    $0x20,%rsp
   16b75:	mov    %rax,%r15
   16b78:	jmp    16abd <btree_iterator_next_leaf+0x40d>
   16b7d:	lea    0x80(%rsp),%rcx
   16b85:	lea    0x3c(%rsp),%rdx
   16b8a:	sub    $0x20,%rsp
   16b8e:	xor    %r8d,%r8d
   16b91:	mov    0x20(%rsp),%rdi
   16b96:	mov    %r14,%rsi
   16b99:	mov    %r13,0x10(%rsp)
   16b9e:	movups %xmm0,(%rsp)
   16ba2:	call   f280 <btree_find_tuple_checked.lto_priv.0>
   16ba7:	add    $0x20,%rsp
   16bab:	test   %eax,%eax
   16bad:	jne    16950 <btree_iterator_next_leaf+0x2a0>
   16bb3:	mov    0x80(%rsp),%r15
   16bbb:	jmp    16abd <btree_iterator_next_leaf+0x40d>
   16bc0:	movl   $0xffffffff,0x18(%rbx)
   16bc7:	xor    %r15d,%r15d
   16bca:	jmp    16af0 <btree_iterator_next_leaf+0x440>
   16bcf:	mov    %r12,0x18(%rsp)
   16bd4:	xor    %edx,%edx
   16bd6:	mov    %rbp,0x20(%rsp)
   16bdb:	mov    %r13,%rbp
   16bde:	mov    %rdx,%r13
   16be1:	mov    %rbx,0x28(%rsp)
   16be6:	mov    %r8,%rbx
   16be9:	nopl   0x0(%rax)
   16bf0:	lea    (%rbx,%r13,1),%rax
   16bf4:	mov    (%rsp),%rdx
   16bf8:	mov    %rbp,0x68(%rsp)
   16bfd:	sub    $0x30,%rsp
   16c01:	mov    %rax,%r15
   16c04:	shr    $0x3f,%r15
   16c08:	mov    0x8(%rdx),%rcx
   16c0c:	mov    0x38(%rsp),%rdx
   16c11:	movl   $0x0,0xc0(%rsp)
   16c1c:	add    %rax,%r15
   16c1f:	sar    $1,%r15
   16c22:	mov    %rdx,0x90(%rsp)
   16c2a:	mov    0x40(%rsp),%edx
   16c2e:	movzwl %r15w,%eax
   16c32:	movzwl 0x28(%r14,%rax,2),%eax
   16c38:	mov    %edx,0xa0(%rsp)
   16c3f:	add    %r14,%rax
   16c42:	movzwl (%rax),%edi
   16c45:	add    $0x6,%rax
   16c49:	mov    %rax,0xb8(%rsp)
   16c51:	mov    %rdi,0xb0(%rsp)
   16c59:	mov    0xc0(%rsp),%rax
   16c61:	mov    %rcx,%rdi
   16c64:	movdqa 0xb0(%rsp),%xmm0
   16c6d:	mov    %rax,0x28(%rsp)
   16c72:	mov    0xa0(%rsp),%rax
   16c7a:	movups %xmm0,0x18(%rsp)
   16c7f:	movdqa 0x90(%rsp),%xmm0
   16c88:	mov    %rax,0x10(%rsp)
   16c8d:	movups %xmm0,(%rsp)
   16c91:	call   *(%rcx)
   16c93:	add    $0x30,%rsp
   16c97:	test   %eax,%eax
   16c99:	je     16cd8 <btree_iterator_next_leaf+0x628>
   16c9b:	jle    16cc8 <btree_iterator_next_leaf+0x618>
   16c9d:	lea    0x1(%r15),%r13
   16ca1:	cmp    %rbx,%r13
   16ca4:	jl     16bf0 <btree_iterator_next_leaf+0x540>
   16caa:	mov    0x18(%rsp),%r12
   16caf:	mov    0x20(%rsp),%rbp
   16cb4:	mov    %r13,%rdx
   16cb7:	mov    0x28(%rsp),%rbx
   16cbc:	jmp    16ab9 <btree_iterator_next_leaf+0x409>
   16cc1:	nopl   0x0(%rax)
   16cc8:	cmp    %r13,%r15
   16ccb:	jle    16caa <btree_iterator_next_leaf+0x5fa>
   16ccd:	mov    %r15,%rbx
   16cd0:	jmp    16bf0 <btree_iterator_next_leaf+0x540>
   16cd5:	nopl   (%rax)
   16cd8:	movl   $0x1,0x3c(%rsp)
   16ce0:	mov    0x20(%rsp),%rbp
   16ce5:	mov    0x18(%rsp),%r12
   16cea:	mov    0x28(%rsp),%rbx
   16cef:	jmp    16abd <btree_iterator_next_leaf+0x40d>
   16cf4:	add    $0x1,%r15
   16cf8:	jmp    16af0 <btree_iterator_next_leaf+0x440>
   16cfd:	cmpl   $0x1,0x3c(%rsp)
   16d02:	adc    $0x0,%r15
   16d06:	jmp    16af0 <btree_iterator_next_leaf+0x440>
   16d0b:	lea    0x80(%rsp),%rcx
   16d13:	lea    0x3c(%rsp),%rdx
   16d18:	xor    %r8d,%r8d
   16d1b:	sub    $0x20,%rsp
   16d1f:	mov    %r14,%rsi
   16d22:	mov    %r13,0x10(%rsp)
   16d27:	movups %xmm0,(%rsp)
   16d2b:	call   efe0 <btree_find_pivot_checked.lto_priv.0>
   16d30:	add    $0x20,%rsp
   16d34:	jmp    16bab <btree_iterator_next_leaf+0x4fb>
   16d39:	call   16680 <btree_node_next_addr.part.0.lto_priv.0>
   16d3e:	xor    %edx,%edx
   16d40:	jmp    16ab9 <btree_iterator_next_leaf+0x409>
   16d45:	mov    0x14(%rsp),%edi
   16d49:	call   123b0 <comparison_invert.part.0.lto_priv.0>

Disassembly of section .fini:
