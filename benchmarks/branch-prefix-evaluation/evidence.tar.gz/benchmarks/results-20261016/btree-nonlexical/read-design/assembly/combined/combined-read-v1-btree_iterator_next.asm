
/home/rob/projects/splinterdb/.cache/projects-20261011/worktrees/branch-prefix/.cache/btree-nonlexical-20261016/combined-read-v1-btree-prefix-bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000016cb0 <btree_iterator_next>:
   16cb0:	push   %r12
   16cb2:	push   %rbp
   16cb3:	push   %rbx
   16cb4:	sub    $0x50,%rsp
   16cb8:	mov    0xb4(%rdi),%ebp
   16cbe:	test   %ebp,%ebp
   16cc0:	je     16cd0 <btree_iterator_next+0x20>
   16cc2:	add    $0x50,%rsp
   16cc6:	mov    %ebp,%eax
   16cc8:	pop    %rbx
   16cc9:	pop    %rbp
   16cca:	pop    %r12
   16ccc:	ret
   16ccd:	nopl   (%rax)
   16cd0:	mov    0xd8(%rdi),%esi
   16cd6:	mov    %rdi,%rbx
   16cd9:	test   %esi,%esi
   16cdb:	je     16cf8 <btree_iterator_next+0x48>
   16cdd:	mov    0xcc(%rdi),%ecx
   16ce3:	test   %ecx,%ecx
   16ce5:	jne    16ea0 <btree_iterator_next+0x1f0>
   16ceb:	mov    $0x1,%esi
   16cf0:	mov    %rbx,%rdi
   16cf3:	call   14bc0 <btree_iterator_maybe_start_prefetch.part.0>
   16cf8:	mov    0x80(%rbx),%rdx
   16cff:	mov    0x90(%rbx),%rax
   16d06:	movzwl 0x24(%rdx),%edx
   16d0a:	add    $0x1,%rax
   16d0e:	mov    %rax,0x90(%rbx)
   16d15:	cmp    %rdx,%rax
   16d18:	jne    16d50 <btree_iterator_next+0xa0>
   16d1a:	mov    0xb4(%rbx),%edx
   16d20:	test   %edx,%edx
   16d22:	jne    16d50 <btree_iterator_next+0xa0>
   16d24:	mov    0xa0(%rbx),%rcx
   16d2b:	cmp    %rcx,0x68(%rbx)
   16d2f:	je     16f90 <btree_iterator_next+0x2e0>
   16d35:	mov    %rbx,%rdi
   16d38:	call   16620 <btree_iterator_next_leaf>
   16d3d:	test   %eax,%eax
   16d3f:	jne    16ff0 <btree_iterator_next+0x340>
   16d45:	data16 cs nopw 0x0(%rax,%rax,1)
   16d50:	movq   $0x0,0xb8(%rbx)
   16d5b:	cmpl   $0x2,0x1c(%rbx)
   16d5f:	jne    16cc2 <btree_iterator_next+0x12>
   16d65:	mov    0xb4(%rbx),%eax
   16d6b:	test   %eax,%eax
   16d6d:	jne    16cc2 <btree_iterator_next+0x12>
   16d73:	mov    0x90(%rbx),%rdx
   16d7a:	mov    0xa0(%rbx),%rax
   16d81:	cmp    %rax,0x68(%rbx)
   16d85:	je     16fb8 <btree_iterator_next+0x308>
   16d8b:	cmp    %rdx,0x98(%rbx)
   16d92:	jg     16f88 <btree_iterator_next+0x2d8>
   16d98:	mov    0x80(%rbx),%rax
   16d9f:	mov    0x10(%rbx),%rsi
   16da3:	cmpb   $0x0,0x20(%rax)
   16da7:	movzwl 0x24(%rax),%ecx
   16dab:	jne    16f10 <btree_iterator_next+0x260>
   16db1:	cmp    %cx,%dx
   16db4:	jae    17000 <btree_iterator_next+0x350>
   16dba:	movzwl %dx,%edx
   16dbd:	movzwl 0x28(%rax,%rdx,2),%ecx
   16dc2:	cmp    0x22(%rax),%cx
   16dc6:	jb     17000 <btree_iterator_next+0x350>
   16dcc:	mov    0x10(%rsi),%rdx
   16dd0:	movzwl 0x26(%rax),%edi
   16dd4:	lea    0x6(%rcx),%r8
   16dd8:	mov    %rdx,%r9
   16ddb:	mov    %rdi,%rsi
   16dde:	sub    %rdi,%r9
   16de1:	cmp    %r8,%r9
   16de4:	jb     17000 <btree_iterator_next+0x350>
   16dea:	lea    (%rax,%rcx,1),%r12
   16dee:	cmpb   $0x0,0x2(%r12)
   16df4:	jne    17000 <btree_iterator_next+0x350>
   16dfa:	movzwl (%r12),%r8d
   16dff:	mov    %rdx,%r9
   16e02:	mov    $0x16,%ebp
   16e07:	shr    $0x3,%r9
   16e0b:	lea    (%r8,%rdi,1),%rax
   16e0f:	cmp    %rax,%r9
   16e12:	jb     16e80 <btree_iterator_next+0x1d0>
   16e14:	movzbl 0x5(%r12),%r9d
   16e1a:	test   $0x3,%r9b
   16e1e:	je     17000 <btree_iterator_next+0x350>
   16e24:	cmp    $0x7,%r9b
   16e28:	ja     17000 <btree_iterator_next+0x350>
   16e2e:	movzwl 0x3(%r12),%r10d
   16e34:	lea    -0x6(%rdx),%rax
   16e38:	sub    %rdi,%rax
   16e3b:	lea    (%r8,%r10,1),%r11
   16e3f:	sub    %rcx,%rax
   16e42:	cmp    %r11,%rax
   16e45:	jb     16e80 <btree_iterator_next+0x1d0>
   16e47:	and    $0x4,%r9d
   16e4b:	jne    1700a <btree_iterator_next+0x35a>
   16e51:	mov    %r12,0xb8(%rbx)
   16e58:	test   %si,%si
   16e5b:	je     16f88 <btree_iterator_next+0x2d8>
   16e61:	mov    %r12,%rsi
   16e64:	mov    %rbx,%rdi
   16e67:	call   11d00 <btree_iterator_decode_current>
   16e6c:	mov    %eax,%ebp
   16e6e:	test   %eax,%eax
   16e70:	je     16f88 <btree_iterator_next+0x2d8>
   16e76:	cs nopw 0x0(%rax,%rax,1)
   16e80:	movq   $0x0,0xb8(%rbx)
   16e8b:	mov    %ebp,0xb4(%rbx)
   16e91:	jmp    16cc2 <btree_iterator_next+0x12>
   16e96:	cs nopw 0x0(%rax,%rax,1)
   16ea0:	cmpl   $0x1,0xd4(%rdi)
   16ea7:	je     16cf8 <btree_iterator_next+0x48>
   16ead:	cmpq   $0x0,0x108(%rdi)
   16eb5:	je     16ed6 <btree_iterator_next+0x226>
   16eb7:	lea    0x108(%rdi),%rsi
   16ebe:	mov    0xf8(%rdi),%rdi
   16ec5:	mov    (%rdi),%rax
   16ec8:	call   *0x30(%rax)
   16ecb:	pxor   %xmm0,%xmm0
   16ecf:	movups %xmm0,0x108(%rbx)
   16ed6:	movl   $0x0,0xc8(%rbx)
   16ee0:	pxor   %xmm0,%xmm0
   16ee4:	movq   $0x0,0xcc(%rbx)
   16eef:	movq   $0x0,0xf0(%rbx)
   16efa:	movups %xmm0,0x118(%rbx)
   16f01:	movups %xmm0,0x128(%rbx)
   16f08:	jmp    16ceb <btree_iterator_next+0x3b>
   16f0d:	nopl   (%rax)
   16f10:	cmp    %cx,%dx
   16f13:	jae    17000 <btree_iterator_next+0x350>
   16f19:	movzwl %dx,%edx
   16f1c:	movzwl 0x28(%rax,%rdx,2),%edx
   16f21:	cmp    0x22(%rax),%dx
   16f25:	jb     17000 <btree_iterator_next+0x350>
   16f2b:	movzwl 0x26(%rax),%ecx
   16f2f:	mov    0x10(%rsi),%rsi
   16f33:	sub    %rcx,%rsi
   16f36:	lea    0x17(%rdx),%rcx
   16f3a:	cmp    %rcx,%rsi
   16f3d:	jb     17000 <btree_iterator_next+0x350>
   16f43:	add    %rdx,%rax
   16f46:	movzbl 0x16(%rax),%edi
   16f4a:	cmp    $0x1,%dil
   16f4e:	ja     17000 <btree_iterator_next+0x350>
   16f54:	movzwl 0x14(%rax),%ecx
   16f58:	mov    %rcx,%r8
   16f5b:	add    $0x17,%rcx
   16f5f:	cmp    $0xfffd,%r8w
   16f64:	mov    $0x17,%r8d
   16f6a:	cmova  %r8,%rcx
   16f6e:	test   %dil,%dil
   16f71:	lea    0xc(%rcx),%r8
   16f75:	cmovne %r8,%rcx
   16f79:	sub    %rdx,%rsi
   16f7c:	cmp    %rcx,%rsi
   16f7f:	jb     17000 <btree_iterator_next+0x350>
   16f81:	mov    %rax,0xb8(%rbx)
   16f88:	xor    %ebp,%ebp
   16f8a:	jmp    16cc2 <btree_iterator_next+0x12>
   16f8f:	nop
   16f90:	mov    0xa8(%rbx),%rdx
   16f97:	cmp    %rdx,%rax
   16f9a:	jge    16d50 <btree_iterator_next+0xa0>
   16fa0:	cmp    0x98(%rbx),%rdx
   16fa7:	jne    16d35 <btree_iterator_next+0x85>
   16fad:	jmp    16d50 <btree_iterator_next+0xa0>
   16fb2:	nopw   0x0(%rax,%rax,1)
   16fb8:	mov    0xa8(%rbx),%rax
   16fbf:	xor    %ebp,%ebp
   16fc1:	cmp    %rdx,%rax
   16fc4:	jle    16cc2 <btree_iterator_next+0x12>
   16fca:	mov    0x98(%rbx),%rcx
   16fd1:	cmp    %rcx,%rax
   16fd4:	je     16cc2 <btree_iterator_next+0x12>
   16fda:	cmp    %rdx,%rcx
   16fdd:	jg     16cc2 <btree_iterator_next+0x12>
   16fe3:	jmp    16d98 <btree_iterator_next+0xe8>
   16fe8:	nopl   0x0(%rax,%rax,1)
   16ff0:	mov    %eax,%ebp
   16ff2:	jmp    16cc2 <btree_iterator_next+0x12>
   16ff7:	nopw   0x0(%rax,%rax,1)
   17000:	mov    $0x16,%ebp
   17005:	jmp    16e80 <btree_iterator_next+0x1d0>
   1700a:	lea    0x6(%r12,%r8,1),%rax
   1700f:	mov    0x8(%rbx),%rdi
   17013:	mov    %rsp,%rcx
   17016:	mov    %r10,%rsi
   17019:	mov    %rax,%rdx
   1701c:	call   242c0 <blob_parse_descriptor>
   17021:	mov    %eax,%ebp
   17023:	test   %eax,%eax
   17025:	jne    16e80 <btree_iterator_next+0x1d0>
   1702b:	mov    0x80(%rbx),%rax
   17032:	movzwl 0x26(%rax),%esi
   17036:	jmp    16e51 <btree_iterator_next+0x1a1>

Disassembly of section .fini:
