
/home/rob/projects/splinterdb/.cache/projects-20261011/worktrees/branch-prefix/.cache/btree-nonlexical-20261016/combined-read-blob-v1-btree-prefix-bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000011dc0 <btree_iterator_decode_current>:
   11dc0:	push   %r12
   11dc2:	push   %rbp
   11dc3:	mov    %rsi,%rbp
   11dc6:	push   %rbx
   11dc7:	mov    0x80(%rdi),%rax
   11dce:	mov    %rdi,%rbx
   11dd1:	movzwl (%rsi),%edx
   11dd4:	movzwl 0x26(%rax),%r12d
   11dd9:	mov    0xc0(%rdi),%rax
   11de0:	lea    (%rdx,%r12,1),%rsi
   11de4:	test   %rax,%rax
   11de7:	je     11def <btree_iterator_decode_current+0x2f>
   11de9:	cmp    %rsi,0x58(%rax)
   11ded:	jae    11e00 <btree_iterator_decode_current+0x40>
   11def:	mov    %rbx,%rdi
   11df2:	call   110e0 <btree_iterator_prepare_decode.lto_priv.0>
   11df7:	test   %eax,%eax
   11df9:	je     11e60 <btree_iterator_decode_current+0xa0>
   11dfb:	pop    %rbx
   11dfc:	pop    %rbp
   11dfd:	pop    %r12
   11dff:	ret
   11e00:	mov    0x68(%rdi),%rcx
   11e04:	cmp    %rcx,0x48(%rax)
   11e08:	jne    11def <btree_iterator_decode_current+0x2f>
   11e0a:	lea    0x6(%rbp),%rsi
   11e0e:	add    0x50(%rax),%r12
   11e12:	cmp    $0x10,%rdx
   11e16:	ja     11e79 <btree_iterator_decode_current+0xb9>
   11e18:	cmp    $0x7,%rdx
   11e1c:	ja     11e40 <btree_iterator_decode_current+0x80>
   11e1e:	cmp    $0x3,%rdx
   11e22:	jbe    11e88 <btree_iterator_decode_current+0xc8>
   11e24:	mov    0x6(%rbp),%eax
   11e27:	mov    %eax,(%r12)
   11e2b:	mov    0x2(%rbp,%rdx,1),%eax
   11e2f:	mov    %eax,-0x4(%r12,%rdx,1)
   11e34:	xor    %eax,%eax
   11e36:	pop    %rbx
   11e37:	pop    %rbp
   11e38:	pop    %r12
   11e3a:	ret
   11e3b:	nopl   0x0(%rax,%rax,1)
   11e40:	mov    0x6(%rbp),%rax
   11e44:	mov    %rax,(%r12)
   11e48:	mov    -0x2(%rbp,%rdx,1),%rax
   11e4d:	mov    %rax,-0x8(%r12,%rdx,1)
   11e52:	xor    %eax,%eax
   11e54:	jmp    11e36 <btree_iterator_decode_current+0x76>
   11e56:	cs nopw 0x0(%rax,%rax,1)
   11e60:	mov    0xc0(%rbx),%rax
   11e67:	movzwl 0x0(%rbp),%edx
   11e6b:	lea    0x6(%rbp),%rsi
   11e6f:	add    0x50(%rax),%r12
   11e73:	cmp    $0x10,%rdx
   11e77:	jbe    11e18 <btree_iterator_decode_current+0x58>
   11e79:	mov    %r12,%rdi
   11e7c:	call   32e0 <memcpy@plt>
   11e81:	xor    %eax,%eax
   11e83:	jmp    11e36 <btree_iterator_decode_current+0x76>
   11e85:	nopl   (%rax)
   11e88:	cmp    $0x1,%rdx
   11e8c:	jbe    11eb0 <btree_iterator_decode_current+0xf0>
   11e8e:	movzwl 0x6(%rbp),%eax
   11e92:	mov    %ax,(%r12)
   11e97:	movzwl 0x4(%rbp,%rdx,1),%eax
   11e9c:	mov    %ax,-0x2(%r12,%rdx,1)
   11ea2:	xor    %eax,%eax
   11ea4:	jmp    11e36 <btree_iterator_decode_current+0x76>
   11ea6:	cs nopw 0x0(%rax,%rax,1)
   11eb0:	jne    11e34 <btree_iterator_decode_current+0x74>
   11eb2:	movzbl 0x6(%rbp),%eax
   11eb6:	mov    %al,(%r12)
   11eba:	xor    %eax,%eax
   11ebc:	jmp    11e36 <btree_iterator_decode_current+0x76>

Disassembly of section .fini:
