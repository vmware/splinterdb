
/home/rob/projects/splinterdb/.cache/projects-20261011/worktrees/branch-prefix/.cache/btree-nonlexical-20261016/combined-read-v1-btree-prefix-bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000011d00 <btree_iterator_decode_current>:
   11d00:	push   %r12
   11d02:	push   %rbp
   11d03:	mov    %rsi,%rbp
   11d06:	push   %rbx
   11d07:	mov    0x80(%rdi),%rax
   11d0e:	mov    %rdi,%rbx
   11d11:	movzwl (%rsi),%edx
   11d14:	movzwl 0x26(%rax),%r12d
   11d19:	mov    0xc0(%rdi),%rax
   11d20:	lea    (%rdx,%r12,1),%rsi
   11d24:	test   %rax,%rax
   11d27:	je     11d2f <btree_iterator_decode_current+0x2f>
   11d29:	cmp    %rsi,0x58(%rax)
   11d2d:	jae    11d40 <btree_iterator_decode_current+0x40>
   11d2f:	mov    %rbx,%rdi
   11d32:	call   11030 <btree_iterator_prepare_decode.lto_priv.0>
   11d37:	test   %eax,%eax
   11d39:	je     11da0 <btree_iterator_decode_current+0xa0>
   11d3b:	pop    %rbx
   11d3c:	pop    %rbp
   11d3d:	pop    %r12
   11d3f:	ret
   11d40:	mov    0x68(%rdi),%rcx
   11d44:	cmp    %rcx,0x48(%rax)
   11d48:	jne    11d2f <btree_iterator_decode_current+0x2f>
   11d4a:	lea    0x6(%rbp),%rsi
   11d4e:	add    0x50(%rax),%r12
   11d52:	cmp    $0x10,%rdx
   11d56:	ja     11db9 <btree_iterator_decode_current+0xb9>
   11d58:	cmp    $0x7,%rdx
   11d5c:	ja     11d80 <btree_iterator_decode_current+0x80>
   11d5e:	cmp    $0x3,%rdx
   11d62:	jbe    11dc8 <btree_iterator_decode_current+0xc8>
   11d64:	mov    0x6(%rbp),%eax
   11d67:	mov    %eax,(%r12)
   11d6b:	mov    0x2(%rbp,%rdx,1),%eax
   11d6f:	mov    %eax,-0x4(%r12,%rdx,1)
   11d74:	xor    %eax,%eax
   11d76:	pop    %rbx
   11d77:	pop    %rbp
   11d78:	pop    %r12
   11d7a:	ret
   11d7b:	nopl   0x0(%rax,%rax,1)
   11d80:	mov    0x6(%rbp),%rax
   11d84:	mov    %rax,(%r12)
   11d88:	mov    -0x2(%rbp,%rdx,1),%rax
   11d8d:	mov    %rax,-0x8(%r12,%rdx,1)
   11d92:	xor    %eax,%eax
   11d94:	jmp    11d76 <btree_iterator_decode_current+0x76>
   11d96:	cs nopw 0x0(%rax,%rax,1)
   11da0:	mov    0xc0(%rbx),%rax
   11da7:	movzwl 0x0(%rbp),%edx
   11dab:	lea    0x6(%rbp),%rsi
   11daf:	add    0x50(%rax),%r12
   11db3:	cmp    $0x10,%rdx
   11db7:	jbe    11d58 <btree_iterator_decode_current+0x58>
   11db9:	mov    %r12,%rdi
   11dbc:	call   32e0 <memcpy@plt>
   11dc1:	xor    %eax,%eax
   11dc3:	jmp    11d76 <btree_iterator_decode_current+0x76>
   11dc5:	nopl   (%rax)
   11dc8:	cmp    $0x1,%rdx
   11dcc:	jbe    11df0 <btree_iterator_decode_current+0xf0>
   11dce:	movzwl 0x6(%rbp),%eax
   11dd2:	mov    %ax,(%r12)
   11dd7:	movzwl 0x4(%rbp,%rdx,1),%eax
   11ddc:	mov    %ax,-0x2(%r12,%rdx,1)
   11de2:	xor    %eax,%eax
   11de4:	jmp    11d76 <btree_iterator_decode_current+0x76>
   11de6:	cs nopw 0x0(%rax,%rax,1)
   11df0:	jne    11d74 <btree_iterator_decode_current+0x74>
   11df2:	movzbl 0x6(%rbp),%eax
   11df6:	mov    %al,(%r12)
   11dfa:	xor    %eax,%eax
   11dfc:	jmp    11d76 <btree_iterator_decode_current+0x76>

Disassembly of section .fini:
