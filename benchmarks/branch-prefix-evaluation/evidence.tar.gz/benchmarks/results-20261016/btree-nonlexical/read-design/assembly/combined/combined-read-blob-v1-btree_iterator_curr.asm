
/home/rob/projects/splinterdb/.cache/projects-20261011/worktrees/branch-prefix/.cache/btree-nonlexical-20261016/combined-read-blob-v1-btree-prefix-bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000011ed0 <btree_iterator_curr>:
   11ed0:	push   %r12
   11ed2:	mov    %rsi,%r12
   11ed5:	push   %rbp
   11ed6:	mov    %rdx,%rbp
   11ed9:	push   %rbx
   11eda:	mov    %rdi,%rbx
   11edd:	sub    $0x30,%rsp
   11ee1:	cmpq   $0x0,0x70(%rdi)
   11ee6:	je     11efd <btree_iterator_curr+0x2d>
   11ee8:	mov    0x8(%rdi),%rdi
   11eec:	mov    0x68(%rbx),%rdx
   11ef0:	lea    0x70(%rbx),%rsi
   11ef4:	mov    (%rdi),%rax
   11ef7:	call   *0xd0(%rax)
   11efd:	mov    0x80(%rbx),%rax
   11f04:	mov    0x1c(%rbx),%edx
   11f07:	cmpb   $0x0,0x20(%rax)
   11f0b:	jne    11f70 <btree_iterator_curr+0xa0>
   11f0d:	cmp    $0x2,%edx
   11f10:	je     12110 <btree_iterator_curr+0x240>
   11f16:	movzwl 0x90(%rbx),%edx
   11f1d:	movzwl 0x28(%rax,%rdx,2),%ecx
   11f22:	add    %rax,%rcx
   11f25:	movzwl 0x26(%rax),%eax
   11f29:	movzwl (%rcx),%esi
   11f2c:	test   %ax,%ax
   11f2f:	jne    12070 <btree_iterator_curr+0x1a0>
   11f35:	lea    0x6(%rcx),%rdx
   11f39:	mov    %rsi,%rax
   11f3c:	mov    %rdx,%rdi
   11f3f:	movq   $0x2,(%r12)
   11f47:	add    %rsi,%rdx
   11f4a:	movzwl 0x3(%rcx),%esi
   11f4e:	mov    %rax,0x8(%r12)
   11f53:	mov    %rdi,0x10(%r12)
   11f58:	movzbl 0x5(%rcx),%eax
   11f5c:	xor    %ecx,%ecx
   11f5e:	test   $0x4,%al
   11f60:	je     11f66 <btree_iterator_curr+0x96>
   11f62:	mov    0x8(%rbx),%rcx
   11f66:	and    $0x3,%eax
   11f69:	jmp    12052 <btree_iterator_curr+0x182>
   11f6e:	xchg   %ax,%ax
   11f70:	cmp    $0x2,%edx
   11f73:	je     120e0 <btree_iterator_curr+0x210>
   11f79:	movzwl 0x90(%rbx),%edx
   11f80:	movzwl 0x28(%rax,%rdx,2),%edx
   11f85:	add    %rdx,%rax
   11f88:	movzwl 0x14(%rax),%edx
   11f8c:	cmp    $0xffff,%dx
   11f90:	je     120f5 <btree_iterator_curr+0x225>
   11f96:	cmp    $0xfffe,%dx
   11f9a:	je     12120 <btree_iterator_curr+0x250>
   11fa0:	lea    0x17(%rax),%rcx
   11fa4:	movzwl %dx,%esi
   11fa7:	mov    $0x2,%edi
   11fac:	mov    %rcx,0x10(%r12)
   11fb1:	pxor   %xmm3,%xmm3
   11fb5:	movq   (%rax),%xmm2
   11fb9:	mov    %edi,(%r12)
   11fbd:	mov    0x10(%rax),%ecx
   11fc0:	movl   $0x0,0x4(%r12)
   11fc9:	mov    %rsi,0x8(%r12)
   11fce:	movq   0x8(%rax),%xmm0
   11fd3:	punpckldq %xmm3,%xmm0
   11fd7:	testb  $0x1,0x16(%rax)
   11fdb:	je     12090 <btree_iterator_curr+0x1c0>
   11fe1:	add    $0x17,%rax
   11fe5:	movzwl %dx,%esi
   11fe8:	add    %rax,%rsi
   11feb:	cmp    $0xfffd,%dx
   11fef:	cmovbe %rsi,%rax
   11ff3:	movq   (%rax),%xmm1
   11ff7:	mov    0x8(%rax),%eax
   11ffa:	shl    $0x20,%rax
   11ffe:	movq   %xmm1,(%rsp)
   12003:	punpckldq %xmm3,%xmm1
   12007:	or     %rcx,%rax
   1200a:	psllq  $0x20,%xmm1
   1200f:	mov    %rax,0x20(%rsp)
   12014:	por    %xmm0,%xmm1
   12018:	movaps %xmm1,0x10(%rsp)
   1201d:	movdqa %xmm2,%xmm1
   12021:	mov    $0x3e8,%eax
   12026:	xor    %ecx,%ecx
   12028:	mov    $0x20,%esi
   1202d:	movq   0x18(%rsp),%xmm0
   12033:	movhps 0x10(%rsp),%xmm1
   12038:	lea    0x138(%rbx),%rdx
   1203f:	movups %xmm1,0x138(%rbx)
   12046:	movhps 0x20(%rsp),%xmm0
   1204b:	movups %xmm0,0x148(%rbx)
   12052:	mov    %eax,0x0(%rbp)
   12055:	mov    %rcx,0x8(%rbp)
   12059:	mov    %rsi,0x10(%rbp)
   1205d:	mov    %rdx,0x18(%rbp)
   12061:	add    $0x30,%rsp
   12065:	pop    %rbx
   12066:	pop    %rbp
   12067:	pop    %r12
   12069:	ret
   1206a:	nopw   0x0(%rax,%rax,1)
   12070:	mov    0xc0(%rbx),%rdx
   12077:	add    %rsi,%rax
   1207a:	mov    0x50(%rdx),%rdi
   1207e:	lea    0x6(%rcx),%rdx
   12082:	jmp    11f3f <btree_iterator_curr+0x6f>
   12087:	nopw   0x0(%rax,%rax,1)
   12090:	mov    $0x7fffffff,%eax
   12095:	cmp    $0x7fffffff,%rcx
   1209c:	movq   %rax,%xmm1
   120a1:	mov    $0xffffffffffffffff,%rax
   120a8:	punpcklqdq %xmm1,%xmm1
   120ac:	cmove  %rax,%rcx
   120b0:	pcmpeqd %xmm0,%xmm1
   120b4:	mov    %rcx,0x20(%rsp)
   120b9:	pshufd $0xb1,%xmm1,%xmm3
   120be:	pand   %xmm3,%xmm1
   120c2:	movdqa %xmm1,%xmm3
   120c6:	pandn  %xmm0,%xmm3
   120ca:	por    %xmm1,%xmm3
   120ce:	movaps %xmm3,0x10(%rsp)
   120d3:	jmp    1201d <btree_iterator_curr+0x14d>
   120d8:	nopl   0x0(%rax,%rax,1)
   120e0:	mov    0xb8(%rbx),%rax
   120e7:	movzwl 0x14(%rax),%edx
   120eb:	cmp    $0xffff,%dx
   120ef:	jne    11f96 <btree_iterator_curr+0xc6>
   120f5:	xor    %ecx,%ecx
   120f7:	mov    $0xffffffffffffffff,%rsi
   120fe:	mov    $0x1,%edi
   12103:	jmp    11fac <btree_iterator_curr+0xdc>
   12108:	nopl   0x0(%rax,%rax,1)
   12110:	mov    0xb8(%rbx),%rcx
   12117:	jmp    11f25 <btree_iterator_curr+0x55>
   1211c:	nopl   0x0(%rax)
   12120:	xor    %ecx,%ecx
   12122:	mov    $0xffffffffffffffff,%rsi
   12129:	mov    $0x3,%edi
   1212e:	jmp    11fac <btree_iterator_curr+0xdc>

Disassembly of section .fini:
