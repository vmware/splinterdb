
/home/rob/projects/splinterdb/.cache/projects-20261011/worktrees/branch-prefix/.cache/btree-nonlexical-20261016/combined-read-v1-btree-prefix-bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000000f250 <btree_find_tuple_checked.lto_priv.0>:
    f250:	push   %r15
    f252:	mov    %rdi,%r9
    f255:	mov    %rdx,%r15
    f258:	mov    %r8,%r11
    f25b:	push   %r14
    f25d:	push   %r13
    f25f:	push   %r12
    f261:	mov    %rsi,%r12
    f264:	push   %rbp
    f265:	push   %rbx
    f266:	sub    $0x98,%rsp
    f26d:	movzwl 0x24(%rsi),%r14d
    f272:	movzwl 0x26(%rsi),%r13d
    f277:	movl   $0x0,(%rdx)
    f27d:	mov    %rcx,0x38(%rsp)
    f282:	mov    0xd0(%rsp),%eax
    f289:	mov    0xd8(%rsp),%rbp
    f291:	mov    0xe0(%rsp),%rdi
    f299:	mov    %r14,%r10
    f29c:	test   %r13w,%r13w
    f2a0:	jne    f430 <btree_find_tuple_checked.lto_priv.0+0x1e0>
    f2a6:	mov    0x8(%r9),%rdx
    f2aa:	mov    0x30(%rdx),%edx
    f2ad:	test   %edx,%edx
    f2af:	je     f470 <btree_find_tuple_checked.lto_priv.0+0x220>
    f2b5:	mov    %eax,%edx
    f2b7:	and    $0xfffffffd,%edx
    f2ba:	cmp    $0x1,%edx
    f2bd:	je     f470 <btree_find_tuple_checked.lto_priv.0+0x220>
    f2c3:	movzwl %r13w,%eax
    f2c7:	xor    %r8d,%r8d
    f2ca:	mov    %rax,0x28(%rsp)
    f2cf:	test   %r14,%r14
    f2d2:	je     f7cd <btree_find_tuple_checked.lto_priv.0+0x57d>
    f2d8:	mov    %r15,0x48(%rsp)
    f2dd:	mov    %r12,%r15
    f2e0:	mov    %r14,%r12
    f2e3:	mov    %r8,%r14
    f2e6:	mov    %rdi,0x20(%rsp)
    f2eb:	mov    %r10w,0x18(%rsp)
    f2f1:	mov    %r9,0x30(%rsp)
    f2f6:	mov    %r11,0x40(%rsp)
    f2fb:	jmp    f30d <btree_find_tuple_checked.lto_priv.0+0xbd>
    f2fd:	nopl   (%rax)
    f300:	lea    0x1(%rbx),%r14
    f304:	cmp    %r12,%r14
    f307:	jge    f3f4 <btree_find_tuple_checked.lto_priv.0+0x1a4>
    f30d:	lea    (%r14,%r12,1),%rax
    f311:	mov    %rax,%rbx
    f314:	shr    $0x3f,%rbx
    f318:	add    %rax,%rbx
    f31b:	sar    $1,%rbx
    f31e:	cmp    0x18(%rsp),%bx
    f323:	jae    f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f329:	movzwl %bx,%eax
    f32c:	movzwl 0x28(%r15,%rax,2),%eax
    f332:	cmp    0x22(%r15),%ax
    f337:	jb     f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f33d:	mov    0x30(%rsp),%rsi
    f342:	mov    0x28(%rsp),%r9
    f347:	lea    0x6(%rax),%rcx
    f34b:	mov    0x10(%rsi),%rsi
    f34f:	mov    %rsi,%rdx
    f352:	sub    %r9,%rdx
    f355:	cmp    %rcx,%rdx
    f358:	jb     f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f35e:	lea    (%r15,%rax,1),%rcx
    f362:	cmpb   $0x0,0x2(%rcx)
    f366:	jne    f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f36c:	movzwl (%rcx),%edi
    f36f:	cmp    $0xfffd,%di
    f373:	ja     f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f379:	sub    $0x6,%rdx
    f37d:	movzwl %di,%r13d
    f381:	mov    %di,0x10(%rsp)
    f386:	sub    %rax,%rdx
    f389:	cmp    %r13,%rdx
    f38c:	jb     f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f392:	lea    0x0(%r13,%r9,1),%rax
    f397:	shr    $0x3,%rsi
    f39b:	cmp    %rax,%rsi
    f39e:	jb     f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f3a4:	cmp    %r13,%rbp
    f3a7:	mov    %r13,%rdx
    f3aa:	mov    0x20(%rsp),%rdi
    f3af:	lea    0x6(%rcx),%rsi
    f3b3:	cmovbe %rbp,%rdx
    f3b7:	mov    %rcx,0x8(%rsp)
    f3bc:	call   3240 <memcmp@plt>
    f3c1:	test   %eax,%eax
    f3c3:	jne    f3e0 <btree_find_tuple_checked.lto_priv.0+0x190>
    f3c5:	cmp    %r13,%rbp
    f3c8:	jb     f3e8 <btree_find_tuple_checked.lto_priv.0+0x198>
    f3ca:	movzwl 0x10(%rsp),%r13d
    f3d0:	mov    %ebp,%eax
    f3d2:	mov    0x8(%rsp),%rcx
    f3d7:	sub    %r13d,%eax
    f3da:	je     f738 <btree_find_tuple_checked.lto_priv.0+0x4e8>
    f3e0:	test   %eax,%eax
    f3e2:	jg     f300 <btree_find_tuple_checked.lto_priv.0+0xb0>
    f3e8:	mov    %rbx,%r12
    f3eb:	cmp    %r12,%r14
    f3ee:	jl     f30d <btree_find_tuple_checked.lto_priv.0+0xbd>
    f3f4:	mov    %r14,%r8
    f3f7:	mov    0x40(%rsp),%r11
    f3fc:	sub    $0x1,%r8
    f400:	mov    0x38(%rsp),%rax
    f405:	mov    %r8,(%rax)
    f408:	test   %r11,%r11
    f40b:	je     f414 <btree_find_tuple_checked.lto_priv.0+0x1c4>
    f40d:	movq   $0x0,(%r11)
    f414:	xor    %eax,%eax
    f416:	add    $0x98,%rsp
    f41d:	pop    %rbx
    f41e:	pop    %rbp
    f41f:	pop    %r12
    f421:	pop    %r13
    f423:	pop    %r14
    f425:	pop    %r15
    f427:	ret
    f428:	nopl   0x0(%rax,%rax,1)
    f430:	cmp    $0x1,%eax
    f433:	je     f7aa <btree_find_tuple_checked.lto_priv.0+0x55a>
    f439:	cmp    $0x3,%eax
    f43c:	je     f76e <btree_find_tuple_checked.lto_priv.0+0x51e>
    f442:	movq   $0xffffffffffffffff,0x10(%rsp)
    f44b:	cmp    $0x2,%eax
    f44e:	je     f610 <btree_find_tuple_checked.lto_priv.0+0x3c0>
    f454:	mov    0x38(%rsp),%rax
    f459:	mov    0x10(%rsp),%rcx
    f45e:	mov    %rcx,(%rax)
    f461:	test   %r11,%r11
    f464:	je     f414 <btree_find_tuple_checked.lto_priv.0+0x1c4>
    f466:	movq   $0x0,(%r11)
    f46d:	jmp    f414 <btree_find_tuple_checked.lto_priv.0+0x1c4>
    f46f:	nop
    f470:	test   %r14,%r14
    f473:	je     f7d9 <btree_find_tuple_checked.lto_priv.0+0x589>
    f479:	cmp    $0x2,%eax
    f47c:	jne    f670 <btree_find_tuple_checked.lto_priv.0+0x420>
    f482:	mov    0xd4(%rsp),%eax
    f489:	xor    %ebx,%ebx
    f48b:	mov    %rbp,0x10(%rsp)
    f490:	mov    %r9,%rbp
    f493:	mov    %r15,0x28(%rsp)
    f498:	mov    %r14,%r15
    f49b:	mov    %rbx,%r14
    f49e:	mov    %r12,%rbx
    f4a1:	mov    %eax,0x8(%rsp)
    f4a5:	mov    %rdi,0x18(%rsp)
    f4aa:	mov    %r11,0x20(%rsp)
    f4af:	jmp    f4ca <btree_find_tuple_checked.lto_priv.0+0x27a>
    f4b1:	nopl   0x0(%rax)
    f4b8:	lea    0x1(%r13),%r14
    f4bc:	cmp    %r15,%r14
    f4bf:	jge    f7c0 <btree_find_tuple_checked.lto_priv.0+0x570>
    f4c5:	movzwl 0x24(%rbx),%r10d
    f4ca:	lea    (%r14,%r15,1),%rax
    f4ce:	mov    %rax,%r13
    f4d1:	shr    $0x3f,%r13
    f4d5:	add    %rax,%r13
    f4d8:	sar    $1,%r13
    f4db:	cmp    %r10w,%r13w
    f4df:	jae    f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f4e5:	movzwl %r13w,%eax
    f4e9:	movzwl 0x28(%rbx,%rax,2),%eax
    f4ee:	cmp    0x22(%rbx),%ax
    f4f2:	jb     f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f4f8:	mov    0x10(%rbp),%r11
    f4fc:	movzwl 0x26(%rbx),%r10d
    f501:	lea    0x6(%rax),%rdx
    f505:	mov    %r11,%rdi
    f508:	sub    %r10,%rdi
    f50b:	cmp    %rdx,%rdi
    f50e:	jb     f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f514:	lea    (%rbx,%rax,1),%r12
    f518:	cmpb   $0x0,0x2(%r12)
    f51e:	jne    f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f524:	movzwl (%r12),%edx
    f529:	cmp    $0xfffd,%dx
    f52d:	ja     f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f533:	sub    $0x6,%rdi
    f537:	sub    %rax,%rdi
    f53a:	cmp    %rdx,%rdi
    f53d:	jb     f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f543:	add    %rdx,%r10
    f546:	shr    $0x3,%r11
    f54a:	cmp    %r10,%r11
    f54d:	jb     f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f553:	mov    0x10(%rsp),%rsi
    f558:	mov    0x18(%rsp),%rcx
    f55d:	mov    %rdx,0x70(%rsp)
    f562:	lea    0x6(%r12),%rdx
    f567:	mov    %rdx,0x78(%rsp)
    f56c:	sub    $0x30,%rsp
    f570:	mov    0x8(%rbp),%rax
    f574:	mov    %rsi,0x80(%rsp)
    f57c:	mov    0x38(%rsp),%esi
    f580:	mov    %rcx,0x88(%rsp)
    f588:	mov    %rax,%rdi
    f58b:	mov    %esi,0x90(%rsp)
    f592:	movl   $0x0,0xb0(%rsp)
    f59d:	movdqa 0xa0(%rsp),%xmm0
    f5a6:	mov    0xb0(%rsp),%rdx
    f5ae:	movups %xmm0,0x18(%rsp)
    f5b3:	movdqa 0x80(%rsp),%xmm0
    f5bc:	mov    %rdx,0x28(%rsp)
    f5c1:	mov    0x90(%rsp),%rdx
    f5c9:	movups %xmm0,(%rsp)
    f5cd:	mov    %rdx,0x10(%rsp)
    f5d2:	call   *(%rax)
    f5d4:	add    $0x30,%rsp
    f5d8:	test   %eax,%eax
    f5da:	je     f780 <btree_find_tuple_checked.lto_priv.0+0x530>
    f5e0:	jg     f4b8 <btree_find_tuple_checked.lto_priv.0+0x268>
    f5e6:	cmp    %r14,%r13
    f5e9:	jle    f7c0 <btree_find_tuple_checked.lto_priv.0+0x570>
    f5ef:	mov    %r13,%r15
    f5f2:	jmp    f4c5 <btree_find_tuple_checked.lto_priv.0+0x275>
    f5f7:	nopw   0x0(%rax,%rax,1)
    f600:	mov    $0x16,%eax
    f605:	jmp    f416 <btree_find_tuple_checked.lto_priv.0+0x1c6>
    f60a:	nopw   0x0(%rax,%rax,1)
    f610:	movzwl %r13w,%ebx
    f614:	mov    %rbp,%rdx
    f617:	mov    %r8,0x8(%rsp)
    f61c:	cmp    %rbp,%rbx
    f61f:	mov    %r14d,0x28(%rsp)
    f624:	cmovbe %rbx,%rdx
    f628:	sub    %rbx,%rsi
    f62b:	add    0x10(%r9),%rsi
    f62f:	mov    %r9,0x20(%rsp)
    f634:	mov    %rdi,0x18(%rsp)
    f639:	call   3240 <memcmp@plt>
    f63e:	mov    0x8(%rsp),%r11
    f643:	test   %eax,%eax
    f645:	jne    f768 <btree_find_tuple_checked.lto_priv.0+0x518>
    f64b:	cmp    %rbx,%rbp
    f64e:	mov    0x18(%rsp),%rdi
    f653:	mov    0x20(%rsp),%r9
    f658:	mov    0x28(%rsp),%r10d
    f65d:	jb     f454 <btree_find_tuple_checked.lto_priv.0+0x204>
    f663:	add    %rbx,%rdi
    f666:	sub    %rbx,%rbp
    f669:	jmp    f2c3 <btree_find_tuple_checked.lto_priv.0+0x73>
    f66e:	xchg   %ax,%ax
    f670:	lea    -0x2(%rax),%esi
    f673:	xor    %ebx,%ebx
    f675:	data16 cs nopw 0x0(%rax,%rax,1)
    f680:	lea    (%r14,%rbx,1),%rdx
    f684:	mov    %rdx,%rax
    f687:	shr    $0x3f,%rax
    f68b:	add    %rdx,%rax
    f68e:	sar    $1,%rax
    f691:	cmp    %r10w,%ax
    f695:	jae    f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f69b:	movzwl %ax,%edx
    f69e:	movzwl 0x28(%r12,%rdx,2),%edx
    f6a4:	cmp    0x22(%r12),%dx
    f6aa:	jb     f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f6b0:	mov    0x10(%r9),%rdi
    f6b4:	lea    0x6(%rdx),%rcx
    f6b8:	cmp    %rcx,%rdi
    f6bb:	jb     f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f6c1:	lea    (%r12,%rdx,1),%rcx
    f6c5:	cmpb   $0x0,0x2(%rcx)
    f6c9:	jne    f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f6cf:	movzwl (%rcx),%ecx
    f6d2:	cmp    $0xfffd,%cx
    f6d6:	ja     f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f6dc:	lea    -0x6(%rdi),%r8
    f6e0:	sub    %rdx,%r8
    f6e3:	cmp    %rcx,%r8
    f6e6:	jb     f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f6ec:	shr    $0x3,%rdi
    f6f0:	cmp    %rcx,%rdi
    f6f3:	jb     f600 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f6f9:	test   %esi,%esi
    f6fb:	jle    f728 <btree_find_tuple_checked.lto_priv.0+0x4d8>
    f6fd:	lea    0x1(%rax),%rbx
    f701:	cmp    %r14,%rbx
    f704:	jl     f680 <btree_find_tuple_checked.lto_priv.0+0x430>
    f70a:	lea    -0x1(%rbx),%rdx
    f70e:	mov    0x38(%rsp),%rax
    f713:	mov    %rdx,(%rax)
    f716:	test   %r11,%r11
    f719:	jne    f40d <btree_find_tuple_checked.lto_priv.0+0x1bd>
    f71f:	jmp    f414 <btree_find_tuple_checked.lto_priv.0+0x1c4>
    f724:	nopl   0x0(%rax)
    f728:	cmp    %rbx,%rax
    f72b:	jle    f70a <btree_find_tuple_checked.lto_priv.0+0x4ba>
    f72d:	mov    %rax,%r14
    f730:	jmp    f680 <btree_find_tuple_checked.lto_priv.0+0x430>
    f735:	nopl   (%rax)
    f738:	mov    0x48(%rsp),%r15
    f73d:	mov    0x38(%rsp),%rsi
    f742:	mov    0x40(%rsp),%r11
    f747:	movl   $0x1,(%r15)
    f74e:	mov    %rbx,(%rsi)
    f751:	test   %r11,%r11
    f754:	je     f416 <btree_find_tuple_checked.lto_priv.0+0x1c6>
    f75a:	mov    %rcx,(%r11)
    f75d:	jmp    f416 <btree_find_tuple_checked.lto_priv.0+0x1c6>
    f762:	nopw   0x0(%rax,%rax,1)
    f768:	js     f454 <btree_find_tuple_checked.lto_priv.0+0x204>
    f76e:	lea    -0x1(%r14),%rax
    f772:	mov    %rax,0x10(%rsp)
    f777:	jmp    f454 <btree_find_tuple_checked.lto_priv.0+0x204>
    f77c:	nopl   0x0(%rax)
    f780:	mov    0x28(%rsp),%r15
    f785:	mov    0x38(%rsp),%rcx
    f78a:	mov    0x20(%rsp),%r11
    f78f:	movl   $0x1,(%r15)
    f796:	mov    %r13,(%rcx)
    f799:	test   %r11,%r11
    f79c:	je     f416 <btree_find_tuple_checked.lto_priv.0+0x1c6>
    f7a2:	mov    %r12,(%r11)
    f7a5:	jmp    f416 <btree_find_tuple_checked.lto_priv.0+0x1c6>
    f7aa:	movq   $0xffffffffffffffff,0x10(%rsp)
    f7b3:	jmp    f454 <btree_find_tuple_checked.lto_priv.0+0x204>
    f7b8:	nopl   0x0(%rax,%rax,1)
    f7c0:	mov    0x20(%rsp),%r11
    f7c5:	mov    %r14,%rbx
    f7c8:	jmp    f70a <btree_find_tuple_checked.lto_priv.0+0x4ba>
    f7cd:	mov    $0xffffffffffffffff,%r8
    f7d4:	jmp    f400 <btree_find_tuple_checked.lto_priv.0+0x1b0>
    f7d9:	mov    $0xffffffffffffffff,%rdx
    f7e0:	jmp    f70e <btree_find_tuple_checked.lto_priv.0+0x4be>

Disassembly of section .fini:
