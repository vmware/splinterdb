
/home/rob/projects/splinterdb/.cache/projects-20261011/worktrees/branch-prefix/.cache/btree-nonlexical-20261016/combined-read-v1-btree-prefix-bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000016620 <btree_iterator_next_leaf>:
   16620:	push   %r15
   16622:	push   %r14
   16624:	push   %r13
   16626:	push   %r12
   16628:	push   %rbp
   16629:	push   %rbx
   1662a:	mov    %rdi,%rbx
   1662d:	sub    $0xa8,%rsp
   16634:	mov    0x1c(%rdi),%ecx
   16637:	mov    0x68(%rdi),%r12
   1663b:	cmp    $0x2,%ecx
   1663e:	jne    168a0 <btree_iterator_next_leaf+0x280>
   16644:	mov    0x80(%rdi),%rsi
   1664b:	mov    0x18(%rsi),%rbp
   1664f:	cmp    $0xffffffffffffffff,%rbp
   16653:	je     16849 <btree_iterator_next_leaf+0x229>
   16659:	add    $0x1,%rbp
   1665d:	lea    0x68(%rdi),%r14
   16661:	xor    %r13d,%r13d
   16664:	testb  $0x2,0x21(%rsi)
   16668:	jne    16687 <btree_iterator_next_leaf+0x67>
   1666a:	mov    0x10(%rdi),%rdi
   1666e:	xor    %edx,%edx
   16670:	mov    0x10(%rdi),%r13
   16674:	add    %r12,%r13
   16677:	mov    %r13,%rax
   1667a:	divq   0x18(%rdi)
   1667e:	test   %rdx,%rdx
   16681:	jne    16687 <btree_iterator_next_leaf+0x67>
   16683:	mov    0x8(%rsi),%r13
   16687:	cmpq   $0x0,0x70(%rbx)
   1668c:	je     16808 <btree_iterator_next_leaf+0x1e8>
   16692:	mov    0x8(%rbx),%rdi
   16696:	lea    0x70(%rbx),%rsi
   1669a:	mov    (%rdi),%rax
   1669d:	call   *0x30(%rax)
   166a0:	pxor   %xmm0,%xmm0
   166a4:	mov    0x1c(%rbx),%ecx
   166a7:	movq   $0x0,0x80(%rbx)
   166b2:	movups %xmm0,0x70(%rbx)
   166b6:	mov    0x10(%rbx),%rsi
   166ba:	mov    0x8(%rbx),%rdi
   166be:	mov    %r13,0x68(%rbx)
   166c2:	mov    %r14,%rdx
   166c5:	call   f7f0 <btree_node_get_checked.lto_priv.0>
   166ca:	test   %eax,%eax
   166cc:	jne    168c0 <btree_iterator_next_leaf+0x2a0>
   166d2:	cmpl   $0x2,0x1c(%rbx)
   166d6:	je     168d0 <btree_iterator_next_leaf+0x2b0>
   166dc:	mov    0x20(%rbx),%ecx
   166df:	test   %ecx,%ecx
   166e1:	je     16870 <btree_iterator_next_leaf+0x250>
   166e7:	cmpq   $0x0,0x70(%rbx)
   166ec:	je     16870 <btree_iterator_next_leaf+0x250>
   166f2:	mov    0x10(%rbx),%rax
   166f6:	mov    0x88(%rbx),%rdi
   166fd:	mov    0x80(%rbx),%rsi
   16704:	mov    0x10(%rax),%rdx
   16708:	call   32e0 <memcpy@plt>
   1670d:	mov    0x8(%rbx),%rdi
   16711:	lea    0x70(%rbx),%rsi
   16715:	mov    (%rdi),%rax
   16718:	call   *0x30(%rax)
   1671b:	mov    0x68(%rbx),%rdi
   1671f:	mov    0x1c(%rbx),%ecx
   16722:	pxor   %xmm0,%xmm0
   16726:	mov    0x88(%rbx),%rsi
   1672d:	movups %xmm0,0x70(%rbx)
   16731:	mov    %rdi,0xa0(%rbx)
   16738:	mov    %rsi,0x80(%rbx)
   1673f:	movzwl 0x24(%rsi),%r13d
   16744:	movl   $0x1,0xb0(%rbx)
   1674e:	cmp    $0x3,%ecx
   16751:	je     16795 <btree_iterator_next_leaf+0x175>
   16753:	cmp    $0x2,%ecx
   16756:	jne    168b9 <btree_iterator_next_leaf+0x299>
   1675c:	cmpl   $0x3,0x48(%rbx)
   16760:	sete   %al
   16763:	test   %r13,%r13
   16766:	sete   %dl
   16769:	or     %edx,%eax
   1676b:	mov    %eax,%r8d
   1676e:	testb  $0x2,0x21(%rsi)
   16772:	jne    16958 <btree_iterator_next_leaf+0x338>
   16778:	mov    0x10(%rbx),%r9
   1677c:	xor    %edx,%edx
   1677e:	mov    0x10(%r9),%r14
   16782:	add    %rdi,%r14
   16785:	mov    %r14,%rax
   16788:	divq   0x18(%r9)
   1678c:	test   %rdx,%rdx
   1678f:	jne    16a80 <btree_iterator_next_leaf+0x460>
   16795:	cmpl   $0x3,0x48(%rbx)
   16799:	mov    0x8(%rsi),%r14
   1679d:	je     16820 <btree_iterator_next_leaf+0x200>
   167a3:	test   %r13,%r13
   167a6:	je     16820 <btree_iterator_next_leaf+0x200>
   167a8:	movdqu 0x48(%rbx),%xmm0
   167ad:	lea    0x38(%rsp),%rcx
   167b2:	sub    $0x20,%rsp
   167b6:	lea    -0x1(%r13),%rdx
   167ba:	mov    %rbx,%rdi
   167bd:	movups %xmm0,(%rsp)
   167c1:	mov    0x58(%rbx),%rax
   167c5:	mov    %rax,0x10(%rsp)
   167ca:	call   111a0 <btree_iterator_compare_node_key.lto_priv.0>
   167cf:	add    $0x20,%rsp
   167d3:	test   %eax,%eax
   167d5:	jne    168c0 <btree_iterator_next_leaf+0x2a0>
   167db:	mov    0x38(%rsp),%eax
   167df:	test   %eax,%eax
   167e1:	jle    16970 <btree_iterator_next_leaf+0x350>
   167e7:	xor    %eax,%eax
   167e9:	test   %r14,%r14
   167ec:	jne    167f2 <btree_iterator_next_leaf+0x1d2>
   167ee:	mov    0x68(%rbx),%rax
   167f2:	mov    %rax,0xa0(%rbx)
   167f9:	mov    0x1c(%rbx),%ecx
   167fc:	mov    %r13,0xa8(%rbx)
   16803:	jmp    16837 <btree_iterator_next_leaf+0x217>
   16805:	nopl   (%rax)
   16808:	movq   $0x0,0x80(%rbx)
   16813:	jmp    166b6 <btree_iterator_next_leaf+0x96>
   16818:	nopl   0x0(%rax,%rax,1)
   16820:	xor    %eax,%eax
   16822:	test   %r14,%r14
   16825:	mov    %r13,0xa8(%rbx)
   1682c:	cmovne %rax,%rdi
   16830:	mov    %rdi,0xa0(%rbx)
   16837:	cmp    $0x2,%ecx
   1683a:	jne    16870 <btree_iterator_next_leaf+0x250>
   1683c:	mov    0x80(%rbx),%rax
   16843:	cmp    %rbp,0x18(%rax)
   16847:	je     16870 <btree_iterator_next_leaf+0x250>
   16849:	movl   $0x16,0xb4(%rbx)
   16853:	mov    $0x16,%eax
   16858:	add    $0xa8,%rsp
   1685f:	pop    %rbx
   16860:	pop    %rbp
   16861:	pop    %r12
   16863:	pop    %r13
   16865:	pop    %r14
   16867:	pop    %r15
   16869:	ret
   1686a:	nopw   0x0(%rax,%rax,1)
   16870:	movdqa 0x1aa28(%rip),%xmm0        # 312a0 <__func__.13+0x68>
   16878:	mov    %rbx,%rdi
   1687b:	movups %xmm0,0x90(%rbx)
   16882:	call   11620 <btree_iterator_prepare_end_idx.lto_priv.0>
   16887:	test   %eax,%eax
   16889:	jne    16858 <btree_iterator_next_leaf+0x238>
   1688b:	mov    $0x1,%edx
   16890:	mov    %r12,%rsi
   16893:	mov    %rbx,%rdi
   16896:	call   148d0 <btree_iterator_prefetch_on_advance>
   1689b:	xor    %eax,%eax
   1689d:	jmp    16858 <btree_iterator_next_leaf+0x238>
   1689f:	nop
   168a0:	mov    0x80(%rdi),%rax
   168a7:	test   %rax,%rax
   168aa:	je     16c99 <btree_iterator_next_leaf+0x679>
   168b0:	cmp    $0x3,%ecx
   168b3:	je     16938 <btree_iterator_next_leaf+0x318>
   168b9:	call   15760 <btree_hdr_next_addr.part.0.lto_priv.0>
   168be:	xchg   %ax,%ax
   168c0:	mov    %eax,0xb4(%rbx)
   168c6:	jmp    16858 <btree_iterator_next_leaf+0x238>
   168c8:	nopl   0x0(%rax,%rax,1)
   168d0:	mov    0x80(%rbx),%rax
   168d7:	movzbl 0x20(%rax),%eax
   168db:	cmp    %eax,0x18(%rbx)
   168de:	jne    16900 <btree_iterator_next_leaf+0x2e0>
   168e0:	mov    0x20(%rbx),%edx
   168e3:	test   %edx,%edx
   168e5:	je     1683c <btree_iterator_next_leaf+0x21c>
   168eb:	cmpq   $0x0,0x70(%rbx)
   168f0:	jne    166f2 <btree_iterator_next_leaf+0xd2>
   168f6:	jmp    1683c <btree_iterator_next_leaf+0x21c>
   168fb:	nopl   0x0(%rax,%rax,1)
   16900:	mov    0x8(%rbx),%rdi
   16904:	lea    0x70(%rbx),%rsi
   16908:	mov    (%rdi),%rax
   1690b:	call   *0x30(%rax)
   1690e:	pxor   %xmm0,%xmm0
   16912:	mov    $0x16,%eax
   16917:	movq   $0x0,0x80(%rbx)
   16922:	movl   $0x16,0xb4(%rbx)
   1692c:	movups %xmm0,0x70(%rbx)
   16930:	jmp    16858 <btree_iterator_next_leaf+0x238>
   16935:	nopl   (%rax)
   16938:	xor    %ebp,%ebp
   1693a:	cmpq   $0x0,0x70(%rbx)
   1693f:	mov    0x8(%rax),%r13
   16943:	lea    0x68(%rdi),%r14
   16947:	jne    16692 <btree_iterator_next_leaf+0x72>
   1694d:	jmp    16808 <btree_iterator_next_leaf+0x1e8>
   16952:	nopw   0x0(%rax,%rax,1)
   16958:	test   %al,%al
   1695a:	je     16a60 <btree_iterator_next_leaf+0x440>
   16960:	mov    %r13,0xa8(%rbx)
   16967:	jmp    1683c <btree_iterator_next_leaf+0x21c>
   1696c:	nopl   0x0(%rax)
   16970:	mov    0x40(%rbx),%eax
   16973:	mov    %eax,0x14(%rsp)
   16977:	cmp    $0x3,%eax
   1697a:	ja     16ca5 <btree_iterator_next_leaf+0x685>
   16980:	movdqu 0x48(%rbx),%xmm0
   16985:	mov    0x58(%rbx),%r13
   16989:	mov    0x18(%rbx),%eax
   1698c:	mov    0x80(%rbx),%r14
   16993:	mov    %r13,0x50(%rsp)
   16998:	movaps %xmm0,0x40(%rsp)
   1699d:	test   %eax,%eax
   1699f:	jne    16aa0 <btree_iterator_next_leaf+0x480>
   169a5:	mov    0x10(%rbx),%rax
   169a9:	cmpl   $0x2,0x1c(%rbx)
   169ad:	mov    %rax,(%rsp)
   169b1:	je     16add <btree_iterator_next_leaf+0x4bd>
   169b7:	mov    0x44(%rsp),%edx
   169bb:	mov    0x40(%rsp),%eax
   169bf:	movl   $0x0,0x3c(%rsp)
   169c7:	movzwl 0x24(%r14),%r8d
   169cc:	mov    %edx,0x10(%rsp)
   169d0:	mov    0x48(%rsp),%rdx
   169d5:	mov    %rdx,0x8(%rsp)
   169da:	test   %r8,%r8
   169dd:	je     16c9e <btree_iterator_next_leaf+0x67e>
   169e3:	cmp    $0x2,%eax
   169e6:	je     16b2f <btree_iterator_next_leaf+0x50f>
   169ec:	mov    %r8,%rdx
   169ef:	sar    $1,%rdx
   169f2:	cmp    $0x2,%eax
   169f5:	jg     16a10 <btree_iterator_next_leaf+0x3f0>
   169f7:	jmp    16a73 <btree_iterator_next_leaf+0x453>
   169f9:	nopl   0x0(%rax)
   16a00:	add    %r8,%rdx
   16a03:	mov    %rdx,%rax
   16a06:	shr    $0x3f,%rax
   16a0a:	add    %rax,%rdx
   16a0d:	sar    $1,%rdx
   16a10:	add    $0x1,%rdx
   16a14:	cmp    %rdx,%r8
   16a17:	jg     16a00 <btree_iterator_next_leaf+0x3e0>
   16a19:	lea    -0x1(%rdx),%r15
   16a1d:	mov    0x14(%rsp),%edx
   16a21:	mov    $0x3,%eax
   16a26:	sub    %edx,%eax
   16a28:	cmp    $0x2,%eax
   16a2b:	je     16c54 <btree_iterator_next_leaf+0x634>
   16a31:	cmp    $0x3,%eax
   16a34:	je     16c5d <btree_iterator_next_leaf+0x63d>
   16a3a:	test   %eax,%eax
   16a3c:	jne    16a50 <btree_iterator_next_leaf+0x430>
   16a3e:	cmpl   $0x1,0x3c(%rsp)
   16a43:	adc    $0xffffffffffffffff,%r15
   16a47:	nopw   0x0(%rax,%rax,1)
   16a50:	mov    %r15,0xa8(%rbx)
   16a57:	mov    0x1c(%rbx),%ecx
   16a5a:	jmp    16837 <btree_iterator_next_leaf+0x217>
   16a5f:	nop
   16a60:	xor    %r14d,%r14d
   16a63:	jmp    167a8 <btree_iterator_next_leaf+0x188>
   16a68:	nopl   0x0(%rax,%rax,1)
   16a70:	sar    $1,%rdx
   16a73:	test   %rdx,%rdx
   16a76:	jne    16a70 <btree_iterator_next_leaf+0x450>
   16a78:	jmp    16a19 <btree_iterator_next_leaf+0x3f9>
   16a7a:	nopw   0x0(%rax,%rax,1)
   16a80:	test   %r8b,%r8b
   16a83:	je     167a8 <btree_iterator_next_leaf+0x188>
   16a89:	movq   $0x0,0xa0(%rbx)
   16a94:	jmp    16960 <btree_iterator_next_leaf+0x340>
   16a99:	nopl   0x0(%rax)
   16aa0:	movzbl 0x20(%r14),%edx
   16aa5:	cmp    %eax,%edx
   16aa7:	jb     16b20 <btree_iterator_next_leaf+0x500>
   16aa9:	cmpl   $0x2,0x1c(%rbx)
   16aad:	mov    0x10(%rbx),%rdi
   16ab1:	je     16c6b <btree_iterator_next_leaf+0x64b>
   16ab7:	lea    0x3c(%rsp),%rdx
   16abc:	mov    %r14,%rsi
   16abf:	sub    $0x20,%rsp
   16ac3:	mov    %r13,0x10(%rsp)
   16ac8:	movups %xmm0,(%rsp)
   16acc:	call   9ea0 <btree_find_pivot>
   16ad1:	add    $0x20,%rsp
   16ad5:	mov    %rax,%r15
   16ad8:	jmp    16a1d <btree_iterator_next_leaf+0x3fd>
   16add:	lea    0x80(%rsp),%rcx
   16ae5:	lea    0x3c(%rsp),%rdx
   16aea:	sub    $0x20,%rsp
   16aee:	xor    %r8d,%r8d
   16af1:	mov    0x20(%rsp),%rdi
   16af6:	mov    %r14,%rsi
   16af9:	mov    %r13,0x10(%rsp)
   16afe:	movups %xmm0,(%rsp)
   16b02:	call   f250 <btree_find_tuple_checked.lto_priv.0>
   16b07:	add    $0x20,%rsp
   16b0b:	test   %eax,%eax
   16b0d:	jne    168c0 <btree_iterator_next_leaf+0x2a0>
   16b13:	mov    0x80(%rsp),%r15
   16b1b:	jmp    16a1d <btree_iterator_next_leaf+0x3fd>
   16b20:	movl   $0xffffffff,0x18(%rbx)
   16b27:	xor    %r15d,%r15d
   16b2a:	jmp    16a50 <btree_iterator_next_leaf+0x430>
   16b2f:	mov    %r12,0x18(%rsp)
   16b34:	xor    %edx,%edx
   16b36:	mov    %rbp,0x20(%rsp)
   16b3b:	mov    %r13,%rbp
   16b3e:	mov    %rdx,%r13
   16b41:	mov    %rbx,0x28(%rsp)
   16b46:	mov    %r8,%rbx
   16b49:	nopl   0x0(%rax)
   16b50:	lea    (%rbx,%r13,1),%rax
   16b54:	mov    (%rsp),%rdx
   16b58:	mov    %rbp,0x68(%rsp)
   16b5d:	sub    $0x30,%rsp
   16b61:	mov    %rax,%r15
   16b64:	shr    $0x3f,%r15
   16b68:	mov    0x8(%rdx),%rcx
   16b6c:	mov    0x38(%rsp),%rdx
   16b71:	movl   $0x0,0xc0(%rsp)
   16b7c:	add    %rax,%r15
   16b7f:	sar    $1,%r15
   16b82:	mov    %rdx,0x90(%rsp)
   16b8a:	mov    0x40(%rsp),%edx
   16b8e:	movzwl %r15w,%eax
   16b92:	movzwl 0x28(%r14,%rax,2),%eax
   16b98:	mov    %edx,0xa0(%rsp)
   16b9f:	add    %r14,%rax
   16ba2:	movzwl (%rax),%edi
   16ba5:	add    $0x6,%rax
   16ba9:	mov    %rax,0xb8(%rsp)
   16bb1:	mov    %rdi,0xb0(%rsp)
   16bb9:	mov    0xc0(%rsp),%rax
   16bc1:	mov    %rcx,%rdi
   16bc4:	movdqa 0xb0(%rsp),%xmm0
   16bcd:	mov    %rax,0x28(%rsp)
   16bd2:	mov    0xa0(%rsp),%rax
   16bda:	movups %xmm0,0x18(%rsp)
   16bdf:	movdqa 0x90(%rsp),%xmm0
   16be8:	mov    %rax,0x10(%rsp)
   16bed:	movups %xmm0,(%rsp)
   16bf1:	call   *(%rcx)
   16bf3:	add    $0x30,%rsp
   16bf7:	test   %eax,%eax
   16bf9:	je     16c38 <btree_iterator_next_leaf+0x618>
   16bfb:	jle    16c28 <btree_iterator_next_leaf+0x608>
   16bfd:	lea    0x1(%r15),%r13
   16c01:	cmp    %rbx,%r13
   16c04:	jl     16b50 <btree_iterator_next_leaf+0x530>
   16c0a:	mov    0x18(%rsp),%r12
   16c0f:	mov    0x20(%rsp),%rbp
   16c14:	mov    %r13,%rdx
   16c17:	mov    0x28(%rsp),%rbx
   16c1c:	jmp    16a19 <btree_iterator_next_leaf+0x3f9>
   16c21:	nopl   0x0(%rax)
   16c28:	cmp    %r13,%r15
   16c2b:	jle    16c0a <btree_iterator_next_leaf+0x5ea>
   16c2d:	mov    %r15,%rbx
   16c30:	jmp    16b50 <btree_iterator_next_leaf+0x530>
   16c35:	nopl   (%rax)
   16c38:	movl   $0x1,0x3c(%rsp)
   16c40:	mov    0x20(%rsp),%rbp
   16c45:	mov    0x18(%rsp),%r12
   16c4a:	mov    0x28(%rsp),%rbx
   16c4f:	jmp    16a1d <btree_iterator_next_leaf+0x3fd>
   16c54:	add    $0x1,%r15
   16c58:	jmp    16a50 <btree_iterator_next_leaf+0x430>
   16c5d:	cmpl   $0x1,0x3c(%rsp)
   16c62:	adc    $0x0,%r15
   16c66:	jmp    16a50 <btree_iterator_next_leaf+0x430>
   16c6b:	lea    0x80(%rsp),%rcx
   16c73:	lea    0x3c(%rsp),%rdx
   16c78:	xor    %r8d,%r8d
   16c7b:	sub    $0x20,%rsp
   16c7f:	mov    %r14,%rsi
   16c82:	mov    %r13,0x10(%rsp)
   16c87:	movups %xmm0,(%rsp)
   16c8b:	call   efb0 <btree_find_pivot_checked.lto_priv.0>
   16c90:	add    $0x20,%rsp
   16c94:	jmp    16b0b <btree_iterator_next_leaf+0x4eb>
   16c99:	call   165f0 <btree_node_next_addr.part.0.lto_priv.0>
   16c9e:	xor    %edx,%edx
   16ca0:	jmp    16a19 <btree_iterator_next_leaf+0x3f9>
   16ca5:	mov    0x14(%rsp),%edi
   16ca9:	call   12310 <comparison_invert.part.0.lto_priv.0>

Disassembly of section .fini:
