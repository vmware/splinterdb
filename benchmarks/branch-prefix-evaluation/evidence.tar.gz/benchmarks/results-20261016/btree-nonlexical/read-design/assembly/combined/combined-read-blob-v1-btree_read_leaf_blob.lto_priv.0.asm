
/home/rob/projects/splinterdb/.cache/projects-20261011/worktrees/branch-prefix/.cache/btree-nonlexical-20261016/combined-read-blob-v1-btree-prefix-bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000000efb0 <btree_read_leaf_blob.lto_priv.0>:
    efb0:	sub    $0x58,%rsp
    efb4:	movzwl (%rsi),%eax
    efb7:	movzwl 0x3(%rsi),%edx
    efbb:	mov    %rsp,%rcx
    efbe:	lea    0x6(%rsi,%rax,1),%rax
    efc3:	xchg   %rax,%rdx
    efc5:	mov    %rax,%rsi
    efc8:	call   24340 <blob_parse_descriptor>
    efcd:	add    $0x58,%rsp
    efd1:	ret

Disassembly of section .fini:
