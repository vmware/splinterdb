
/home/rob/projects/splinterdb/.cache/projects-20261011/worktrees/branch-prefix/.cache/btree-nonlexical-20261016/combined-read-blob-v1-btree-prefix-bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000000f280 <btree_find_tuple_checked.lto_priv.0>:
    f280:	push   %r15
    f282:	mov    %rdi,%r9
    f285:	mov    %rdx,%r15
    f288:	mov    %r8,%r11
    f28b:	push   %r14
    f28d:	push   %r13
    f28f:	push   %r12
    f291:	mov    %rsi,%r12
    f294:	push   %rbp
    f295:	push   %rbx
    f296:	sub    $0x98,%rsp
    f29d:	movzwl 0x24(%rsi),%r14d
    f2a2:	movzwl 0x26(%rsi),%r13d
    f2a7:	movl   $0x0,(%rdx)
    f2ad:	mov    %rcx,0x38(%rsp)
    f2b2:	mov    0xd0(%rsp),%eax
    f2b9:	mov    0xd8(%rsp),%rbp
    f2c1:	mov    0xe0(%rsp),%rdi
    f2c9:	mov    %r14,%r10
    f2cc:	test   %r13w,%r13w
    f2d0:	jne    f460 <btree_find_tuple_checked.lto_priv.0+0x1e0>
    f2d6:	mov    0x8(%r9),%rdx
    f2da:	mov    0x30(%rdx),%edx
    f2dd:	test   %edx,%edx
    f2df:	je     f4a0 <btree_find_tuple_checked.lto_priv.0+0x220>
    f2e5:	mov    %eax,%edx
    f2e7:	and    $0xfffffffd,%edx
    f2ea:	cmp    $0x1,%edx
    f2ed:	je     f4a0 <btree_find_tuple_checked.lto_priv.0+0x220>
    f2f3:	movzwl %r13w,%eax
    f2f7:	xor    %r8d,%r8d
    f2fa:	mov    %rax,0x28(%rsp)
    f2ff:	test   %r14,%r14
    f302:	je     f7fd <btree_find_tuple_checked.lto_priv.0+0x57d>
    f308:	mov    %r15,0x48(%rsp)
    f30d:	mov    %r12,%r15
    f310:	mov    %r14,%r12
    f313:	mov    %r8,%r14
    f316:	mov    %rdi,0x20(%rsp)
    f31b:	mov    %r10w,0x18(%rsp)
    f321:	mov    %r9,0x30(%rsp)
    f326:	mov    %r11,0x40(%rsp)
    f32b:	jmp    f33d <btree_find_tuple_checked.lto_priv.0+0xbd>
    f32d:	nopl   (%rax)
    f330:	lea    0x1(%rbx),%r14
    f334:	cmp    %r12,%r14
    f337:	jge    f424 <btree_find_tuple_checked.lto_priv.0+0x1a4>
    f33d:	lea    (%r14,%r12,1),%rax
    f341:	mov    %rax,%rbx
    f344:	shr    $0x3f,%rbx
    f348:	add    %rax,%rbx
    f34b:	sar    $1,%rbx
    f34e:	cmp    0x18(%rsp),%bx
    f353:	jae    f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f359:	movzwl %bx,%eax
    f35c:	movzwl 0x28(%r15,%rax,2),%eax
    f362:	cmp    0x22(%r15),%ax
    f367:	jb     f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f36d:	mov    0x30(%rsp),%rsi
    f372:	mov    0x28(%rsp),%r9
    f377:	lea    0x6(%rax),%rcx
    f37b:	mov    0x10(%rsi),%rsi
    f37f:	mov    %rsi,%rdx
    f382:	sub    %r9,%rdx
    f385:	cmp    %rcx,%rdx
    f388:	jb     f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f38e:	lea    (%r15,%rax,1),%rcx
    f392:	cmpb   $0x0,0x2(%rcx)
    f396:	jne    f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f39c:	movzwl (%rcx),%edi
    f39f:	cmp    $0xfffd,%di
    f3a3:	ja     f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f3a9:	sub    $0x6,%rdx
    f3ad:	movzwl %di,%r13d
    f3b1:	mov    %di,0x10(%rsp)
    f3b6:	sub    %rax,%rdx
    f3b9:	cmp    %r13,%rdx
    f3bc:	jb     f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f3c2:	lea    0x0(%r13,%r9,1),%rax
    f3c7:	shr    $0x3,%rsi
    f3cb:	cmp    %rax,%rsi
    f3ce:	jb     f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f3d4:	cmp    %r13,%rbp
    f3d7:	mov    %r13,%rdx
    f3da:	mov    0x20(%rsp),%rdi
    f3df:	lea    0x6(%rcx),%rsi
    f3e3:	cmovbe %rbp,%rdx
    f3e7:	mov    %rcx,0x8(%rsp)
    f3ec:	call   3240 <memcmp@plt>
    f3f1:	test   %eax,%eax
    f3f3:	jne    f410 <btree_find_tuple_checked.lto_priv.0+0x190>
    f3f5:	cmp    %r13,%rbp
    f3f8:	jb     f418 <btree_find_tuple_checked.lto_priv.0+0x198>
    f3fa:	movzwl 0x10(%rsp),%r13d
    f400:	mov    %ebp,%eax
    f402:	mov    0x8(%rsp),%rcx
    f407:	sub    %r13d,%eax
    f40a:	je     f768 <btree_find_tuple_checked.lto_priv.0+0x4e8>
    f410:	test   %eax,%eax
    f412:	jg     f330 <btree_find_tuple_checked.lto_priv.0+0xb0>
    f418:	mov    %rbx,%r12
    f41b:	cmp    %r12,%r14
    f41e:	jl     f33d <btree_find_tuple_checked.lto_priv.0+0xbd>
    f424:	mov    %r14,%r8
    f427:	mov    0x40(%rsp),%r11
    f42c:	sub    $0x1,%r8
    f430:	mov    0x38(%rsp),%rax
    f435:	mov    %r8,(%rax)
    f438:	test   %r11,%r11
    f43b:	je     f444 <btree_find_tuple_checked.lto_priv.0+0x1c4>
    f43d:	movq   $0x0,(%r11)
    f444:	xor    %eax,%eax
    f446:	add    $0x98,%rsp
    f44d:	pop    %rbx
    f44e:	pop    %rbp
    f44f:	pop    %r12
    f451:	pop    %r13
    f453:	pop    %r14
    f455:	pop    %r15
    f457:	ret
    f458:	nopl   0x0(%rax,%rax,1)
    f460:	cmp    $0x1,%eax
    f463:	je     f7da <btree_find_tuple_checked.lto_priv.0+0x55a>
    f469:	cmp    $0x3,%eax
    f46c:	je     f79e <btree_find_tuple_checked.lto_priv.0+0x51e>
    f472:	movq   $0xffffffffffffffff,0x10(%rsp)
    f47b:	cmp    $0x2,%eax
    f47e:	je     f640 <btree_find_tuple_checked.lto_priv.0+0x3c0>
    f484:	mov    0x38(%rsp),%rax
    f489:	mov    0x10(%rsp),%rcx
    f48e:	mov    %rcx,(%rax)
    f491:	test   %r11,%r11
    f494:	je     f444 <btree_find_tuple_checked.lto_priv.0+0x1c4>
    f496:	movq   $0x0,(%r11)
    f49d:	jmp    f444 <btree_find_tuple_checked.lto_priv.0+0x1c4>
    f49f:	nop
    f4a0:	test   %r14,%r14
    f4a3:	je     f809 <btree_find_tuple_checked.lto_priv.0+0x589>
    f4a9:	cmp    $0x2,%eax
    f4ac:	jne    f6a0 <btree_find_tuple_checked.lto_priv.0+0x420>
    f4b2:	mov    0xd4(%rsp),%eax
    f4b9:	xor    %ebx,%ebx
    f4bb:	mov    %rbp,0x10(%rsp)
    f4c0:	mov    %r9,%rbp
    f4c3:	mov    %r15,0x28(%rsp)
    f4c8:	mov    %r14,%r15
    f4cb:	mov    %rbx,%r14
    f4ce:	mov    %r12,%rbx
    f4d1:	mov    %eax,0x8(%rsp)
    f4d5:	mov    %rdi,0x18(%rsp)
    f4da:	mov    %r11,0x20(%rsp)
    f4df:	jmp    f4fa <btree_find_tuple_checked.lto_priv.0+0x27a>
    f4e1:	nopl   0x0(%rax)
    f4e8:	lea    0x1(%r13),%r14
    f4ec:	cmp    %r15,%r14
    f4ef:	jge    f7f0 <btree_find_tuple_checked.lto_priv.0+0x570>
    f4f5:	movzwl 0x24(%rbx),%r10d
    f4fa:	lea    (%r14,%r15,1),%rax
    f4fe:	mov    %rax,%r13
    f501:	shr    $0x3f,%r13
    f505:	add    %rax,%r13
    f508:	sar    $1,%r13
    f50b:	cmp    %r10w,%r13w
    f50f:	jae    f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f515:	movzwl %r13w,%eax
    f519:	movzwl 0x28(%rbx,%rax,2),%eax
    f51e:	cmp    0x22(%rbx),%ax
    f522:	jb     f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f528:	mov    0x10(%rbp),%r11
    f52c:	movzwl 0x26(%rbx),%r10d
    f531:	lea    0x6(%rax),%rdx
    f535:	mov    %r11,%rdi
    f538:	sub    %r10,%rdi
    f53b:	cmp    %rdx,%rdi
    f53e:	jb     f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f544:	lea    (%rbx,%rax,1),%r12
    f548:	cmpb   $0x0,0x2(%r12)
    f54e:	jne    f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f554:	movzwl (%r12),%edx
    f559:	cmp    $0xfffd,%dx
    f55d:	ja     f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f563:	sub    $0x6,%rdi
    f567:	sub    %rax,%rdi
    f56a:	cmp    %rdx,%rdi
    f56d:	jb     f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f573:	add    %rdx,%r10
    f576:	shr    $0x3,%r11
    f57a:	cmp    %r10,%r11
    f57d:	jb     f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f583:	mov    0x10(%rsp),%rsi
    f588:	mov    0x18(%rsp),%rcx
    f58d:	mov    %rdx,0x70(%rsp)
    f592:	lea    0x6(%r12),%rdx
    f597:	mov    %rdx,0x78(%rsp)
    f59c:	sub    $0x30,%rsp
    f5a0:	mov    0x8(%rbp),%rax
    f5a4:	mov    %rsi,0x80(%rsp)
    f5ac:	mov    0x38(%rsp),%esi
    f5b0:	mov    %rcx,0x88(%rsp)
    f5b8:	mov    %rax,%rdi
    f5bb:	mov    %esi,0x90(%rsp)
    f5c2:	movl   $0x0,0xb0(%rsp)
    f5cd:	movdqa 0xa0(%rsp),%xmm0
    f5d6:	mov    0xb0(%rsp),%rdx
    f5de:	movups %xmm0,0x18(%rsp)
    f5e3:	movdqa 0x80(%rsp),%xmm0
    f5ec:	mov    %rdx,0x28(%rsp)
    f5f1:	mov    0x90(%rsp),%rdx
    f5f9:	movups %xmm0,(%rsp)
    f5fd:	mov    %rdx,0x10(%rsp)
    f602:	call   *(%rax)
    f604:	add    $0x30,%rsp
    f608:	test   %eax,%eax
    f60a:	je     f7b0 <btree_find_tuple_checked.lto_priv.0+0x530>
    f610:	jg     f4e8 <btree_find_tuple_checked.lto_priv.0+0x268>
    f616:	cmp    %r14,%r13
    f619:	jle    f7f0 <btree_find_tuple_checked.lto_priv.0+0x570>
    f61f:	mov    %r13,%r15
    f622:	jmp    f4f5 <btree_find_tuple_checked.lto_priv.0+0x275>
    f627:	nopw   0x0(%rax,%rax,1)
    f630:	mov    $0x16,%eax
    f635:	jmp    f446 <btree_find_tuple_checked.lto_priv.0+0x1c6>
    f63a:	nopw   0x0(%rax,%rax,1)
    f640:	movzwl %r13w,%ebx
    f644:	mov    %rbp,%rdx
    f647:	mov    %r8,0x8(%rsp)
    f64c:	cmp    %rbp,%rbx
    f64f:	mov    %r14d,0x28(%rsp)
    f654:	cmovbe %rbx,%rdx
    f658:	sub    %rbx,%rsi
    f65b:	add    0x10(%r9),%rsi
    f65f:	mov    %r9,0x20(%rsp)
    f664:	mov    %rdi,0x18(%rsp)
    f669:	call   3240 <memcmp@plt>
    f66e:	mov    0x8(%rsp),%r11
    f673:	test   %eax,%eax
    f675:	jne    f798 <btree_find_tuple_checked.lto_priv.0+0x518>
    f67b:	cmp    %rbx,%rbp
    f67e:	mov    0x18(%rsp),%rdi
    f683:	mov    0x20(%rsp),%r9
    f688:	mov    0x28(%rsp),%r10d
    f68d:	jb     f484 <btree_find_tuple_checked.lto_priv.0+0x204>
    f693:	add    %rbx,%rdi
    f696:	sub    %rbx,%rbp
    f699:	jmp    f2f3 <btree_find_tuple_checked.lto_priv.0+0x73>
    f69e:	xchg   %ax,%ax
    f6a0:	lea    -0x2(%rax),%esi
    f6a3:	xor    %ebx,%ebx
    f6a5:	data16 cs nopw 0x0(%rax,%rax,1)
    f6b0:	lea    (%r14,%rbx,1),%rdx
    f6b4:	mov    %rdx,%rax
    f6b7:	shr    $0x3f,%rax
    f6bb:	add    %rdx,%rax
    f6be:	sar    $1,%rax
    f6c1:	cmp    %r10w,%ax
    f6c5:	jae    f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f6cb:	movzwl %ax,%edx
    f6ce:	movzwl 0x28(%r12,%rdx,2),%edx
    f6d4:	cmp    0x22(%r12),%dx
    f6da:	jb     f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f6e0:	mov    0x10(%r9),%rdi
    f6e4:	lea    0x6(%rdx),%rcx
    f6e8:	cmp    %rcx,%rdi
    f6eb:	jb     f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f6f1:	lea    (%r12,%rdx,1),%rcx
    f6f5:	cmpb   $0x0,0x2(%rcx)
    f6f9:	jne    f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f6ff:	movzwl (%rcx),%ecx
    f702:	cmp    $0xfffd,%cx
    f706:	ja     f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f70c:	lea    -0x6(%rdi),%r8
    f710:	sub    %rdx,%r8
    f713:	cmp    %rcx,%r8
    f716:	jb     f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f71c:	shr    $0x3,%rdi
    f720:	cmp    %rcx,%rdi
    f723:	jb     f630 <btree_find_tuple_checked.lto_priv.0+0x3b0>
    f729:	test   %esi,%esi
    f72b:	jle    f758 <btree_find_tuple_checked.lto_priv.0+0x4d8>
    f72d:	lea    0x1(%rax),%rbx
    f731:	cmp    %r14,%rbx
    f734:	jl     f6b0 <btree_find_tuple_checked.lto_priv.0+0x430>
    f73a:	lea    -0x1(%rbx),%rdx
    f73e:	mov    0x38(%rsp),%rax
    f743:	mov    %rdx,(%rax)
    f746:	test   %r11,%r11
    f749:	jne    f43d <btree_find_tuple_checked.lto_priv.0+0x1bd>
    f74f:	jmp    f444 <btree_find_tuple_checked.lto_priv.0+0x1c4>
    f754:	nopl   0x0(%rax)
    f758:	cmp    %rbx,%rax
    f75b:	jle    f73a <btree_find_tuple_checked.lto_priv.0+0x4ba>
    f75d:	mov    %rax,%r14
    f760:	jmp    f6b0 <btree_find_tuple_checked.lto_priv.0+0x430>
    f765:	nopl   (%rax)
    f768:	mov    0x48(%rsp),%r15
    f76d:	mov    0x38(%rsp),%rsi
    f772:	mov    0x40(%rsp),%r11
    f777:	movl   $0x1,(%r15)
    f77e:	mov    %rbx,(%rsi)
    f781:	test   %r11,%r11
    f784:	je     f446 <btree_find_tuple_checked.lto_priv.0+0x1c6>
    f78a:	mov    %rcx,(%r11)
    f78d:	jmp    f446 <btree_find_tuple_checked.lto_priv.0+0x1c6>
    f792:	nopw   0x0(%rax,%rax,1)
    f798:	js     f484 <btree_find_tuple_checked.lto_priv.0+0x204>
    f79e:	lea    -0x1(%r14),%rax
    f7a2:	mov    %rax,0x10(%rsp)
    f7a7:	jmp    f484 <btree_find_tuple_checked.lto_priv.0+0x204>
    f7ac:	nopl   0x0(%rax)
    f7b0:	mov    0x28(%rsp),%r15
    f7b5:	mov    0x38(%rsp),%rcx
    f7ba:	mov    0x20(%rsp),%r11
    f7bf:	movl   $0x1,(%r15)
    f7c6:	mov    %r13,(%rcx)
    f7c9:	test   %r11,%r11
    f7cc:	je     f446 <btree_find_tuple_checked.lto_priv.0+0x1c6>
    f7d2:	mov    %r12,(%r11)
    f7d5:	jmp    f446 <btree_find_tuple_checked.lto_priv.0+0x1c6>
    f7da:	movq   $0xffffffffffffffff,0x10(%rsp)
    f7e3:	jmp    f484 <btree_find_tuple_checked.lto_priv.0+0x204>
    f7e8:	nopl   0x0(%rax,%rax,1)
    f7f0:	mov    0x20(%rsp),%r11
    f7f5:	mov    %r14,%rbx
    f7f8:	jmp    f73a <btree_find_tuple_checked.lto_priv.0+0x4ba>
    f7fd:	mov    $0xffffffffffffffff,%r8
    f804:	jmp    f430 <btree_find_tuple_checked.lto_priv.0+0x1b0>
    f809:	mov    $0xffffffffffffffff,%rdx
    f810:	jmp    f73e <btree_find_tuple_checked.lto_priv.0+0x4be>

Disassembly of section .fini:
