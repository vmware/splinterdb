
/home/rob/projects/splinterdb/.cache/projects-20261011/worktrees/branch-prefix/.cache/btree-nonlexical-20261016/combined-read-blob-v1-btree-prefix-bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000016d50 <btree_iterator_next>:
   16d50:	push   %rbp
   16d51:	push   %rbx
   16d52:	sub    $0x18,%rsp
   16d56:	mov    0xb4(%rdi),%ebp
   16d5c:	test   %ebp,%ebp
   16d5e:	je     16d70 <btree_iterator_next+0x20>
   16d60:	add    $0x18,%rsp
   16d64:	mov    %ebp,%eax
   16d66:	pop    %rbx
   16d67:	pop    %rbp
   16d68:	ret
   16d69:	nopl   0x0(%rax)
   16d70:	mov    0xd8(%rdi),%esi
   16d76:	mov    %rdi,%rbx
   16d79:	test   %esi,%esi
   16d7b:	je     16d98 <btree_iterator_next+0x48>
   16d7d:	mov    0xcc(%rdi),%ecx
   16d83:	test   %ecx,%ecx
   16d85:	jne    16f30 <btree_iterator_next+0x1e0>
   16d8b:	mov    $0x1,%esi
   16d90:	mov    %rbx,%rdi
   16d93:	call   14c80 <btree_iterator_maybe_start_prefetch.part.0>
   16d98:	mov    0x80(%rbx),%rdx
   16d9f:	mov    0x90(%rbx),%rax
   16da6:	movzwl 0x24(%rdx),%edx
   16daa:	add    $0x1,%rax
   16dae:	mov    %rax,0x90(%rbx)
   16db5:	cmp    %rdx,%rax
   16db8:	jne    16df0 <btree_iterator_next+0xa0>
   16dba:	mov    0xb4(%rbx),%edx
   16dc0:	test   %edx,%edx
   16dc2:	jne    16df0 <btree_iterator_next+0xa0>
   16dc4:	mov    0xa0(%rbx),%rcx
   16dcb:	cmp    %rcx,0x68(%rbx)
   16dcf:	je     17020 <btree_iterator_next+0x2d0>
   16dd5:	mov    %rbx,%rdi
   16dd8:	call   166b0 <btree_iterator_next_leaf>
   16ddd:	test   %eax,%eax
   16ddf:	jne    17080 <btree_iterator_next+0x330>
   16de5:	data16 cs nopw 0x0(%rax,%rax,1)
   16df0:	movq   $0x0,0xb8(%rbx)
   16dfb:	cmpl   $0x2,0x1c(%rbx)
   16dff:	jne    16d60 <btree_iterator_next+0x10>
   16e05:	mov    0xb4(%rbx),%eax
   16e0b:	test   %eax,%eax
   16e0d:	jne    16d60 <btree_iterator_next+0x10>
   16e13:	mov    0x90(%rbx),%rdx
   16e1a:	mov    0xa0(%rbx),%rax
   16e21:	cmp    %rax,0x68(%rbx)
   16e25:	je     17048 <btree_iterator_next+0x2f8>
   16e2b:	cmp    %rdx,0x98(%rbx)
   16e32:	jg     17018 <btree_iterator_next+0x2c8>
   16e38:	mov    0x80(%rbx),%rax
   16e3f:	mov    0x10(%rbx),%rsi
   16e43:	cmpb   $0x0,0x20(%rax)
   16e47:	movzwl 0x24(%rax),%ecx
   16e4b:	jne    16fa0 <btree_iterator_next+0x250>
   16e51:	cmp    %cx,%dx
   16e54:	jae    17090 <btree_iterator_next+0x340>
   16e5a:	movzwl %dx,%edx
   16e5d:	movzwl 0x28(%rax,%rdx,2),%ecx
   16e62:	cmp    0x22(%rax),%cx
   16e66:	jb     17090 <btree_iterator_next+0x340>
   16e6c:	mov    0x10(%rsi),%rdx
   16e70:	movzwl 0x26(%rax),%r8d
   16e75:	lea    0x6(%rcx),%rsi
   16e79:	mov    %rdx,%r9
   16e7c:	mov    %r8,%rdi
   16e7f:	sub    %r8,%r9
   16e82:	cmp    %rsi,%r9
   16e85:	jb     17090 <btree_iterator_next+0x340>
   16e8b:	lea    (%rax,%rcx,1),%rsi
   16e8f:	cmpb   $0x0,0x2(%rsi)
   16e93:	jne    17090 <btree_iterator_next+0x340>
   16e99:	movzwl (%rsi),%eax
   16e9c:	mov    %rdx,%r10
   16e9f:	mov    $0x16,%ebp
   16ea4:	shr    $0x3,%r10
   16ea8:	lea    (%rax,%r8,1),%r9
   16eac:	cmp    %r9,%r10
   16eaf:	jb     16f10 <btree_iterator_next+0x1c0>
   16eb1:	movzbl 0x5(%rsi),%r9d
   16eb6:	test   $0x3,%r9b
   16eba:	je     17090 <btree_iterator_next+0x340>
   16ec0:	cmp    $0x7,%r9b
   16ec4:	ja     17090 <btree_iterator_next+0x340>
   16eca:	movzwl 0x3(%rsi),%r10d
   16ecf:	add    %rax,%r10
   16ed2:	lea    -0x6(%rdx),%rax
   16ed6:	sub    %r8,%rax
   16ed9:	sub    %rcx,%rax
   16edc:	cmp    %r10,%rax
   16edf:	jb     16f10 <btree_iterator_next+0x1c0>
   16ee1:	and    $0x4,%r9d
   16ee5:	jne    1709a <btree_iterator_next+0x34a>
   16eeb:	mov    %rsi,0xb8(%rbx)
   16ef2:	test   %di,%di
   16ef5:	je     17018 <btree_iterator_next+0x2c8>
   16efb:	mov    %rbx,%rdi
   16efe:	call   11dc0 <btree_iterator_decode_current>
   16f03:	mov    %eax,%ebp
   16f05:	test   %eax,%eax
   16f07:	je     17018 <btree_iterator_next+0x2c8>
   16f0d:	nopl   (%rax)
   16f10:	movq   $0x0,0xb8(%rbx)
   16f1b:	mov    %ebp,0xb4(%rbx)
   16f21:	jmp    16d60 <btree_iterator_next+0x10>
   16f26:	cs nopw 0x0(%rax,%rax,1)
   16f30:	cmpl   $0x1,0xd4(%rdi)
   16f37:	je     16d98 <btree_iterator_next+0x48>
   16f3d:	cmpq   $0x0,0x108(%rdi)
   16f45:	je     16f66 <btree_iterator_next+0x216>
   16f47:	lea    0x108(%rdi),%rsi
   16f4e:	mov    0xf8(%rdi),%rdi
   16f55:	mov    (%rdi),%rax
   16f58:	call   *0x30(%rax)
   16f5b:	pxor   %xmm0,%xmm0
   16f5f:	movups %xmm0,0x108(%rbx)
   16f66:	movl   $0x0,0xc8(%rbx)
   16f70:	pxor   %xmm0,%xmm0
   16f74:	movq   $0x0,0xcc(%rbx)
   16f7f:	movq   $0x0,0xf0(%rbx)
   16f8a:	movups %xmm0,0x118(%rbx)
   16f91:	movups %xmm0,0x128(%rbx)
   16f98:	jmp    16d8b <btree_iterator_next+0x3b>
   16f9d:	nopl   (%rax)
   16fa0:	cmp    %cx,%dx
   16fa3:	jae    17090 <btree_iterator_next+0x340>
   16fa9:	movzwl %dx,%edx
   16fac:	movzwl 0x28(%rax,%rdx,2),%edx
   16fb1:	cmp    0x22(%rax),%dx
   16fb5:	jb     17090 <btree_iterator_next+0x340>
   16fbb:	movzwl 0x26(%rax),%ecx
   16fbf:	mov    0x10(%rsi),%rsi
   16fc3:	sub    %rcx,%rsi
   16fc6:	lea    0x17(%rdx),%rcx
   16fca:	cmp    %rcx,%rsi
   16fcd:	jb     17090 <btree_iterator_next+0x340>
   16fd3:	add    %rdx,%rax
   16fd6:	movzbl 0x16(%rax),%edi
   16fda:	cmp    $0x1,%dil
   16fde:	ja     17090 <btree_iterator_next+0x340>
   16fe4:	movzwl 0x14(%rax),%ecx
   16fe8:	mov    %rcx,%r8
   16feb:	add    $0x17,%rcx
   16fef:	cmp    $0xfffd,%r8w
   16ff4:	mov    $0x17,%r8d
   16ffa:	cmova  %r8,%rcx
   16ffe:	test   %dil,%dil
   17001:	lea    0xc(%rcx),%r8
   17005:	cmovne %r8,%rcx
   17009:	sub    %rdx,%rsi
   1700c:	cmp    %rcx,%rsi
   1700f:	jb     17090 <btree_iterator_next+0x340>
   17011:	mov    %rax,0xb8(%rbx)
   17018:	xor    %ebp,%ebp
   1701a:	jmp    16d60 <btree_iterator_next+0x10>
   1701f:	nop
   17020:	mov    0xa8(%rbx),%rdx
   17027:	cmp    %rdx,%rax
   1702a:	jge    16df0 <btree_iterator_next+0xa0>
   17030:	cmp    0x98(%rbx),%rdx
   17037:	jne    16dd5 <btree_iterator_next+0x85>
   1703d:	jmp    16df0 <btree_iterator_next+0xa0>
   17042:	nopw   0x0(%rax,%rax,1)
   17048:	mov    0xa8(%rbx),%rax
   1704f:	xor    %ebp,%ebp
   17051:	cmp    %rdx,%rax
   17054:	jle    16d60 <btree_iterator_next+0x10>
   1705a:	mov    0x98(%rbx),%rcx
   17061:	cmp    %rcx,%rax
   17064:	je     16d60 <btree_iterator_next+0x10>
   1706a:	cmp    %rdx,%rcx
   1706d:	jg     16d60 <btree_iterator_next+0x10>
   17073:	jmp    16e38 <btree_iterator_next+0xe8>
   17078:	nopl   0x0(%rax,%rax,1)
   17080:	mov    %eax,%ebp
   17082:	jmp    16d60 <btree_iterator_next+0x10>
   17087:	nopw   0x0(%rax,%rax,1)
   17090:	mov    $0x16,%ebp
   17095:	jmp    16f10 <btree_iterator_next+0x1c0>
   1709a:	mov    0x8(%rbx),%rdi
   1709e:	mov    %rsi,0x8(%rsp)
   170a3:	call   efb0 <btree_read_leaf_blob.lto_priv.0>
   170a8:	mov    %eax,%ebp
   170aa:	test   %eax,%eax
   170ac:	jne    16f10 <btree_iterator_next+0x1c0>
   170b2:	mov    0x80(%rbx),%rax
   170b9:	mov    0x8(%rsp),%rsi
   170be:	movzwl 0x26(%rax),%edi
   170c2:	jmp    16eeb <btree_iterator_next+0x19b>

Disassembly of section .fini:
