
/home/rob/projects/splinterdb/.cache/projects-20261011/worktrees/branch-prefix/.cache/btree-nonlexical-20261016/combined-read-blob-v1-btree-prefix-bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000012140 <btree_iterator_check_current>:
   12140:	push   %rbp
   12141:	xor    %ebp,%ebp
   12143:	push   %rbx
   12144:	sub    $0x18,%rsp
   12148:	cmpl   $0x2,0x1c(%rdi)
   1214c:	movq   $0x0,0xb8(%rdi)
   12157:	jne    1225a <btree_iterator_check_current+0x11a>
   1215d:	mov    0xb4(%rdi),%ebp
   12163:	mov    %rdi,%rbx
   12166:	test   %ebp,%ebp
   12168:	jne    12258 <btree_iterator_check_current+0x118>
   1216e:	mov    0x90(%rdi),%rdx
   12175:	mov    0xa0(%rdi),%rax
   1217c:	cmp    %rax,0x68(%rdi)
   12180:	je     12290 <btree_iterator_check_current+0x150>
   12186:	cmp    %rdx,0x98(%rdi)
   1218d:	jg     1225a <btree_iterator_check_current+0x11a>
   12193:	mov    0x80(%rbx),%rax
   1219a:	mov    0x10(%rbx),%rsi
   1219e:	cmpb   $0x0,0x20(%rax)
   121a2:	movzwl 0x24(%rax),%ecx
   121a6:	jne    12268 <btree_iterator_check_current+0x128>
   121ac:	cmp    %cx,%dx
   121af:	jae    12270 <btree_iterator_check_current+0x130>
   121b5:	movzwl %dx,%edx
   121b8:	movzwl 0x28(%rax,%rdx,2),%ecx
   121bd:	cmp    0x22(%rax),%cx
   121c1:	jb     12270 <btree_iterator_check_current+0x130>
   121c7:	mov    0x10(%rsi),%rdx
   121cb:	movzwl 0x26(%rax),%edi
   121cf:	lea    0x6(%rcx),%rsi
   121d3:	mov    %rdx,%r9
   121d6:	mov    %rdi,%r8
   121d9:	sub    %rdi,%r9
   121dc:	cmp    %rsi,%r9
   121df:	jb     12270 <btree_iterator_check_current+0x130>
   121e5:	lea    (%rax,%rcx,1),%rsi
   121e9:	cmpb   $0x0,0x2(%rsi)
   121ed:	jne    12270 <btree_iterator_check_current+0x130>
   121f3:	movzwl (%rsi),%eax
   121f6:	mov    %rdx,%r10
   121f9:	shr    $0x3,%r10
   121fd:	lea    (%rax,%rdi,1),%r9
   12201:	cmp    %r9,%r10
   12204:	jb     12270 <btree_iterator_check_current+0x130>
   12206:	movzbl 0x5(%rsi),%r9d
   1220b:	test   $0x3,%r9b
   1220f:	je     12270 <btree_iterator_check_current+0x130>
   12211:	cmp    $0x7,%r9b
   12215:	ja     12270 <btree_iterator_check_current+0x130>
   12217:	movzwl 0x3(%rsi),%r10d
   1221c:	add    %rax,%r10
   1221f:	lea    -0x6(%rdx),%rax
   12223:	sub    %rdi,%rax
   12226:	sub    %rcx,%rax
   12229:	cmp    %r10,%rax
   1222c:	jb     12270 <btree_iterator_check_current+0x130>
   1222e:	and    $0x4,%r9d
   12232:	jne    12324 <btree_iterator_check_current+0x1e4>
   12238:	mov    %rsi,0xb8(%rbx)
   1223f:	test   %r8w,%r8w
   12243:	je     1225a <btree_iterator_check_current+0x11a>
   12245:	mov    %rbx,%rdi
   12248:	call   11dc0 <btree_iterator_decode_current>
   1224d:	test   %eax,%eax
   1224f:	je     1225a <btree_iterator_check_current+0x11a>
   12251:	mov    %eax,%ebp
   12253:	jmp    12275 <btree_iterator_check_current+0x135>
   12255:	nopl   (%rax)
   12258:	xor    %ebp,%ebp
   1225a:	add    $0x18,%rsp
   1225e:	mov    %ebp,%eax
   12260:	pop    %rbx
   12261:	pop    %rbp
   12262:	ret
   12263:	nopl   0x0(%rax,%rax,1)
   12268:	cmp    %cx,%dx
   1226b:	jb     122b8 <btree_iterator_check_current+0x178>
   1226d:	nopl   (%rax)
   12270:	mov    $0x16,%ebp
   12275:	movq   $0x0,0xb8(%rbx)
   12280:	mov    %ebp,0xb4(%rbx)
   12286:	jmp    1225a <btree_iterator_check_current+0x11a>
   12288:	nopl   0x0(%rax,%rax,1)
   12290:	mov    0xa8(%rdi),%rax
   12297:	cmp    %rdx,%rax
   1229a:	jle    1225a <btree_iterator_check_current+0x11a>
   1229c:	mov    0x98(%rdi),%rcx
   122a3:	cmp    %rcx,%rax
   122a6:	je     1225a <btree_iterator_check_current+0x11a>
   122a8:	cmp    %rdx,%rcx
   122ab:	jg     1225a <btree_iterator_check_current+0x11a>
   122ad:	jmp    12193 <btree_iterator_check_current+0x53>
   122b2:	nopw   0x0(%rax,%rax,1)
   122b8:	movzwl %dx,%edx
   122bb:	movzwl 0x28(%rax,%rdx,2),%edx
   122c0:	cmp    0x22(%rax),%dx
   122c4:	jb     12270 <btree_iterator_check_current+0x130>
   122c6:	movzwl 0x26(%rax),%ecx
   122ca:	mov    0x10(%rsi),%rsi
   122ce:	sub    %rcx,%rsi
   122d1:	lea    0x17(%rdx),%rcx
   122d5:	cmp    %rcx,%rsi
   122d8:	jb     12270 <btree_iterator_check_current+0x130>
   122da:	add    %rdx,%rax
   122dd:	movzbl 0x16(%rax),%edi
   122e1:	cmp    $0x1,%dil
   122e5:	ja     12270 <btree_iterator_check_current+0x130>
   122e7:	movzwl 0x14(%rax),%ecx
   122eb:	mov    %rcx,%r8
   122ee:	add    $0x17,%rcx
   122f2:	cmp    $0xfffd,%r8w
   122f7:	mov    $0x17,%r8d
   122fd:	cmova  %r8,%rcx
   12301:	test   %dil,%dil
   12304:	lea    0xc(%rcx),%r8
   12308:	cmovne %r8,%rcx
   1230c:	sub    %rdx,%rsi
   1230f:	cmp    %rcx,%rsi
   12312:	jb     12270 <btree_iterator_check_current+0x130>
   12318:	mov    %rax,0xb8(%rbx)
   1231f:	jmp    1225a <btree_iterator_check_current+0x11a>
   12324:	mov    0x8(%rbx),%rdi
   12328:	mov    %rsi,0x8(%rsp)
   1232d:	call   efb0 <btree_read_leaf_blob.lto_priv.0>
   12332:	mov    0x8(%rsp),%rsi
   12337:	test   %eax,%eax
   12339:	jne    12251 <btree_iterator_check_current+0x111>
   1233f:	mov    0x80(%rbx),%rax
   12346:	movzwl 0x26(%rax),%r8d
   1234b:	jmp    12238 <btree_iterator_check_current+0xf8>

Disassembly of section .fini:
