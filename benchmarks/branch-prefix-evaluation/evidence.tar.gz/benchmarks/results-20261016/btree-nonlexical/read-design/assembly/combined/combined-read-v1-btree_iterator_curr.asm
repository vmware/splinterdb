
/home/rob/projects/splinterdb/.cache/projects-20261011/worktrees/branch-prefix/.cache/btree-nonlexical-20261016/combined-read-v1-btree-prefix-bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000011e10 <btree_iterator_curr>:
   11e10:	push   %r12
   11e12:	mov    %rsi,%r12
   11e15:	push   %rbp
   11e16:	mov    %rdx,%rbp
   11e19:	push   %rbx
   11e1a:	mov    %rdi,%rbx
   11e1d:	sub    $0x30,%rsp
   11e21:	cmpq   $0x0,0x70(%rdi)
   11e26:	je     11e3d <btree_iterator_curr+0x2d>
   11e28:	mov    0x8(%rdi),%rdi
   11e2c:	mov    0x68(%rbx),%rdx
   11e30:	lea    0x70(%rbx),%rsi
   11e34:	mov    (%rdi),%rax
   11e37:	call   *0xd0(%rax)
   11e3d:	mov    0x80(%rbx),%rax
   11e44:	mov    0x1c(%rbx),%edx
   11e47:	cmpb   $0x0,0x20(%rax)
   11e4b:	jne    11eb0 <btree_iterator_curr+0xa0>
   11e4d:	cmp    $0x2,%edx
   11e50:	je     12050 <btree_iterator_curr+0x240>
   11e56:	movzwl 0x90(%rbx),%edx
   11e5d:	movzwl 0x28(%rax,%rdx,2),%ecx
   11e62:	add    %rax,%rcx
   11e65:	movzwl 0x26(%rax),%eax
   11e69:	movzwl (%rcx),%esi
   11e6c:	test   %ax,%ax
   11e6f:	jne    11fb0 <btree_iterator_curr+0x1a0>
   11e75:	lea    0x6(%rcx),%rdx
   11e79:	mov    %rsi,%rax
   11e7c:	mov    %rdx,%rdi
   11e7f:	movq   $0x2,(%r12)
   11e87:	add    %rsi,%rdx
   11e8a:	movzwl 0x3(%rcx),%esi
   11e8e:	mov    %rax,0x8(%r12)
   11e93:	mov    %rdi,0x10(%r12)
   11e98:	movzbl 0x5(%rcx),%eax
   11e9c:	xor    %ecx,%ecx
   11e9e:	test   $0x4,%al
   11ea0:	je     11ea6 <btree_iterator_curr+0x96>
   11ea2:	mov    0x8(%rbx),%rcx
   11ea6:	and    $0x3,%eax
   11ea9:	jmp    11f92 <btree_iterator_curr+0x182>
   11eae:	xchg   %ax,%ax
   11eb0:	cmp    $0x2,%edx
   11eb3:	je     12020 <btree_iterator_curr+0x210>
   11eb9:	movzwl 0x90(%rbx),%edx
   11ec0:	movzwl 0x28(%rax,%rdx,2),%edx
   11ec5:	add    %rdx,%rax
   11ec8:	movzwl 0x14(%rax),%edx
   11ecc:	cmp    $0xffff,%dx
   11ed0:	je     12035 <btree_iterator_curr+0x225>
   11ed6:	cmp    $0xfffe,%dx
   11eda:	je     12060 <btree_iterator_curr+0x250>
   11ee0:	lea    0x17(%rax),%rcx
   11ee4:	movzwl %dx,%esi
   11ee7:	mov    $0x2,%edi
   11eec:	mov    %rcx,0x10(%r12)
   11ef1:	pxor   %xmm3,%xmm3
   11ef5:	movq   (%rax),%xmm2
   11ef9:	mov    %edi,(%r12)
   11efd:	mov    0x10(%rax),%ecx
   11f00:	movl   $0x0,0x4(%r12)
   11f09:	mov    %rsi,0x8(%r12)
   11f0e:	movq   0x8(%rax),%xmm0
   11f13:	punpckldq %xmm3,%xmm0
   11f17:	testb  $0x1,0x16(%rax)
   11f1b:	je     11fd0 <btree_iterator_curr+0x1c0>
   11f21:	add    $0x17,%rax
   11f25:	movzwl %dx,%esi
   11f28:	add    %rax,%rsi
   11f2b:	cmp    $0xfffd,%dx
   11f2f:	cmovbe %rsi,%rax
   11f33:	movq   (%rax),%xmm1
   11f37:	mov    0x8(%rax),%eax
   11f3a:	shl    $0x20,%rax
   11f3e:	movq   %xmm1,(%rsp)
   11f43:	punpckldq %xmm3,%xmm1
   11f47:	or     %rcx,%rax
   11f4a:	psllq  $0x20,%xmm1
   11f4f:	mov    %rax,0x20(%rsp)
   11f54:	por    %xmm0,%xmm1
   11f58:	movaps %xmm1,0x10(%rsp)
   11f5d:	movdqa %xmm2,%xmm1
   11f61:	mov    $0x3e8,%eax
   11f66:	xor    %ecx,%ecx
   11f68:	mov    $0x20,%esi
   11f6d:	movq   0x18(%rsp),%xmm0
   11f73:	movhps 0x10(%rsp),%xmm1
   11f78:	lea    0x138(%rbx),%rdx
   11f7f:	movups %xmm1,0x138(%rbx)
   11f86:	movhps 0x20(%rsp),%xmm0
   11f8b:	movups %xmm0,0x148(%rbx)
   11f92:	mov    %eax,0x0(%rbp)
   11f95:	mov    %rcx,0x8(%rbp)
   11f99:	mov    %rsi,0x10(%rbp)
   11f9d:	mov    %rdx,0x18(%rbp)
   11fa1:	add    $0x30,%rsp
   11fa5:	pop    %rbx
   11fa6:	pop    %rbp
   11fa7:	pop    %r12
   11fa9:	ret
   11faa:	nopw   0x0(%rax,%rax,1)
   11fb0:	mov    0xc0(%rbx),%rdx
   11fb7:	add    %rsi,%rax
   11fba:	mov    0x50(%rdx),%rdi
   11fbe:	lea    0x6(%rcx),%rdx
   11fc2:	jmp    11e7f <btree_iterator_curr+0x6f>
   11fc7:	nopw   0x0(%rax,%rax,1)
   11fd0:	mov    $0x7fffffff,%eax
   11fd5:	cmp    $0x7fffffff,%rcx
   11fdc:	movq   %rax,%xmm1
   11fe1:	mov    $0xffffffffffffffff,%rax
   11fe8:	punpcklqdq %xmm1,%xmm1
   11fec:	cmove  %rax,%rcx
   11ff0:	pcmpeqd %xmm0,%xmm1
   11ff4:	mov    %rcx,0x20(%rsp)
   11ff9:	pshufd $0xb1,%xmm1,%xmm3
   11ffe:	pand   %xmm3,%xmm1
   12002:	movdqa %xmm1,%xmm3
   12006:	pandn  %xmm0,%xmm3
   1200a:	por    %xmm1,%xmm3
   1200e:	movaps %xmm3,0x10(%rsp)
   12013:	jmp    11f5d <btree_iterator_curr+0x14d>
   12018:	nopl   0x0(%rax,%rax,1)
   12020:	mov    0xb8(%rbx),%rax
   12027:	movzwl 0x14(%rax),%edx
   1202b:	cmp    $0xffff,%dx
   1202f:	jne    11ed6 <btree_iterator_curr+0xc6>
   12035:	xor    %ecx,%ecx
   12037:	mov    $0xffffffffffffffff,%rsi
   1203e:	mov    $0x1,%edi
   12043:	jmp    11eec <btree_iterator_curr+0xdc>
   12048:	nopl   0x0(%rax,%rax,1)
   12050:	mov    0xb8(%rbx),%rcx
   12057:	jmp    11e65 <btree_iterator_curr+0x55>
   1205c:	nopl   0x0(%rax)
   12060:	xor    %ecx,%ecx
   12062:	mov    $0xffffffffffffffff,%rsi
   12069:	mov    $0x3,%edi
   1206e:	jmp    11eec <btree_iterator_curr+0xdc>

Disassembly of section .fini:
