# Read-path investigation, 2026-10-16

Production and both isolated variants start from commit
`b9cc3ea4ecfd523d799116798285fb2d7fe0bfaa`; original `src/btree.c` SHA256 is
`6ceb7b6ea8d9c72c4112433f8dde617a3818de832b3e6e411d5914e3fd419aab`.
The source archive and variant manifests retain exact identities. Production
sources and the sealed 2026-10-15 archives were not changed. Build/test/timing
execution is owned by the campaign coordinator, not this source-review task.

## Ready variants

* **rare-blob**: [patch](rare-blob.patch), [manifest](rare-blob.json).
  Moves only the parsed-blob scratch local and descriptor parser into a
  non-inlined helper, called after existing bounds/flags checks for blob
  messages. Full source export at
  `.cache/btree-nonlexical-20261016/variants/rare-blob`; resulting B-tree hash
  `ad4eed7076c4292752705edac380532a4629cb823bb48a71204bfbd9ce683988`.
* **decode-outline**: [patch](decode-outline.patch),
  [manifest](decode-outline.json). Independently moves the existing current
  highwater decode block into a non-inlined helper after successful leaf-entry
  validation. Allocation, growth, prefix-page tracking, suffix copy, cached
  data pointer/capacity, and failure propagation retain their existing behavior.
  It includes neither rare-blob nor an always-inline annotation. Source export
  at `.cache/btree-nonlexical-20261016/variants/decode-outline`; B-tree hash
  `3ffadf591ca0c35566506417052ae0bf384687d39d774b82294645c516b2a804`.

Decode outlining is a deliberate revisit under the user's stronger priority on
nonlexical performance. An earlier, different-source whole-database probe saved
about 9 instructions per nonlexical key but added about 23 per compressed key;
it was rejected for that tradeoff. Those historical figures are not predictions
for this isolated B-tree variant. The new probe retains the latest highwater
algorithm and makes the extra helper call only for stored compressed leaves.
No descriptor validation is removed by either variant.

## Assembly observations

[Assembly manifest](assembly/manifest.json) hashes the inspected binaries and
individual function listings. These are static observations, not runtime claims.

* Frozen main inlines entry validation in `btree_iterator_next`; the frozen
  candidate calls outlined `btree_iterator_check_current` instead.
* Uncompressed current iterators return keys directly from the pinned leaf;
  they do not allocate decode state or copy key bytes.
* The candidate's full leaf validation includes the prefix-reserved endpoint
  and reconstructed-key maximum, then tests prefix before any decode. `curr`
  adds a prefix load/test compared with main. Common `cache_validate_page`
  calls occur in both versions and are not new prefix overhead.
* The root-built rare-blob binary reduced `check_current` stack reservation
  from `0x58` to `0x08` bytes, but it remains outlined and saves the same four
  callee-saved registers. `next` remains `0x12a` bytes and `curr` `0x263` bytes.
  `check_current` shrank only from `0x2ff` to `0x2f4` bytes. Its ordinary inline
  message path is essentially unchanged. The hoped-for inlining effect did not
  occur; moving the stack local alone does not establish a performance gain.

* The root-built decode-outline binary inlines full validation into `next`
  (`0x38b` bytes) with three saved registers and `0x50` stack bytes. Uncompressed
  same-page advancement no longer calls `check_current`; compressed keys call
  the `0x101`-byte decode helper after validation. `curr` remains `0x263` bytes.
  This demonstrates the intended code-shape change, not a throughput benefit.
  The independent source review found state reload/failure handling, highwater
  reuse, prefix replacement, and zero-length suffix behavior unchanged.

The main/current pack append helpers are both outlined and both marshal
key/message descriptors through stack arguments. No claim here attributes a
regression to a newly introduced append call.

## Further designs, not implemented

Per-leaf validation constants are the simpler next source design if the small
probes leave a meaningful regression. Cache `payload_end = page_size - prefix`
and `max_suffix = MAX_INLINE_KEY_SIZE(page_size) - prefix` after header
validation, potentially as two uint32 fields. The existing header check proves
both subtractions valid; entry checks still enforce index/offset/header bounds,
key flags and finite length, full-key maximum, message flags/class and widened
key+message bounds, and blob parsing. An implementation must preserve the latter
checks exactly and benchmark the extra iterator fields against saved arithmetic.

All current sync/async paths that acquire a new iterator page pass through
`btree_iterator_copy_curr_if_needed` after checked header acquisition. The paths
are synchronous get-current (forward/reverse leaf movement), asynchronous
forward/reverse acquisition, synchronous lookup-based initial positioning/seek,
and asynchronous initial positioning. The reverse copied-memtable repair loop
also passes through it on each acquired successor. Refreshing constants there,
including the non-copy early-return path, avoids a per-key address check. Branch
headers are immutable while pinned; mutable pages retain their trusted/copied
behavior. A copied page must use the same validated metadata, and no failed
positioning operation may expose cached constants for another page.

A dedicated uncompressed-leaf ops table could additionally keep a small
zero-prefix validator and direct `curr` path in specialized functions. Searches
of src/tests found no cached B-tree ops pointer or external direct calls to
`btree_iterator_curr/next/prev`; iterator wrappers reload the table each call.
Nevertheless, this is a larger invariant surface and is deferred. Every
successful sync/async initial position, seek, range exhaustion, forward/reverse
page change, and mixed compressed/uncompressed transition would need correct
selection. Specialized same-page advancement would still validate every newly
exposed entry. Generic public entry points, mutable/index iterators, aliases to
returned keys during seek, prefetch transitions, and failure poisoning must
retain their current semantics. This is not an adopted optimization.

## Independent message-type algebra probe

The `message-type` variant ([patch](message-type.patch),
[manifest](message-type.json)) starts independently from b9cc3ea4 and changes
only the predicate in `btree_read_leaf_message`. Compile-time assertions require
invalid type zero and maximum valid type equal to the entire type mask. Under
those requirements, the existing allowed-bit check plus nonzero-type check
already accepts exactly all valid user types; the explicit type>maximum test is
redundant. Every bounds and blob-descriptor check remains in place.

The [standalone proof](message_type_proof.py) parses constants from the actual
headers and enumerates all 256 possible flag bytes. Its
[output](message-type-proof.json) confirms identical acceptance for exactly
`[1, 2, 3, 5, 6, 7]`. This is an exhaustive algebraic check of that byte predicate, not a substitute
for compiled/runtime validation. The coordinator has now built the variant and
passed its smoke checks. Performance measurements remain pending.

[Assembly observations](message-type-assembly.json) show that the ordinary
flag/type check shrinks from seven instructions after the flag load to four:
`cmp/ja + mov/and/sub/cmp/ja` becomes `test/je + cmp/ja`. This removes three
executed instructions while retaining the two conditional rejection branches.
There is no inlining change: `next` remains `0x12a` bytes, `curr` `0x263`, and
`check_current` `0x2ff`, saving four registers and reserving `0x58` stack bytes.
Padding keeps total checker size unchanged despite the shorter hot sequence.
The assembly finding does not yet establish a throughput benefit. Corruption
coverage is unchanged. Resulting
B-tree source SHA256 is
`36db9c735809788608cd0e91e617fb83fd29ff4f24a3f1d068eae6b7e26ecbdd`.

## Proposed combination

[combined-read-v1](combined-read-v1.md) combines decode outlining, message-type
validation algebra and callback-only checked search in a new source export.
It is formatted, frozen, independently source-reviewed, and built by the
coordinator. No selection or performance claim is made here. Independent
variants remain unchanged.

A separate [combined-read-blob-v1 proposal](combined-read-blob-v1.md) adds
rare-blob scratch outlining to the frozen combination. It preserves its parent
and is independently source-reviewed and built; it is not a selected alias.
[Compiled inspection](combined-assembly.md) confirms both combinations keep
validation inline in ordinary `next`. The blob combination reduces its saved
register count from three to two and local stack reservation from `0x50` to
`0x18`, while preserving the shorter message check and separate callback loop.
Measurement and full validation remain separate gates.
