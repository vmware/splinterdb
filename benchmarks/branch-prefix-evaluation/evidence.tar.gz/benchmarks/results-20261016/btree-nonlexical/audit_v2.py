#!/usr/bin/env python3
"""Independently audit explicit-profile B-tree campaigns; never starts a workload.

Run only after the campaign owner authorizes the final audit. Positional names
select campaigns; the default discovers all immediate manifest directories,
and every selected campaign must be complete. Exclusive
benchmark.lock and machine.lock prevent hashing alongside a measurement.
Inputs are read-only; the requested new JSON output is the only file written.
Ancillary archive files without original hashes are indexed as observed-only.
Version 2 recognizes named independent-review logs and verifies their report,
manifest, summary, reviewer, and stdout identities separately from benchmark logs.
No earlier archive, runner, analyzer, build, or benchmark source is executed.
"""

import argparse
from collections import defaultdict
import fcntl
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import time


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SEALED = ROOT / 'benchmarks/results-20261015/btree-prefix'
SCRATCH = ROOT / '.cache/btree-nonlexical-20261016'
COORD = Path('/home/rob/projects/splinterdb/.cache/projects-20261011/coordination')
ZERO_FIELDS = ('active_read_bytes', 'active_write_bytes', 'major_faults',
               'io_reads', 'io_writes', 'io_async_reads', 'io_async_writes')
CONFIG_FIELDS = ('operation', 'pattern', 'insert_order', 'keys', 'key_bytes',
                 'value_bytes', 'requested_ops', 'scan_length', 'batches',
                 'seed', 'cache_mib', 'disk_mib', 'cpu', 'miss')
WORK_FIELDS = ('operations', 'tuples', 'returned_tuples', 'processed_tuples',
               'checksum', 'expected_checksum', 'verified_tuples', 'verified_values')


class AuditError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise AuditError(message)


def integer(value, field, positive=False):
    require(type(value) is int and value >= (1 if positive else 0),
            f'{field}: expected a nonnegative/positive integer, got {value!r}')
    return value


def load(path):
    return json.loads(Path(path).read_text())


class Hashes:
    def __init__(self):
        self.files = {}

    def check(self, path, expected, role):
        path = Path(path).resolve()
        name = str(path)
        if name not in self.files:
            before = path.stat()
            digest = hashlib.sha256()
            with path.open('rb') as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(block)
            after = path.stat()
            identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns,
                                   s.st_ctime_ns)
            require(identity(before) == identity(after), f'File changed while hashing: {path}')
            self.files[name] = {'sha256': digest.hexdigest(), 'bytes': after.st_size,
                                'identity': list(identity(after)),
                                'roles': [], 'recorded_hash_checked': False}
        record = self.files[name]
        now = path.stat()
        require(record['identity'] == [now.st_dev, now.st_ino, now.st_size,
                                       now.st_mtime_ns, now.st_ctime_ns],
                f'Previously hashed file changed during audit: {path}')
        if role not in record['roles']:
            record['roles'].append(role)
        if expected is not None:
            require(record['sha256'] == expected, f'Hash mismatch: {path} ({role})')
            record['recorded_hash_checked'] = True
        return record['sha256']


def parse_perf(path):
    events = {}
    for line in path.read_text().splitlines():
        parts = line.split(';')
        if len(parts) < 5 or line.startswith('#'):
            continue
        event = parts[2].strip()
        require(event not in events, f'Duplicate perf event: {event}')
        value, coverage = float(parts[0]), float(parts[4])
        require(math.isfinite(value) and value >= 0, f'Invalid perf value: {event}')
        require(math.isfinite(coverage) and 99 <= coverage <= 100,
                f'Invalid/low perf coverage: {event}: {coverage}')
        events[event] = {'value': value, 'coverage': coverage}
    for event in ('cpu_core/cycles/u', 'cpu_core/instructions/u', 'task-clock'):
        require(events.get(event, {}).get('value', 0) > 0,
                f'Missing positive counter: {event}')
    return events


def expected_runs(plan):
    cases = plan['cases']
    require(cases and len({c['name'] for c in cases}) == len(cases),
            'Missing or duplicate planned cases')
    repeats = integer(plan.get('repeats', 6), 'plan/repeats', True)
    definitions = plan['profile_definitions']
    require(isinstance(definitions, dict) and definitions, 'Missing explicit profiles')
    for name, definition in definitions.items():
        require(isinstance(name, str) and name.replace('-', '').replace('_', '').isalnum(),
                'Invalid profile name')
        require(isinstance(definition['build'], str), 'Missing profile build')
        require(type(definition['compression']) is bool and type(definition['read_lexical']) is bool,
                'Profile flags must be explicit booleans')
    for case in cases:
        profiles = case['profiles']
        require(1 <= len(profiles) <= 3 and set(profiles) <= definitions.keys(),
                'Invalid or undefined case profiles')
        require(plan.get('purpose') == 'smoke' or repeats % math.factorial(len(profiles)) == 0,
                'Incomplete balanced profile schedule')
        comparisons = case.get('comparisons', plan.get('comparisons'))
        require(isinstance(comparisons, list), 'Missing explicit comparison list')
        applicable = []
        for pair in comparisons:
            require(isinstance(pair, list) and len(pair) == 2 and pair[0] != pair[1]
                    and set(pair) <= definitions.keys(), 'Invalid comparison pair')
            if set(pair) <= set(profiles):
                applicable.append(tuple(pair))
        require(len(applicable) == len(set(applicable)), 'Duplicate comparisons')
        require(applicable or len(profiles) == 1, 'No comparison for case')
    rows = []
    for repeat in range(repeats):
        rotated = cases[repeat % len(cases):] + cases[:repeat % len(cases)]
        for case in rotated:
            profiles = case['profiles']
            require(profiles and len(set(profiles)) == len(profiles),
                    f'Duplicate/empty profile list: {case["name"]}')
            order = list(itertools.permutations(profiles))
            for position, profile in enumerate(order[repeat % len(order)]):
                rows.append((case, repeat, position, profile))
    return rows


def expected_config(plan, case, repeat, profile, build):
    mapping = plan['profile_definitions'][profile]
    keys = plan.get('keys', 200000)
    length = case.get('scan_length', 10000)
    if length == 'full':
        length = keys
    config = dict(operation=case['operation'], pattern=case['pattern'],
                  insert_order=case.get('insert_order', 'random'), keys=keys,
                  key_bytes=plan.get('key_bytes', 64),
                  value_bytes=plan.get('value_bytes', 100),
                  requested_ops=case.get('ops', 1), scan_length=length,
                  batches=case.get('batches', 1),
                  seed=plan.get('seed', 20261015) + repeat,
                  cache_mib=plan.get('cache_mib', 512),
                  disk_mib=plan.get('disk_mib', 2048), cpu=plan.get('cpu', 2),
                  miss=case.get('miss', False),
                  prefix_supported=build['prefix_supported'],
                  pack_lexical=mapping['compression'], read_lexical=mapping['read_lexical'])
    require(type(build['prefix_supported']) is bool, 'Invalid prefix capability')
    require(build['prefix_supported'] or not (config['pack_lexical'] or config['read_lexical']),
            'Unsupported prefix flags')
    if case['pattern'] == 'nonlexical':
        require(not config['pack_lexical'] and not config['read_lexical'],
                'Nonlexical workload cannot opt into lexical behavior')
    return config


def validate_result(result, config):
    require(result.get('schema_version') == 1, 'Unknown result schema')
    require(result.get('verified') is True and result.get('resident') is True,
            'Run is not verified and resident')
    for field, expected in config.items():
        require(type(result[field]) is type(expected) and result[field] == expected,
                f'Result config mismatch: {field}')
    for field in ZERO_FIELDS:
        require(integer(result[field], field) == 0, f'Nonzero resident {field}')
    for field in ('active_wall_ns', 'process_cpu_ns', 'verified_tuples', 'verified_values'):
        integer(result[field], field, True)
    for field in ('checksum', 'expected_checksum'):
        integer(result[field], field)
    require(result['checksum'] == result['expected_checksum'], 'Checksum mismatch')
    require(result['verified_tuples'] == result['verified_values'],
            'Full-key and value verification counts differ')
    keys, batches, operation = config['keys'], config['batches'], config['operation']
    returned = processed = 0
    if operation in ('insert', 'overwrite'):
        ops = processed = keys * batches
    elif operation == 'pack':
        ops, processed = batches, keys * batches
    elif operation in ('lookup', 'scan'):
        ops = config['requested_ops'] * batches
        returned = (ops * config['scan_length'] if operation == 'scan'
                    else (0 if config['miss'] else ops))
    else:
        raise AuditError('Unsupported operation: ' + operation)
    for field, expected in dict(operations=ops, returned_tuples=returned,
                                processed_tuples=processed, tuples=returned+processed).items():
        require(integer(result[field], field) == expected, f'Incorrect work units: {field}')
    for field in ('packed_bytes', 'leaf_count', 'compressed_leaf_count', 'prefix_bytes'):
        integer(result[field], field)
    require(result['compressed_leaf_count'] <= result['leaf_count'], 'Invalid leaf census')
    if not config['pack_lexical'] or operation in ('insert', 'overwrite'):
        require(result['compressed_leaf_count'] == result['prefix_bytes'] == 0,
                'Unexpected compression in uncompressed or mutable workload')


def validate_command(run, config, build, folder, manifest):
    command = run['command']
    require(isinstance(command, list) and command
            and all(isinstance(v, str) for v in command),
            'Command is not an argv list')
    perf = manifest['perf_events'] is not None
    if perf:
        control = SCRATCH / (folder.name + '-' + run['label'] + '.control')
        ack = SCRATCH / (folder.name + '-' + run['label'] + '.ack')
        expected_prefix = ['perf', 'stat', '-x', ';', '-o',
                           str(folder / (run['label'] + '.stat')), '-e', manifest['perf_events'],
                           '-D', '-1', f'--control=fifo:{control},{ack}', '--']
        require(command[:len(expected_prefix)] == expected_prefix, 'Perf wrapper/scope mismatch')
        command = command[len(expected_prefix):]
    require(command, 'Missing benchmark command')
    require(Path(command[0]).resolve() == Path(build['binary']).resolve(), 'Binary argv mismatch')
    options, i = {}, 1
    while i < len(command):
        option = command[i]
        require(option.startswith('--') and option not in options, 'Duplicate/invalid argv option')
        if option == '--miss':
            options[option] = True
            i += 1
        else:
            require(i+1 < len(command), 'Missing argv option value')
            options[option] = command[i+1]
            i += 2
    expected = {
        '--operation': config['operation'], '--pattern': config['pattern'],
        '--compression': 'on' if config['pack_lexical'] else 'off',
        '--read-lexical': 'on' if config['read_lexical'] else 'off',
        '--keys': str(config['keys']), '--key-bytes': str(config['key_bytes']),
        '--value-bytes': str(config['value_bytes']), '--ops': str(config['requested_ops']),
        '--batches': str(config['batches']), '--seed': str(config['seed']),
        '--cache-mib': str(config['cache_mib']), '--disk-mib': str(config['disk_mib']),
        '--cpu': str(config['cpu']),
    }
    for key, value in expected.items():
        require(options.get(key) == value, f'Command config mismatch: {key}')
    require(options.get('--miss', False) == config['miss'], 'Miss argv mismatch')
    require(options.get('--insert-order', 'random') == config['insert_order'], 'Insert-order argv mismatch')
    length = options.get('--scan-length', '10000')
    require((config['keys'] if length == 'full' else int(length)) == config['scan_length'],
            'Scan length argv mismatch')
    allowed = set(expected) | {'--db', '--miss', '--insert-order', '--scan-length'}
    require(set(options) <= allowed and '--db' in options, 'Unexpected/unsafe benchmark option')
    require(Path(options['--db']).resolve() == SCRATCH / (folder.name + '-scratch.db'),
            'Scratch image location mismatch')


def audit_builds(builds, hashes):
    entries = {k: v for k, v in builds.items() if not k.startswith('_')}
    require(entries, 'Missing build metadata')
    require(len({v['source_sha256'] for v in entries.values()}) == 1,
            'Builds use different harness source')
    limitations = []
    for name, build in entries.items():
        source = Path(build['source']).resolve()
        require(source.is_relative_to(HERE) or source.is_relative_to(SEALED),
                'Harness is not a retained archive source')
        for field in ('binary', 'library', 'source', 'build_log'):
            hashes.check(build[field], build[field + '_sha256'], name + '/' + field)
        for filename, expected in build['source_files_sha256'].items():
            relative = Path(filename)
            require(not relative.is_absolute() and '..' not in relative.parts,
                    'Unsafe source inventory path')
            hashes.check(Path(build['tree']) / relative, expected, name + '/runtime-source')
        if 'Makefile' not in build['source_files_sha256']:
            hashes.check(Path(build['tree']) / 'Makefile', None, name + '/Makefile-observed-only')
            limitations.append(name + ': Makefile was not in the original recorded source inventory.')
        archive = source.parent
        if archive.is_relative_to(HERE / 'builds'):
            frozen_path = archive / 'build.json'
            frozen = load(frozen_path)
            require(all(build.get(k) == value for k, value in frozen.items()),
                    'Per-build and campaign build metadata differ: ' + name)
            hashes.check(frozen_path, None, name + '/per-build-metadata')
            before, after = load(archive / 'sources-before.json'), load(archive / 'sources-after.json')
            require(before == after == build['source_files_sha256'],
                    'Build source inventories differ: ' + name)
            for filename in ('sources-before.json', 'sources-after.json'):
                hashes.check(archive / filename, None, name + '/source-inventory')
            for filename, field in (('make.log', 'make_log_sha256'),
                                     ('invocation.json', 'invocation_sha256'),
                                     ('build_variants.py', 'build_helper_sha256')):
                recorded = build.get(field)
                hashes.check(archive / filename, recorded, name + '/' + filename)
                if recorded is None:
                    limitations.append(name + ': ' + filename + ' has no original file hash; indexed as observed-only.')
            invocation = load(archive / 'invocation.json')
            require(invocation['build'] == build['build_command']
                    and invocation['link'] == build['command'], 'Recorded build commands differ')
            hashes.check(invocation['source_metadata'], invocation['source_metadata_sha256'],
                         name + '/source-build-metadata')
        elif source.is_relative_to(SEALED):
            old_metadata = archive.parent / 'build.json'
            old = load(old_metadata)
            originals = [value for key, value in old.items() if not key.startswith('_')
                         and value.get('binary') == build['binary']]
            require(len(originals) == 1 and all(build.get(k) == value for k, value in originals[0].items()),
                    'Sealed original build entry differs: ' + name)
            hashes.check(old_metadata, None, name + '/sealed-build-metadata')
            meta = old['_build']
            require(meta['runtime_sources_unchanged'] is True, 'Sealed build changed runtime source')
            hashes.check(meta['runner'], meta['runner_sha256'], name + '/sealed-build-helper')
            hashes.check(meta['input_metadata'], meta['input_metadata_sha256'], name + '/sealed-build-input')
        else:
            raise AuditError('Unrecognized build archive: ' + str(source))
    return sorted(set(limitations))


def audit_supplemental_review(folder, hashes, manifest_sha256, run_count):
    """Recognize one named post-run review without treating it as a workload log."""
    report_path = folder / 'independent-review.json'
    log_path = folder / 'independent-review.log'
    if not report_path.exists():
        require(not log_path.exists(), 'Supplemental review log has no review report')
        return []
    review = load(report_path)
    require(review.get('passed') is True and review['runs'] == run_count,
            'Supplemental review failed or reviewed a different run count')
    require(review['manifest_sha256'] == manifest_sha256,
            'Supplemental review used a different manifest')
    hashes.check(report_path, None, 'supplemental-review-report-observed')
    hashes.check(folder / 'summary.json', review['summary_sha256'],
                 'supplemental-reviewed-summary')
    source_bindings = HERE / 'reviewer-sources.json'
    bindings = load(source_bindings)
    require(bindings['schema_version'] == 1, 'Unknown reviewer source binding schema')
    binding = bindings['sources'].get(review['review_source_sha256'])
    require(binding is not None, 'Review source hash has no recorded source path')
    relative = Path(binding['path'])
    require(not relative.is_absolute() and '..' not in relative.parts
            and (HERE / relative).resolve().is_relative_to(HERE),
            'Unsafe supplemental reviewer source path')
    hashes.check(source_bindings, None, 'supplemental-review-source-bindings-observed')
    hashes.check(HERE / relative, review['review_source_sha256'],
                 'supplemental-review-source')
    if log_path.exists():
        expected = dict(passed=True, runs=review['runs'],
                        coverage=review['minimum_counter_coverage_percent'],
                        comparisons=[dict(case=c['case'], comparison=c['comparison'],
                            throughput=c['metrics']['ops_s'],
                            instructions_pct=c['metrics']['user_instructions_per_operation']['percent_change'])
                            for c in review['comparisons']])
        require(load(log_path) == expected, 'Supplemental review stdout/report mismatch')
        hashes.check(log_path, None, 'supplemental-review-stdout-observed')
        return [log_path.name]
    return []


def audit_campaign(name, hashes):
    folder = HERE / name
    manifest = load(folder / 'manifest.json')
    require(manifest.get('complete') is True, 'Campaign is incomplete')
    require(manifest.get('final_build_identities_verified') is True,
            'Missing final build identity verification')
    plan = load(folder / 'plan.json')
    require(plan == manifest['plan'], 'Embedded and archived plans differ')
    require(plan['profile_definitions'] == manifest['profile_definitions'], 'Profile definitions differ')
    hashes.check(folder / 'manifest.json', None, 'campaign-manifest')
    for file, field in (('plan.json', 'plan_sha256'), ('runner.py', 'runner_sha256'),
                        ('analyze.py', 'analysis_sha256'), ('build.json', 'build_sha256')):
        hashes.check(folder / file, manifest[field], 'campaign-' + file)
    builds = load(folder / 'build.json')
    limitations = audit_builds(builds, hashes)
    expected = expected_runs(plan)
    runs = manifest['runs']
    require(len(runs) == len(expected), 'Run count differs from plan')
    groups = defaultdict(list)
    minimum_coverage = []
    for index, (run, (case, repeat, position, profile)) in enumerate(zip(runs, expected), 1):
        label = f'{index:04d}-r{repeat}-{case["name"]}-{profile}'
        require((run['label'], run['case'], run['repeat'], run['position'], run['profile'])
                == (label, case['name'], repeat, position, profile), 'Run order/identity mismatch')
        mapping = plan['profile_definitions'][profile]
        require(run['profile_definition'] == mapping and run['build'] == mapping['build'],
                'Recorded profile/build mapping differs')
        build = builds[mapping['build']]
        for run_field, build_field in (('binary_sha256', 'binary_sha256'),
                                       ('library_sha256', 'library_sha256'),
                                       ('harness_sha256', 'source_sha256'),
                                       ('prefix_supported', 'prefix_supported')):
            require(run[run_field] == build[build_field], 'Recorded run/build identity mismatch')
        config = expected_config(plan, case, repeat, profile, build)
        validate_command(run, config, build, folder, manifest)
        log = folder / (label + '.log')
        hashes.check(log, run['log_sha256'], 'run-log')
        records = [json.loads(line) for line in log.read_text().splitlines()
                   if line.startswith('{') and 'schema_version' in line]
        stat = folder / (label + '.stat')
        require(run.get('returncode') == 0 and not run.get('error'), 'Failed run in completed campaign')
        require(len(records) == 1 and records[0] == run['result'], 'Log/manifest result mismatch')
        result = records[0]
        validate_result(result, config)
        groups[case['name'], repeat].append(result)
        if manifest['perf_events'] is not None:
            hashes.check(stat, run['perf_sha256'], 'run-perf')
            counters = parse_perf(stat)
            require(counters == run['perf'], 'Raw/manifest perf mismatch')
            minimum_coverage.extend(v['coverage'] for v in counters.values())
        else:
            require(not stat.exists() and not run.get('perf'), 'Unexpected perf in no-perf campaign')
    for group, results in groups.items():
        reference = {k: results[0][k] for k in CONFIG_FIELDS + WORK_FIELDS}
        require(all({k: r[k] for k in reference} == reference for r in results[1:]),
                f'Profiles used different logical work/configuration: {group}')
    expected_logs = {r['label'] + '.log' for r in runs}
    expected_stats = ({r['label'] + '.stat' for r in runs}
                      if manifest['perf_events'] is not None else set())
    supplemental_logs = audit_supplemental_review(
        folder, hashes, hashes.check(folder / 'manifest.json', None, 'campaign-manifest'), len(runs))
    require({p.name for p in folder.glob('*.log')} == expected_logs | set(supplemental_logs),
            'Unrecorded/missing benchmark or supplemental review log files')
    require({p.name for p in folder.glob('*.stat')} == expected_stats, 'Unrecorded/missing perf files')
    summary = folder / 'summary.json'
    if summary.exists():
        provenance = load(summary)['provenance']
        require(provenance['manifest_sha256'] == hashes.check(folder / 'manifest.json', None, 'campaign-manifest'),
                'Summary used a different manifest')
        require(provenance['analysis_sha256'] == manifest['analysis_sha256'],
                'Summary used a different analyzer source')
        hashes.check(summary, None, 'analysis-output-observed')
    return {
        'name': name, 'passed': True, 'complete': True,
        'runs': len(runs), 'validated_runs': len(runs),
        'cases': len(plan['cases']), 'repeats': plan.get('repeats', 6),
        'paired_groups_checked': len(groups),
        'supplemental_review_logs': supplemental_logs,
        'minimum_counter_coverage_percent': min(minimum_coverage) if minimum_coverage else None,
        'manifest_sha256': hashes.check(folder / 'manifest.json', None, 'campaign-manifest'),
        'provenance_limitations': limitations,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('campaigns', nargs='*')
    parser.add_argument('--output', type=Path, default=HERE / 'audit.json')
    args = parser.parse_args()
    require(not args.output.exists(), 'Refusing to overwrite an existing audit')
    if not args.campaigns:
        args.campaigns = sorted(p.name for p in HERE.iterdir() if (p / 'manifest.json').is_file())
    require(args.campaigns, 'No campaigns selected')
    require(len(set(args.campaigns)) == len(args.campaigns), 'Duplicate campaign arguments')
    for name in args.campaigns:
        require(name.replace('-', '').replace('_', '').isalnum(), 'Invalid campaign name')
    report = {'schema_version': 1, 'started': time.time(), 'campaigns': [], 'errors': [],
              'coordination': 'Exclusive benchmark.lock then machine.lock; no workloads launched',
              'scope': 'Plans, source/artifact identities, result integrity, work units, resident guards, paired work, and raw perf; no performance significance claim',
              'paired_config_fields': list(CONFIG_FIELDS),
              'paired_work_fields': list(WORK_FIELDS),
              'paired_exceptions': 'Pack/read lexical flags and prefix-support capability are checked against each profile/build instead of requiring equality. Timing, counters, and physical tree census are outcomes, not paired logical-work invariants.'}
    hashes = Hashes()
    try:
        os.sched_setaffinity(0, {19})
    except OSError as error:
        report['affinity_note'] = str(error)
    print('Waiting for exclusive benchmark.lock and machine.lock', flush=True)
    with (COORD / 'benchmark.lock').open('rb') as bench, (COORD / 'machine.lock').open('rb') as machine:
        fcntl.flock(bench, fcntl.LOCK_EX)
        fcntl.flock(machine, fcntl.LOCK_EX)
        for name in args.campaigns:
            try:
                report['campaigns'].append(audit_campaign(name, hashes))
            except (AuditError, OSError, KeyError, TypeError, ValueError, IndexError,
                    OverflowError) as error:
                report['errors'].append({'campaign': name, 'error': repr(error)})
        # Retain observed hashes for ancillary plans/reports/build logs without
        # presenting them as hashes recorded before their original execution.
        for path in sorted(HERE.rglob('*')):
            if path.is_file() and path.resolve() != args.output.resolve():
                try:
                    require(not path.is_symlink(), 'Unexpected archive symlink: ' + str(path))
                    hashes.check(path, None, 'archive-file-observed')
                except (AuditError, OSError) as error:
                    report['errors'].append({'file': str(path), 'error': repr(error)})
        # Detect any earlier artifact changed after its first read in this audit.
        for filename in tuple(hashes.files):
            try:
                hashes.check(filename, None, 'final-identity-recheck')
            except (AuditError, OSError) as error:
                report['errors'].append({'file': filename, 'error': repr(error)})
        report.update(finished=time.time(), passed=not report['errors'], files=hashes.files)
        report['counts'] = {
            'campaigns_requested': len(args.campaigns),
            'campaigns_passed': len(report['campaigns']),
            'validated_runs': sum(c['validated_runs'] for c in report['campaigns']),
            'unique_files_hashed': len(hashes.files),
            'files_with_recorded_hash_checked': sum(f['recorded_hash_checked'] for f in hashes.files.values()),
            'files_observed_only': sum(not f['recorded_hash_checked'] for f in hashes.files.values()),
        }
        report['auditor_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        with args.output.open('x') as stream:
            json.dump(report, stream, indent=2, allow_nan=False)
            stream.write('\n')
    print(json.dumps({'output': str(args.output), 'passed': report['passed'],
                      'counts': report['counts'], 'errors': report['errors']}, indent=2))
    raise SystemExit(0 if report['passed'] else 1)


if __name__ == '__main__':
    main()
