# Nonlexical B-tree performance investigation — 2026-10-16

Implemented and validated. The read changes recovered the nonlexical long-scan
regression: their direct comparison with the original candidate improved
10,000-key scans by 4.25% and full scans by 4.93%. The final candidate, including
an alignment repair exposed by validation, has all nine nonlexical throughput
estimates within 0.9% of frozen main. Every final nominal 95% interval has its
lower end above −2.1%. No remaining nonlexical throughput regression above the
requested 2–3% range is apparent in these resident workloads.

This is an exploratory, single-machine investigation with nominal per-case
intervals, not a universal or simultaneous equivalence guarantee. Residual
instruction overhead and lexical costs remain. All planned measurements are
complete; the source changes are applied in the working tree, without a commit
or merge. The original failed sanitizer logs and successful repair checks are
retained.

This campaign prioritizes avoiding performance regressions for custom,
nonlexical sort orders. The prior [resident B-tree evaluation](../../results-20261015/btree-prefix/README.md)
found a 4.61% throughput loss for nonlexical 10,000-key scans versus main,
with a nominal 95% paired interval of −5.58% to −3.63%. Full scans and some
smaller operations had less conclusive losses. Uncompressed iteration already
returns keys directly from the page; key reconstruction is not its cost.
Both builds have the same nonlexical packed geometry: 36,835,328 bytes and
8,696 leaves for this input. The resident regression therefore concerns CPU
work rather than extra pages or reconstructed keys.

The starting candidate is `b9cc3ea4ecfd523d799116798285fb2d7fe0bfaa` and the
frozen main reference is `6105c49f66a24d3006ba0464d9558b52e692e27c`.
The old evidence archive is retained unchanged. New variants are separate
source exports. The final implementation is `selected-io-alignment`, which
combines `combined-read-blob-v1` with the validated I/O alignment repair. The
pack proposals and unmeasured `zero-prefix-callback` contingency are not selected.

## Final candidate against main

Positive throughput changes are faster. Eight rows use six paired repetitions
from the 180-sample final-source confirmation. Random insertion uses a separate
fixed 18-pair follow-up because its first six pairs had a wide interval. The
earlier result, −1.04% [−3.95, +1.97], remains in its original archive; no pairs
were excluded or pooled between campaigns.

| Nonlexical operation | Final / main | Nominal 95% interval | Pairs |
| --- | ---: | ---: | ---: |
| Random insert | −0.26% | [−0.84%, +0.33%] | 18 |
| Sorted insert | +0.74% | [−2.07%, +3.64%] | 6 |
| Overwrite | −0.38% | [−1.82%, +1.08%] | 6 |
| Pack from array | −0.89% | [−1.83%, +0.06%] | 6 |
| Point hit | +0.30% | [−0.88%, +1.50%] | 6 |
| Point miss | −0.31% | [−1.14%, +0.54%] | 6 |
| One-key scan | −0.70% | [−1.85%, +0.46%] | 6 |
| 10,000-key scan | +0.90% | [−0.90%, +2.73%] | 6 |
| Full 200,000-key scan | +0.40% | [−0.73%, +1.54%] | 6 |

The final binary's instructions match the preceding selected binary in every
case. Its compressed lexical full-scan control is −0.99% [−2.74, +0.80] versus
main and +0.41% [−0.71, +1.54] versus the preceding selected binary. Other lexical
operations were not retimed after the alignment repair; their separately
identified read-optimization measurements appear below.

See [final results with absolute rates](final-results.csv),
[final selection](final-selection.json),
[180-sample analysis](confirmation-aligned/summary.json), and
[18-pair insertion analysis](confirmation-aligned-random-insert/summary.json).
Both final campaigns passed all measurement and correctness guards; no further
performance specialization was justified by the measured nonlexical results.

## Read optimization confirmation before the alignment repair

Each cell is a throughput percentage change; positive is faster. Selected/main
intervals are nominal 95% intervals from six paired repetitions. The original
and selected builds were compared with main in the same campaign, using all
six profile orders and rotating workload order.

| Nonlexical operation | Original / main | Selected / main [95% interval] | Selected / original |
| --- | ---: | ---: | ---: |
| Random insert | +0.91% | +0.82% [−0.57, +2.22] | −0.10% |
| Sorted insert | +0.13% | +0.91% [−0.49, +2.33] | +0.78% |
| Overwrite | −0.11% | −0.63% [−1.42, +0.18] | −0.52% |
| Pack from array | −1.14% | +1.16% [−0.68, +3.04] | +2.32% |
| Point hit | +0.07% | +0.86% [−1.85, +3.64] | +0.79% |
| Point miss | +0.15% | +0.38% [−1.38, +2.18] | +0.23% |
| One-key scan | −1.53% | −0.45% [−2.40, +1.54] | +1.09% |
| 10,000-key scan | −3.87% | +0.22% [−1.44, +1.90] | +4.25% |
| Full 200,000-key scan | −4.57% | +0.13% [−1.50, +1.79] | +4.93% |

The long-scan improvements versus the original are resolved: +4.25%
[+2.95, +5.56] and +4.93% [+2.94, +6.96]. Selected instruction counts are 4.18%
lower for both scans, though still about 2.34% above main. Hits, misses and
one-key scans retain about 3.47–3.64% more instructions than main, without a
resolved throughput loss. The selected code does not change insertion or
packing algorithms, and their instruction counts match the original; the pack
timing gain is not evidence of a newly optimized pack algorithm. No further
point-search specialization was adopted once the measured nonlexical target
was met.

See the [complete paired analysis](confirmation/summary.json),
[independent arithmetic review](confirmation/independent-review.json), and
[exact plan](confirmation/plan.json). All 378 samples passed correctness,
residency and measurement guards, with no exclusions or retries.

## Lexical tradeoffs retained

These controls use the lexical flag on the candidate and selected builds.
Common-prefix keys compress; random lexical keys do not. Results are direct
selected/main comparisons in the same confirmation campaign.

| Operation | Common-prefix lexical [95% interval] | Random lexical [95% interval] |
| --- | ---: | ---: |
| Pack from array | −7.53% [−8.54, −6.50] | −0.18% [−1.35, +1.01] |
| Point hit | +2.00% [+1.31, +2.69] | +1.51% [+0.17, +2.88] |
| Point miss | +6.20% [+4.45, +7.99] | +5.23% [+2.63, +7.90] |
| One-key scan | +4.26% [+3.32, +5.20] | +5.77% [+3.32, +8.29] |
| 10,000-key scan | −5.49% [−6.59, −4.38] | +2.17% [+0.48, +3.89] |
| Full scan | −0.73% [−6.30, +5.19] | −0.91% [−1.95, +0.15] |

Common-prefix pack and 10,000-key scan costs remain material relative to main.
They largely predate these read changes: selected/original is −0.32%
[−1.94, +1.34] for packing and −0.39% [−1.52, +0.75] for 10,000-key scans.
Common-prefix full scans show an additional cost of about 2–3%: −2.27%
[−3.98, −0.53] in the combination screen and −2.59% [−5.13, +0.01] in
confirmation. The direct-main full-scan interval is wide, so its near-zero
estimate does not establish neutrality. This tradeoff is accepted under the
user's priority on nonlexical performance. On-disk benefits are not measured
by this resident campaign.

## Experiments

| Variant | Hypothesis | Initial code-generation observation |
| --- | --- | --- |
| `rare-blob` | Keep blob-descriptor scratch outside ordinary message validation | Validator stack frame shrinks from 0x58 to 0x08 bytes, but it remains outlined |
| `decode-outline` | Move compressed-key reconstruction into a helper so ordinary validation can inline | Validation now inlines into next; three saved registers replace the nested validator call |
| `callback-search` | Choose a callback-only binary-search loop once per nonlexical leaf | Removes a repeated lexical-mode decision in source; performance unproven |
| `lazy-pivot` | Initialize a pivot key buffer only when a compressed leaf needs reconstruction | Targets setup once per linked page |
| `prefix-scratch` | Qualify a prefix before entering the page-rewrite helper | Primarily a lexical control; nonlexical eligibility already returns before scratch setup |
| `message-type` | Use the flag mask's existing type bound to simplify validation | All 256 flag bytes exhaustively checked for predicate equivalence |

The decode-helper split revisits a previously rejected whole-database tradeoff:
it reduced nonlexical work but added work to compressed scans. The user's revised
priority warrants a direct B-tree measurement of both effects. No corruption
check or malformed-blob parsing is intentionally removed by any proposal.

## Applied implementation

The working tree contains four read-path changes in
[`src/btree.c`](../../../src/btree.c):

* Compressed-key reconstruction lives in a separate non-inlined helper. This
  makes the ordinary entry checker small enough to inline into advancement.
* Blob-descriptor parsing has its own non-inlined helper, keeping its scratch
  space out of inline-message validation.
* Leaf search chooses callback or lexical comparison before its binary-search
  loop. Checked key reads still precede every custom-comparator call.
* Message validation uses the flag mask's existing type bound, with static
  assertions protecting the enum assumptions. All 256 flag bytes were checked
  for equivalence with the original predicate.

Bounds checks, key limits, flags, malformed-blob parsing and error propagation
remain. Nonlexical iterator keys still reference the page directly; there is
no added decoded-key allocation or iterator-layout change. The alignment
repair in the Linux I/O implementation is separately explained below.

[`application.json`](application.json) records the applied patch and source
hashes. Runtime sources match the frozen repaired build except for one
preexisting brace-placement correction in `btree.c`; that correction changes
only whitespace. The regression test matches the validated test overlay
exactly. The four changed files pass `clang-format-19 --Werror --dry-run`, and
`git diff --check` passes. All 203 maintained tracked C/header files also pass
formatting when archived history is excluded. The repository-wide formatting
script still fails on archived source copies, including two preexisting tracked
historical benchmark files; these inputs are preserved. See
[the full check](format-check-final.json), [tracked check](format-check-tracked.json)
and [maintained-source check](format-check-maintained.json). Final performance
confirmation and the focused random-insert precision check are complete.

## Controls

The harness and fixed-work counts come from the completed resident campaign:
one worker on CPU2, 200,000 64-byte keys, 100-byte values, a 512 MiB cache,
and an array input iterator for packing. Builds and measurements use shared
machine/benchmark locks, with no overlapping workloads. Input, correctness and
residency checks remain unchanged. Each profile explicitly identifies its
binary, packing flag and lexical-read flag; nonlexical cases disable both flags.

Screening uses adjacent paired runs in balanced AB/BA order. Confirmation
compares selected code directly with both the original candidate and main,
including inserts, overwrites, point reads, scans and packing. Lexical controls
quantify any resulting tradeoff. Timed binaries and libraries remain immutable;
correctness builds use separate output directories.

The compiler is GCC 14.2 with the existing release `-O3`, LTO and native-CPU
configuration, on an Intel i7-12800H. The cache limit is not a whole-process
memory limit. Each measured sample follows full key/value verification,
warming and I/O draining; timed reads, writes, asynchronous I/O and major
faults must all be zero. Hardware instruction and cycle counters bracket the
active interval, including timer and FIFO-control overhead, with 100% coverage
required. Fixed work comes from the
prior calibration and is identical between profiles in each pair.

Insertion and overwrite use mutable B-trees. Point queries and scans use
packed immutable B-trees. Scan timing includes iterator initialization and
deinitialization; packing includes the pack computation but excludes input
generation, sorting, pack-request setup, validation and reclamation. The array
input iterator prevents B-tree scan costs from contaminating pack results.
The timed consumer performs a checksum; a full key/value oracle runs outside
timing. All valid pairs are retained, including unusually large differences.

These experiments measure resident, single-worker, inline-value workloads.
They do not measure disk throughput, concurrent scaling, asynchronous lookup
throughput or blob-heavy workloads. Custom ordering compares trailing ordinal
bytes, common lexical keys share a 48-byte prefix, and random lexical keys
produce no compressed leaves. Absolute rates across these patterns are not
controlled comparisons because their input-array locality differs. Intervals
are nominal 95% paired log-ratio intervals, not simultaneous guarantees of
equivalence across workloads.

## Completed screening

`rare-blob` completed 72 samples. Relative to the starting candidate,
nonlexical 10,000-key scan throughput changed by +1.27% (nominal 95% interval
+0.17% to +2.38%), full scans by +1.67% (−0.22% to +3.60%), and other measured
operations stayed near zero. Long-scan user-mode instruction counts were
unchanged. This did not by itself eliminate the regression against main;
it was adopted only after the combination and direct-main confirmations. See its
[paired analysis](screen-rare-blob/summary.json).

`decode-outline` completed 84 samples. Nonlexical 10,000-key scans improved
1.88% (+0.83% to +2.94%) and full scans improved 2.61% (+0.21% to +5.06%)
relative to the starting candidate. User-mode instructions per returned key
fell about 2.08%. Compressed lexical full scans showed no resolved throughput
change (−0.12%, −0.67% to +0.44%), despite about 5.03% more instructions.
Compressed 10,000-key scans improved 2.01% (+0.48% to +3.57%) in this sample.
These results justified the subsequent combination screen; this isolated
screen did not establish performance relative to main. See its
[paired analysis](screen-decode-outline/summary.json).

`callback-search` completed 84 samples. Nonlexical misses improved 1.19%
(+0.26% to +2.13%) and one-key scans improved 1.32% (+0.14% to +2.51%).
Hits changed +2.36% (−1.44% to +6.30%); one unusually large paired gain
(10.05%) was retained, so the hit timing is not conclusive.
User instructions fell 1.53%, 1.68% and 2.10% for hits, misses and one-key
scans respectively. Long-scan throughput was essentially unchanged. See its
[paired analysis](screen-callback-search/summary.json). This proposal addresses
short reads, separately from the decode-helper proposal's scan effect.

`lazy-pivot` completed 36 samples and is not selected. Nonlexical pack
throughput changed −1.17% (−2.35% to +0.02%), common-prefix lexical pack
changed −1.19% (−1.94% to −0.45%), and random lexical pack changed +1.01%
(−2.03% to +4.14%). Avoiding buffer setup reduced nonlexical instructions
about 0.65%, but did not demonstrate a throughput benefit. See its
[paired analysis](screen-lazy-pivot/summary.json).

`prefix-scratch` completed 36 samples and is not selected. Nonlexical pack
changed −0.43% (−1.57% to +0.73%), common-prefix lexical pack changed −3.00%
(−4.73% to −1.24%), and random lexical pack changed −2.75% (−4.05% to −1.42%).
Instructions increased in all three cases. Moving the rewrite into a helper
did not improve these workloads. See its
[paired analysis](screen-prefix-scratch/summary.json).

`message-type` completed 84 samples. Nonlexical 10,000-key and full scans
changed −0.03% (−1.77% to +1.75%) and +0.08% (−1.19% to +1.37%), despite
about 1.26% fewer user instructions per key. Short-read timings were also
unresolved. Compressed lexical 10,000-key scans improved 0.68% (+0.19% to
+1.18%); full scans had a wide interval influenced by a retained large pair.
This is a combination candidate on code simplicity and work reduction, not
an established nonlexical throughput improvement. See its
[paired analysis](screen-message-type/summary.json).

## Combined read changes

The 54-sample direct combination screen compared the original candidate,
`combined-read-v1` (decode outlining, callback search, message-type check),
and `combined-read-blob-v1` (those changes plus blob-validation outlining).
All six profile orders were used. Throughput changes below use nominal 95%
paired intervals; they are direct comparisons, not products of screen results.

| Case | Read changes / original | Read + blob helper / original | Additional blob helper / read changes |
| --- | ---: | ---: | ---: |
| Nonlexical 10,000-key scan | +1.35% [−0.31, +3.03] | +5.21% [+4.02, +6.41] | +3.81% [+2.36, +5.29] |
| Nonlexical full scan | +3.14% [+0.91, +5.42] | +5.00% [+2.89, +7.15] | +1.81% [+0.72, +2.91] |
| Common-prefix lexical full scan | −0.19% [−2.03, +1.69] | −2.27% [−3.98, −0.53] | −2.09% [−3.37, −0.80] |

The blob combination was selected provisionally for confirmation, following the user's
explicit priority on nonlexical performance. Its lexical full-scan loss is a
measured tradeoff, not neutrality. Nonlexical long-scan instructions fall 4.18%
versus the original. [Compiled evidence](read-design/combined-assembly.md)
confirms that ordinary validation inlines and blob outlining saves one register
and 56 bytes of local stack space in `next`; the latter is per-call stack usage,
not a new allocation per iterator. No iterator layout changes are proposed.

See the [paired analysis](screen-combinations/summary.json),
[independent arithmetic review](screen-combinations/independent-review.json),
and [initial selection record](selection.json). The complete confirmation
results above supersede this screen for the final nonlexical comparison.

All eight built variants passed their 18-case reduced correctness/residency
smoke campaigns (144 samples). The selected combination also passed 87 release
test executions: full B-tree and quick suites, plus focused core and stress
tests. Its test overlay adds a nonlexical immutable-branch regression covering
custom comparator/hash behavior, synchronous and asynchronous lookups, forward
and reverse iteration, absent bounds, and rejection of malformed keys before
the custom comparator runs. Invalid message types and reserved flag bits are
also checked. Runtime sources and timed artifacts remained unchanged during
validation. Debug passed another 87 executions and fault injection passed 36.
The sanitizer stage passed 21 executions before finding the preexisting
alignment defect described below. See the
[release validation](validation/combined-read-blob-v1-preconfirmation-release/summary.json)
and [additional validation](validation/combined-read-blob-v1-postconfirmation-extra/summary.json).

## Alignment defect exposed by validation

The new custom-comparator regression opens a cold packed branch before its
direct lookup probes. ASan/UBSan reported a misaligned `laio_async_state` during
that initial asynchronous cache read: the backend needs eight-byte alignment,
but `io_async_state_buffer` was a byte array with alignment one. Its member in
`clockcache_get_async_state` followed a four-byte status field, placing it at
offset 116 (four modulo eight). Aligning the outer state does not align that
member. This is a production storage declaration issue, not a malformed test
pointer.

The exact failure reproduced on the original candidate with the same test
overlay and sanitizer configuration. Frozen main contains the same unaligned
typedef. The original [selected failure](validation/combined-read-blob-v1-postconfirmation-extra/summary.json)
and [baseline reproduction](validation/baseline-alignment-reproduction/summary.json)
are retained. The isolated repair aligns the opaque buffer to `max_align_t`
and adds a backend static assertion that its required alignment fits. The
buffer remains 1,024 bytes and keeps its byte-array API. On this build, the
enclosing cache-read state grows from 1,192 to 1,200 bytes, within its fixed
2,048-byte payload; the separate I/O state wrapper grows from 1,032 to 1,040
bytes. No B-tree iterator layout changes.

The repair passed all 36 focused ASan/UBSan test executions and the new cold
custom-comparator regression in release, debug and fault-injection builds
(39 executions total). No alignment suppression was used. LeakSanitizer was
disabled as in the earlier validation configuration; ASan and UBSan remained
enabled. See [repair validation](alignment-diagnosis/repair-validation/summary.json).
A direct nonlexical performance recheck is complete; it does not overwrite
the preceding read-optimization confirmation.

The repaired binary also passed 18 reduced correctness/residency smoke samples.
Its 180-sample confirmation completed with all guards passing: nine nonlexical
workloads plus the compressed full-scan control, each with main, the previous
selected binary and the repaired binary in all six orders. Long scans remain
near main (+0.90% for 10,000 keys and +0.40% for full scans). The random-insert
estimate was −1.04% [−3.95, +1.97], so an additional fixed 18-pair comparison
tested that uncertainty. It measured −0.26% [−0.84, +0.33], resolving the
2–3% concern for this workload. No samples were discarded or pooled between
campaigns.

## Evidence and reproduction

The archive includes 1,206 samples across 19 campaigns: nine 18-case smoke
campaigns, six isolated screens, one combination screen, and three confirmation
campaigns. The frozen harness,
compiler/link commands, source and artifact hashes, explicit profiles,
per-sample checksums, raw timing/counters and paired analyses are retained.
See [build identities](build.json), [source application](application.json),
[campaign audit](audit-campaigns-final.json), and
[validation/source audit](audit-final.json). Historical failures retain their
failed status; the audit checks their reproduction and subsequent repair.

The exact plans are [read confirmation](confirmation-plan.json),
[final-source confirmation](confirmation-aligned-plan.json), and
[focused insertion confirmation](confirmation-aligned-random-insert-plan.json).
To repeat a campaign using the retained frozen binaries on this machine,
choose a fresh output name; the runner refuses to replace an existing result:

```sh
python3 benchmarks/results-20261016/btree-nonlexical/runner.py --plan benchmarks/results-20261016/btree-nonlexical/confirmation-aligned-plan.json --name confirmation-aligned-repeat
python3 benchmarks/results-20261016/btree-nonlexical/analyze.py benchmarks/results-20261016/btree-nonlexical/confirmation-aligned-repeat/manifest.json benchmarks/results-20261016/btree-nonlexical/confirmation-aligned-repeat/summary.json
```

Rebuilding should use a new source export and output directory, preserving the
recorded binaries. The [audit plan](final-audit-plan.md) explains verification,
including the original sanitizer failure and the formatting-only source delta.
The conclusion is limited to resident, single-worker B-tree throughput with
these key distributions and inline values; disk, concurrent and blob-heavy
performance remain outside this campaign.
