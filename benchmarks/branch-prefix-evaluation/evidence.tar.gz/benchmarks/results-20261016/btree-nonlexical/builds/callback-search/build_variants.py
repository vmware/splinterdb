#!/usr/bin/env python3
"""Build isolated B-tree probes without changing measured baseline artifacts."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SCRATCH = ROOT / '.cache/btree-nonlexical-20261016'
COORD = Path('/home/rob/projects/splinterdb/.cache/projects-20261011/coordination')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def sources(tree):
    return {str(p.relative_to(tree)): sha(p)
            for folder in ('src', 'include', 'tests')
            for p in sorted((tree / folder).rglob('*')) if p.is_file()}


def save(path, value):
    temporary = path.with_suffix('.new')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def invoke(command, tree, log, environment):
    proc = None
    with log.open('x') as stream:
        try:
            proc = subprocess.Popen(command, cwd=tree, env=environment,
                                    stdout=stream, stderr=subprocess.STDOUT,
                                    start_new_session=True)
            status = proc.wait(timeout=1200)
            if status:
                raise RuntimeError(f'Exit {status}: see {log}')
        except BaseException:
            if proc is not None:
                for sig in (signal.SIGTERM, signal.SIGKILL):
                    try:
                        os.killpg(proc.pid, sig)
                    except ProcessLookupError:
                        pass
                    try:
                        proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        pass
                proc.wait()
            raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('names', nargs='+')
    args = parser.parse_args()
    HERE.mkdir(parents=True, exist_ok=True)
    SCRATCH.mkdir(parents=True, exist_ok=True)
    old_path = ROOT / 'benchmarks/results-20261015/btree-prefix/build-v2/build.json'
    old = json.loads(old_path.read_text())
    output = HERE / 'build.json'
    builds = json.loads(output.read_text()) if output.exists() else {
        'main': old['main'], 'baseline': old['current']}
    print('Waiting for exclusive machine lock', flush=True)
    with (COORD / 'machine.lock').open('rb') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        for name in args.names:
            assert name.replace('-', '').replace('_', '').isalnum(), name
            if name in builds:
                raise RuntimeError(f'Refusing to overwrite frozen build {name}')
            tree = SCRATCH / 'variants' / name
            if not (tree / 'Makefile').exists():
                raise RuntimeError(f'Missing complete source tree: {tree}')
            archive = HERE / 'builds' / name
            archive.mkdir(parents=True, exist_ok=False)
            before = sources(tree)
            save(archive / 'sources-before.json', before)
            harness = archive / 'btree_prefix_bench.c'
            harness.write_bytes((ROOT / 'benchmarks/btree_prefix_bench.c').read_bytes())
            (archive / 'build_variants.py').write_bytes(Path(__file__).read_bytes())
            started = time.time()
            build_command = ['make', '-j6', 'BUILD_MODE=release', 'libs']
            library = tree / 'build/release/lib/libsplinterdb.a'
            binary = SCRATCH / (name + '-btree-prefix-bench')
            if binary.exists():
                raise RuntimeError(f'Refusing to overwrite {binary}')
            command = [str(harness) if v == old['current']['source'] else
                       str(library) if v == old['current']['library'] else
                       str(binary) if v == old['current']['binary'] else
                       v.replace(old['current']['tree'] + '/', str(tree) + '/')
                       for v in old['current']['command']]
            save(archive / 'invocation.json', {'build': build_command, 'link': command,
                 'started': started, 'source_metadata': str(old_path),
                 'source_metadata_sha256': sha(old_path),
                 'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()})
            with tempfile.TemporaryDirectory(prefix='build-' + name + '-', dir=SCRATCH) as tmp:
                environment = dict(os.environ, TMPDIR=tmp)
                print('Building ' + name, flush=True)
                invoke(build_command, tree, archive / 'make.log', environment)
                invoke(command, tree, archive / 'link.log', environment)
            after = sources(tree)
            save(archive / 'sources-after.json', after)
            assert before == after, 'Source changed while building'
            builds[name] = dict(tree=str(tree), library=str(library),
                library_sha256=sha(library), source_files_sha256=after,
                binary=str(binary), binary_sha256=sha(binary), source=str(harness),
                source_sha256=sha(harness), prefix_supported=True,
                command=command, build_command=build_command,
                compiler=subprocess.check_output(['cc', '--version'], text=True),
                build_log=str(archive / 'link.log'), build_log_sha256=sha(archive / 'link.log'),
                started=started, finished=time.time())
            save(archive / 'build.json', builds[name])
            save(output, builds)
            print('Built ' + name, flush=True)


if __name__ == '__main__':
    def interrupted(signum, frame):
        raise KeyboardInterrupt(f'signal {signum}')
    signal.signal(signal.SIGTERM, interrupted)
    main()
