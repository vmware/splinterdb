#!/usr/bin/env python3
"""Freeze current sources and validate persisted old-version rejection."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time

ROOT = Path.cwd()
ARCHIVE = ROOT / 'benchmarks/results-20261016/branch-prefix-merge-prep/version-rejection'
SCRATCH = ROOT / '.cache/branch-prefix-merge-prep/version-rejection'
LOCK = Path('/home/rob/projects/splinterdb/.cache/projects-20261011/coordination/machine.lock')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')

def manifest(tree):
    paths = [tree / 'Makefile', tree / '.clang-format']
    for name in ('src', 'include', 'tests'):
        paths.extend(p for p in (tree / name).rglob('*') if p.is_file())
    return {str(p.relative_to(tree)): digest(p) for p in sorted(paths)}

records = []
env = {k: v for k, v in os.environ.items() if k not in (
    'CFLAGS', 'LDFLAGS', 'MAKEFLAGS', 'MFLAGS', 'CC', 'CXX', 'BUILD_MODE',
    'BUILD_ROOT', 'BUILD_ASAN', 'BUILD_MSAN', 'BUILD_MEMORY_FAULT_INJECTION')}

def run(name, argv, cwd, stage_env, expected=None):
    logfile = ARCHIVE / (name + '.log')
    row = dict(name=name, command=list(map(str, argv)), cwd=str(cwd), started=time.time(),
               environment={k: stage_env[k] for k in ('TMPDIR', 'CFLAGS', 'LDFLAGS', 'ASAN_OPTIONS', 'UBSAN_OPTIONS') if k in stage_env})
    with logfile.open('x') as log:
        proc = subprocess.Popen(argv, cwd=cwd, env=stage_env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        row['pid'] = proc.pid
        try:
            row['returncode'] = proc.wait(timeout=1200)
        except BaseException:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
            raise
    content = logfile.read_text(errors='replace')
    counts = re.findall(r'RESULTS: (\d+) tests \((\d+) ok, (\d+) failed, (\d+) skipped\)', content)
    row.update(finished=time.time(), log=logfile.name, log_sha256=digest(logfile), summaries=counts)
    row['passed'] = row['returncode'] == 0 and (expected is None or len(counts) == 1 and int(counts[0][0]) == int(counts[0][1]) and int(counts[0][2]) == int(counts[0][3]) == 0 and (expected == 'suite' or int(counts[0][0]) == 1))
    records.append(row)
    save(ARCHIVE / 'results.json', records)
    print(name, 'PASS' if row['passed'] else 'FAIL', counts, flush=True)
    if not row['passed']:
        raise RuntimeError(str(logfile))

SCRATCH.mkdir(parents=True, exist_ok=False)
TREE = SCRATCH / 'source'
TREE.mkdir()
for name in ('src', 'include', 'tests'):
    shutil.copytree(ROOT / name, TREE / name)
for name in ('Makefile', '.clang-format'):
    shutil.copy2(ROOT / name, TREE / name)
source_before = manifest(TREE)
save(ARCHIVE / 'sources-before.json', source_before)
save(ARCHIVE / 'provenance.json', dict(head=subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip(), tree=str(TREE), script_sha256=digest(Path(__file__)), purpose='Old version-1 references persisted, cache evicted, clean and recovering reopen paths; no backward compatibility or migration'))
(ARCHIVE / 'test.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', 'tests/unit/splinter_test.c']))
summary = dict(passed=False, started=time.time(), stages=['release','debug','sanitizers'])
try:
    print('Waiting for exclusive machine lock', flush=True)
    with LOCK.open('rb') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        print('Machine lock acquired', flush=True)
        summary['lock_acquired'] = time.time()
        for stage in summary['stages']:
            mode = 'release' if stage == 'release' else 'debug'
            sanitize = stage == 'sanitizers'
            buildroot = SCRATCH / ('build-' + stage)
            tmp = SCRATCH / ('tmp-' + stage)
            tmp.mkdir()
            stage_env = dict(env, TMPDIR=str(tmp))
            if sanitize:
                stage_env.update(CFLAGS='-fsanitize=undefined -fno-sanitize-recover=all -fno-omit-frame-pointer', LDFLAGS='-fsanitize=undefined', ASAN_OPTIONS='detect_leaks=0:halt_on_error=1', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
            run(stage + '-build', ['make','-j6','CC=gcc',f'BUILD_ROOT={buildroot}',f'BUILD_MODE={mode}',f'BUILD_ASAN={int(sanitize)}','BUILD_MSAN=0','BUILD_MEMORY_FAULT_INJECTION=0','unit/btree_test','unit/splinter_test'],TREE,stage_env)
            build = buildroot / (mode + ('-asan' if sanitize else ''))
            for suite, case in [('btree',None),('splinter','test_invalid_branch_reference_rejected'),('splinter','test_persisted_old_branch_version_rejected')]:
                name = stage + '-' + suite + ('-' + case if case else '')
                cwd = SCRATCH / 'tests' / name
                cwd.mkdir(parents=True)
                cmd = [str(build / 'bin/unit' / (suite + '_test'))]
                if suite == 'splinter':
                    cmd.extend(['--db-location','core.db','--cache-capacity-mib','128','--db-capacity-gib','64',case])
                run(name,cmd,cwd,stage_env,'suite' if case is None else 'single')
            save(ARCHIVE / (stage + '-artifacts.json'), {str(p.relative_to(build)): digest(p) for p in sorted(build.rglob('*')) if p.is_file() and ('/bin/' in str(p) or '/lib/' in str(p))})
        summary['lock_released'] = time.time()
    summary['sources_unchanged'] = manifest(TREE) == source_before
    summary['passed'] = summary['sources_unchanged'] and all(r['passed'] for r in records)
except BaseException as exc:
    summary['error'] = repr(exc)
    raise
finally:
    summary['finished'] = time.time()
    save(ARCHIVE / 'summary.json', summary)
