import fcntl, hashlib, json, os, re, shutil, signal, subprocess, sys, time
from pathlib import Path
root=Path.cwd(); scratch=root/'.cache/prefix-msan'; archive=root/'benchmarks/results-20261016/prefix-msan'
mode=sys.argv[1]
assert mode in ('baseline-tests','fixed-msan','fixed-release')
tree=scratch/(mode+'-source'); shutil.copytree(scratch/'original-source',tree,dirs_exist_ok=True)
files=['Makefile','tests/unit/splinterdb_quick_test.c','tests/unit/platform_apis_test.c']
if mode!='baseline-tests': files += ['src/btree.c','src/platform_linux/laio.c']
for name in files: shutil.copy2(root/name,tree/name)
sources={str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(tree.rglob('*')) if p.is_file()}
record={'mode':mode,'sources_sha256':sources,'commands':[]}
env={k:v for k,v in os.environ.items() if k not in ['CC','LD','BUILD_ROOT','BUILD_MODE','BUILD_ASAN','BUILD_MSAN','CFLAGS','LDFLAGS','MAKEFLAGS','MFLAGS','BUILD_MEMORY_FAULT_INJECTION']}
tmp=scratch/(mode+'-tmp');tmp.mkdir(exist_ok=True);env.update(TMPDIR=str(tmp),MSAN_OPTIONS='halt_on_error=1:exit_code=86',LLVM_SYMBOLIZER_PATH='/usr/bin/llvm-symbolizer-19')
record['environment']={k:env[k] for k in ['TMPDIR','MSAN_OPTIONS','LLVM_SYMBOLIZER_PATH']}
def save(): (archive/(mode+'-run.json')).write_text(json.dumps(record,indent=2)+'\n')
def run(name,cmd,cwd,expect_failure=False):
    log=archive/(mode+'-'+name+'.log'); row={'name':name,'command':list(map(str,cmd)),'cwd':str(cwd),'start':time.time()}
    record['commands'].append(row);save();print(mode,name,'started',flush=True)
    with log.open('x') as stream:
        p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True); row['pid']=p.pid;save()
        try: row['returncode']=p.wait(timeout=3600)
        except BaseException:
            os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
            raise
    content=log.read_text(errors='replace')
    row.update(finish=time.time(),log=log.name,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),summaries=re.findall(r'RESULTS: (\d+) tests \((\d+) ok, (\d+) failed, (\d+) skipped\)',content))
    row['passed']=(row['returncode']==1 and '[FAIL]' in content and len(row['summaries'])==1) if expect_failure else row['returncode']==0
    save();print(mode,name,'finished',row['returncode'],row['summaries'],flush=True)
    print('\n'.join(content.splitlines()[-9:]),flush=True)
    if not row['passed']: raise RuntimeError(str(log))
with Path('/home/rob/projects/splinterdb/.cache/projects-20261011/coordination/machine.lock').open('r') as lock:
    print(mode,'waiting for machine lock',flush=True);fcntl.flock(lock,fcntl.LOCK_EX);print(mode,'machine lock acquired',flush=True)
    msan=mode!='fixed-release';cc='clang-19' if msan else 'gcc';build=scratch/(mode+'-build'); bindir=build/('release-msan' if msan else 'release')/'bin/unit'
    run('build',['make','-j6',f'CC={cc}',f'LD={cc}',f'BUILD_ROOT={build}','BUILD_MODE=release',f'BUILD_MSAN={int(msan)}','BUILD_ASAN=0',str(bindir/'large_inserts_stress_test'),'unit/splinterdb_quick_test',str(bindir/'platform_apis_test'),'unit/btree_test'],tree)
    cases=[('prefix','splinterdb_quick_test',['test_branch_prefix_pack_initializes_free_gap'])]
    cases += [(name,'platform_apis_test',[case]) for name,case in [('io-full','test_async_read_initializes_all_iovecs'),('io-short','test_async_short_read_initializes_only_returned_bytes'),('io-eof','test_async_eof_read_keeps_buffer_poisoned'),('io-failed','test_async_failed_read_keeps_buffer_poisoned'),('io-write','test_async_write_does_not_initialize_source')]]
    if mode!='baseline-tests':
        cases += [('btree','btree_test',[]),('quick','splinterdb_quick_test',[])]
        if mode=='fixed-msan':cases += [('stress-full','large_inserts_stress_test',['--num-inserts','1000000','--db-capacity-gib','25'])]
    for name,binary,args in cases:
        cwd=scratch/(mode+'-'+name);cwd.mkdir(exist_ok=True)
        run(name,[str(bindir/binary)]+args,cwd,mode=='baseline-tests' and name in ('prefix','io-full','io-short'))
    record['sources_unchanged']=sources=={str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(tree.rglob('*')) if p.is_file()}
    record['passed']=record['sources_unchanged'] and all(r['passed'] for r in record['commands']);save()
print(mode,'complete, lock released',flush=True)
