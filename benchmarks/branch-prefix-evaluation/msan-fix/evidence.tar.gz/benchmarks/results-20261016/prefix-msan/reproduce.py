import fcntl, hashlib, io, json, os, signal, subprocess, tarfile, time
from pathlib import Path
root=Path.cwd()
scratch=root/'.cache/prefix-msan'
archive=root/'benchmarks/results-20261016/prefix-msan'
tree=scratch/'original-source'
tree.mkdir(exist_ok=True)
data=subprocess.check_output(['git','archive','HEAD','src','include','tests','Makefile','.clang-format'])
with tarfile.open(fileobj=io.BytesIO(data)) as tf:
    tf.extractall(tree, filter='data')
(archive/'original-source.tar').write_bytes(data)
record={'head': subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(), 'source_sha256':hashlib.sha256(data).hexdigest(),'commands':[]}
env={k:v for k,v in os.environ.items() if k not in ['CC','LD','BUILD_ROOT','BUILD_MODE','BUILD_ASAN','BUILD_MSAN','CFLAGS','LDFLAGS','MAKEFLAGS','MFLAGS','BUILD_MEMORY_FAULT_INJECTION']}
tmp=scratch/'original-tmp'; tmp.mkdir(exist_ok=True)
env.update(TMPDIR=str(tmp),MSAN_OPTIONS='halt_on_error=1:exit_code=86',LLVM_SYMBOLIZER_PATH='/usr/bin/llvm-symbolizer-19')
def save(): (archive/'original-run.json').write_text(json.dumps(record,indent=2)+'\n')
def run(name,cmd,cwd,timeout=3600):
    log=archive/(name+'.log')
    row={'name':name,'command':list(map(str,cmd)),'cwd':str(cwd),'start':time.time()}
    record['commands'].append(row); save()
    print(name, 'started',flush=True)
    with log.open('w') as stream:
        proc=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        row['pid']=proc.pid; save()
        try: row['returncode']=proc.wait(timeout=timeout)
        except BaseException:
            os.killpg(proc.pid,signal.SIGTERM)
            try: proc.wait(timeout=10)
            except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL); proc.wait()
            raise
    row.update(finish=time.time(),log=log.name,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest()); save()
    print(name,'finished',row['returncode'],flush=True)
    print('\n'.join(log.read_text(errors='replace').splitlines()[-28:]),flush=True)
    return row['returncode']
with Path('/home/rob/projects/splinterdb/.cache/projects-20261011/coordination/machine.lock').open('r') as lock:
    print('Waiting for machine lock',flush=True); fcntl.flock(lock,fcntl.LOCK_EX); print('Machine lock acquired',flush=True)
    build=scratch/'original-build'
    rc=run('original-build',['make','-j6','CC=clang-19','LD=clang-19',f'BUILD_ROOT={build}','BUILD_MODE=release','BUILD_MSAN=1','BUILD_ASAN=0',str(build/'release-msan/bin/unit/large_inserts_stress_test'),'unit/splinterdb_quick_test',str(build/'release-msan/bin/unit/platform_apis_test')],tree)
    if rc: raise SystemExit(rc)
    cwd=scratch/'original-stress'; cwd.mkdir(exist_ok=True)
    rc=run('original-stress',[str(build/'release-msan/bin/unit/large_inserts_stress_test'),'--num-inserts','1000000','--db-capacity-gib','25','test_seq_keys_random_values_threaded'],cwd)
print('Original reproduction completed; machine lock released',flush=True)
